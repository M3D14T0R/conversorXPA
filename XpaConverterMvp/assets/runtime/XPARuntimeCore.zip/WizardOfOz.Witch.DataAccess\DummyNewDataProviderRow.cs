using System;
using XPARuntimeCore.Box.Data.Advanced;

namespace WizardOfOz.Witch.DataAccess;

internal class DummyNewDataProviderRow : DataProviderRow
{
	private bool _updated;

	public void SetColumnsAcordingToYourValueOrDefaultValuesForANewRowAndRefreshJoinedLookups()
	{
	}

	public void UpdateDatabaseAcordingToValues()
	{
		_updated = true;
	}

	public void Delete()
	{
		_updated = true;
	}

	public void Lock(Action callIfRowDoesNotExist, bool checkForChanges)
	{
	}

	public void DoUpdateOrInsertOnSavingRow()
	{
	}

	public void DoDeleteOnSavingRow()
	{
	}

	public bool IsNewRow()
	{
		return !_updated;
	}

	public void ReloadRowData(Action callIfRowDoesNotExist)
	{
	}

	public void ReloadRowDataAndIgnoreExceptions()
	{
	}

	public bool IsEqualTo(DataProviderRow b)
	{
		return false;
	}

	public void Unlock()
	{
	}

	public void LockAndIgnoreExceptions()
	{
	}

	public bool HasJoins()
	{
		return false;
	}

	public DataRowFilter GetFilterChecker()
	{
		return DummyDataRowFitler.Instance;
	}

	public void AddEqualToColumn(ColumnBase parentIdColumn, ColumnBase columnToTakeTheValueFrom, FilterCollection fc)
	{
	}
}
