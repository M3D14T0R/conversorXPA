namespace WizardOfOz.Witch.DataAccess;

internal interface QueryResultProvider
{
	QueryResult SubFilter(FilterCondition extraFilter);

	QueryResult FromStart();

	QueryResult From(DataProviderRow row, bool reverse);

	DataProviderRow CreateTemporaryNewRow();

	bool ProvidesInfiniteQueryResults();

	QueryResult AllRows(bool lockAllRows);

	QueryResult FromEnd();

	QueryResult After(DataProviderRow row, bool reverse);

	QueryResult FetchRowsThatMatchFilterOrAreAfterIt(FilterCondition filter, bool reverseParkOnRowOrder);

	QueryResult Preload();
}
