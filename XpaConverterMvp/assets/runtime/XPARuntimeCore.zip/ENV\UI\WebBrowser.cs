using System;

namespace ENV.UI
{
    public class WebBrowser : XPARuntimeCore.Box.UI.WebBrowser, WebBrowserShared
    {
        public void LoadHtml(string html)
        {
            DocumentText = html;
        }
    }
    public interface WebBrowserShared
    {
        void LoadHtml(string html);
    }
}
