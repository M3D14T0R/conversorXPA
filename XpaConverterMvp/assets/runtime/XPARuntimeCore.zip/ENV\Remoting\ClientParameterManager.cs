using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ENV.Remoting.Data;
using XPARuntimeCore.Box;
using XPARuntimeCore.Box.Advanced;
using XPARuntimeCore.Box.Data;
using XPARuntimeCore.Box.Data.Advanced;

namespace ENV.Remoting
{
    public class ClientParameterManager : ResultConsumer
    {
        List<ColumnBase> _columns = new List<ColumnBase>();
        public bool DoNotTrim { get; set; }
        public object Pack(object o)
        {
            if (o == null)
                return null;
            if (o.GetType().IsSerializable)
                return o;
            {
                var t = o as Text;
                if (t != null)
                {
                    if (!DoNotTrim)
                        t = t.TrimEnd();
                    return new myText(t);
                }
            }
            {
                var t = o as Number;
                if (t != null)
                    return new myNumber(t);
            }
            {
                var t = o as Date;
                if (t != null)
                    return new myDate(t);
            }
            {
                var t = o as Time;
                if (t != null)
                    return new myTime(t);
            }
            {
                var t = o as Bool;
                if (t != null)
                    return new myBool(t);
            }
            {
                var t = o as NumberColumn;
                if (t != null)
                {
                    _columns.Add(t);
                    return new WrappedNumberColumn(_columns.Count - 1, Pack(t.Value));
                }
            }
            {
                var t = o as TextColumn;
                if (t != null)
                {
                    _columns.Add(t);
                    return new WrappedTextColumn(_columns.Count - 1, Pack(t.Value));
                }
            }
            {
                var t = o as DateColumn;
                if (t != null)
                {
                    _columns.Add(t);
                    return new WrappedDateColumn(_columns.Count - 1, Pack(t.Value));
                }
            }
            {
                var t = o as TimeColumn;
                if (t != null)
                {
                    _columns.Add(t);
                    return new WrappedTimeColumn(_columns.Count - 1, Pack(t.Value));
                }
            }
            {
                var t = o as BoolColumn;
                if (t != null)
                {
                    _columns.Add(t);
                    return new WrappedBoolColumn(_columns.Count - 1, Pack(t.Value));
                }
            }
            {
                var t = o as ByteArrayColumn;
                if (t != null)
                {
                    _columns.Add(t);
                    return new WrappedByteArrayColumn(_columns.Count - 1, Pack(t.Value));
                }
            }



            throw new Exception("Unable to pack type" + o.GetType());
        }
        [Serializable]
        internal class WrappedNumberColumn : SerializedByMe, Serializable
        {

            int _index;
            object _value;

            public WrappedNumberColumn(int index, object value)
            {
                _index = index;
                _value = value;
            }

            public object GetValue(IUnPacker unpacker)
            {
                var nc = new NumberColumn { AllowNull = true, Value = (Number)unpacker.UnPack(_value) };
                unpacker.AddColumn(nc, _index);
                return nc;
            }

            public WrappedNumberColumn(Loader l)
            {
                _index = l.Get<int>();
                _value = l.Get<object>();
            }
            public void SaveTo(Saver saver)
            {
                saver.SaveObjects(_index, _value);
            }
        }
        [Serializable]
        internal class WrappedTextColumn : SerializedByMe,Serializable
        {

            int _index;
            object _value;

            public WrappedTextColumn(int index, object value)
            {
                _index = index;
                _value = value;
            }
            public WrappedTextColumn(Loader l)
            {
                _index = l.Get<int>();
                _value = l.Get<object>();
            }
            public void SaveTo(Saver saver)
            {
                saver.SaveObjects(_index, _value);
            }

            public object GetValue(IUnPacker unpacker)
            {
                var nc = new TextColumn { AllowNull = true, Value = (Text)unpacker.UnPack(_value) };
                unpacker.AddColumn(nc, _index);
                return nc;
            }
        }
        [Serializable]
        internal class WrappedDateColumn : SerializedByMe,Serializable
        {

            int _index;
            object _value;

            public WrappedDateColumn(int index, object value)
            {
                _index = index;
                _value = value;
            }
            public WrappedDateColumn(Loader l)
            {
                _index = l.Get<int>();
                _value = l.Get<object>();
            }
            public void SaveTo(Saver saver)
            {
                saver.SaveObjects(_index, _value);
            }

            public object GetValue(IUnPacker unpacker)
            {
                var nc = new DateColumn { AllowNull = true, Value = (Date)unpacker.UnPack(_value) };
                unpacker.AddColumn(nc, _index);
                return nc;
            }
        }
        internal void ReportColumnResultToConsole()
        {
            if (_columns.Count == 0)
                return;
            Console.WriteLine("Arguments :");
            Console.WriteLine("=========== ");
            for (int i = 0; i < _columns.Count; i++)
            {
                Console.Write("#");
                Console.Write((i + 1).ToString().PadRight(3));
                Console.Write(!_updatedColumns.Contains(i) ? "(Not modified) : " : "               : ");
                var c = _columns[i];
                Console.Write(c is TextColumn ? "ALPHA  " : c is NumberColumn ? "NUMERIC" : c is BoolColumn ? "LOGICAL " : "UNKNOWN");
                Console.Write("  : ");
                Console.WriteLine(c.Value.ToString().TrimEnd(' '));
            }
        }
        [Serializable]
        internal class WrappedTimeColumn : SerializedByMe,Serializable
        {

            int _index;
            object _value;

            public WrappedTimeColumn(int index, object value)
            {
                _index = index;
                _value = value;
            }
            public WrappedTimeColumn(Loader l)
            {
                _index = l.Get<int>();
                _value = l.Get<object>();
            }
            public void SaveTo(Saver saver)
            {
                saver.SaveObjects(_index, _value);
            }

            public object GetValue(IUnPacker unpacker)
            {
                var nc = new TimeColumn { AllowNull = true, Value = (Time)unpacker.UnPack(_value) };
                unpacker.AddColumn(nc, _index);
                return nc;
            }
        }
        [Serializable]
        internal class WrappedBoolColumn : SerializedByMe,Serializable
        {

            int _index;
            object _value;

            public WrappedBoolColumn(int index, object value)
            {
                _index = index;
                _value = value;
            }
                        public WrappedBoolColumn(Loader l)
            {
                _index = l.Get<int>();
                _value = l.Get<object>();
            }
            public void SaveTo(Saver saver)
            {
                saver.SaveObjects(_index, _value);
            }

            
            public object GetValue(IUnPacker unpacker)
            {
                var nc = new BoolColumn { AllowNull = true, Value = (Bool)unpacker.UnPack(_value) };
                unpacker.AddColumn(nc, _index);
                return nc;
            }
        }
        [Serializable]
        internal class WrappedByteArrayColumn : SerializedByMe,Serializable
        {

            int _index;
            object _value;

            public WrappedByteArrayColumn(int index, object value)
            {
                _index = index;
                _value = value;
            }
            public WrappedByteArrayColumn(Loader l)
            {
                _index = l.Get<int>();
                _value = l.Get<object>();
            }
            public void SaveTo(Saver saver)
            {
                saver.SaveObjects(_index, _value);
            }

            public object GetValue(IUnPacker unpacker)
            {
                var nc = new ByteArrayColumn { AllowNull = true, Value = (byte[])unpacker.UnPack(_value) };
                unpacker.AddColumn(nc, _index);
                return nc;
            }
        }

        [Serializable]
        internal class myText : SerializedByMe,Serializable
        {
            string _value;

            public myText(string value)
            {
                _value = value;
            }
            public myText(Loader l)
            {
                _value = l.Get<string>();
            }
            public void SaveTo(Saver saver)
            {
                saver.SaveObjects(_value);
            }

            public object GetValue(IUnPacker unpacker)
            {
                return (Text)_value;
            }

        }
        [Serializable]
        internal class myNumber : SerializedByMe,Serializable
        {
            decimal _value;


            public myNumber(decimal value)
            {
                _value = value;
            }
            public myNumber(Loader l)
            {
                _value = l.Get<decimal>();
            }
            public void SaveTo(Saver saver)
            {
                saver.SaveObjects(_value);
            }

            public object GetValue(IUnPacker unpacker)
            {
                return (Number)_value;
            }
        }
        [Serializable]
        internal class myDate : SerializedByMe,Serializable
        {
            long _value;

            public myDate(Date value)
            {
                _value = ENV.UserMethods.Instance.ToNumber(value);
            }
            public myDate(Loader l)
            {
                _value = l.Get<long>();
            }
            public void SaveTo(Saver saver)
            {
                saver.SaveObjects(_value);
            }

            public object GetValue(IUnPacker unpacker)
            {
                return ENV.UserMethods.Instance.ToDate(_value);
            }
        }
        [Serializable]
        internal class myTime : SerializedByMe,Serializable
        {
            long _value;

            public myTime(Time value)
            {
                _value = ENV.UserMethods.Instance.ToNumber(value);
            }
            public myTime(Loader l)
            {
                _value = l.Get<long>();
            }
            public void SaveTo(Saver saver)
            {
                saver.SaveObjects(_value);
            }

            public object GetValue(IUnPacker unpacker)
            {
                return ENV.UserMethods.Instance.ToTime(_value);
            }
        }
        [Serializable]
        internal class myBool : SerializedByMe,Serializable
        {
            bool _value;

            public myBool(Bool value)
            {
                _value = value;
            }
            public myBool(Loader l)
            {
                _value = l.Get<bool>();
            }
            public void SaveTo(Saver saver)
            {
                saver.SaveObjects(_value);
            }

            public object GetValue(IUnPacker unpacker)
            {
                return (Bool)_value;
            }
        }
        HashSet<int> _updatedColumns = new HashSet<int>();
        public void Set(int id, object value)
        {
            _columns[id].Value = value;
            _updatedColumns.Add(id);
        }

        public object _returnValue;
        public void SetReturnValue(object value)
        {
            _returnValue = value;
        }
    }
    interface SerializedByMe
    {
        object GetValue(IUnPacker unpacker);
    }

    interface IUnPacker
    {
        void AddColumn(ColumnBase column, int id);
        object UnPack(object o);
    }
    public interface ServerParameterByRefResultInformation
    {
        void ApplyTo(ResultConsumer client);
    }
    public interface ResultConsumer
    {
        void Set(int id, object value);
        void SetReturnValue(object value);
    }

    public class ServerParameterManager : IUnPacker
    {
        class ColumnInProcess
        {
            ColumnBase _column;
            int _id;
            object _originalValue;

            public ColumnInProcess(ColumnBase column, int id)
            {
                _column = column;
                _id = id;
                _originalValue = _column.Value;
            }

            public void AddTo(MyParameterByRefResultInformation information)
            {
                if (XPARuntimeCore.Box.Advanced.Comparer.Compare(_originalValue, _column.Value) != 0)
                    information.Set(_id, _column.Value);
            }
        }

        List<ColumnInProcess> _columns = new List<ColumnInProcess>();
        public object UnPack(object o)
        {
            var z = o as SerializedByMe;
            if (z != null)
                return z.GetValue(this);
            return o;
        }

        void IUnPacker.AddColumn(ColumnBase column, int id)
        {
            _columns.Add(new ColumnInProcess(column, id));
        }
        [Serializable]
        internal class MyParameterByRefResultInformation : ResultConsumer, ServerParameterByRefResultInformation,Serializable
        {
            public MyParameterByRefResultInformation() { }
            public MyParameterByRefResultInformation(Loader l)
            {
                _returnValue = l.Get<object>();
                var arr = l.Get<object[]>();
                for (int i = 0; i < arr.Length; i++)
                {
                    if (i % 2 == 0) {
                        _values.Add((int)arr[i], arr[i + 1]);
                    }
                }
            }
            public void SaveTo(Saver saver)
            {
                var arr = new ArrayList();
                foreach (var val in _values)
                {
                    arr.Add(val.Key);
                    arr.Add(val.Value);
                }
                saver.SaveObjects(_returnValue,arr.ToArray());
            }
            Dictionary<int, object> _values = new Dictionary<int, object>();

            public void Set(int id, object value)
            {
                _values.Add(id, new ClientParameterManager().Pack(value));
            }

            object _returnValue = null;
            public void SetReturnValue(object value)
            {
                _returnValue = new ClientParameterManager().Pack(value);
            }

            public void ApplyTo(ResultConsumer client)
            {
                foreach (var o in _values)
                {
                    client.Set(o.Key, new ServerParameterManager().UnPack(o.Value));
                }
                client.SetReturnValue(new ServerParameterManager().UnPack(_returnValue));
            }

        }
        public ServerParameterByRefResultInformation CreateResult(object result)
        {
            var x = new MyParameterByRefResultInformation();
            x.SetReturnValue(result);
            foreach (var c in _columns)
            {
                c.AddTo(x);
            }
            return x;
        }

    }
}
