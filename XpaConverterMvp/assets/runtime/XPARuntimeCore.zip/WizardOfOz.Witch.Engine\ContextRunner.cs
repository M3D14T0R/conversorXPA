using System;

namespace WizardOfOz.Witch.Engine;

internal interface ContextRunner
{
	void RunInContext(Action command);

	ContextInstance CreateContextInstance();
}
