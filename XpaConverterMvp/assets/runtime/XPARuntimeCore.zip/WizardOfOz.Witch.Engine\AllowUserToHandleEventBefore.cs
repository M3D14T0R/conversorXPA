using System;
using XPARuntimeCore.Box;
using XPARuntimeCore.Box.UI.Advanced;

namespace WizardOfOz.Witch.Engine;

internal delegate void AllowUserToHandleEventBefore(bool isWithinActiveTask, Action<Command, ControlBase> raiseCommand, Action runWithoutCommand);
