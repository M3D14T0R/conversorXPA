using System.Drawing;
using XPARuntimeCore.Box.UI;
using XPARuntimeCore.Box;
namespace ENV.Security.UI
{

    /// <summary>Button</summary>
    public partial class Button : XPARuntimeCore.Box.UI.Button
    {


        /// <summary>Button</summary>
        public Button()
        {
            InitializeComponent();
        }

    }
}
