using System;
using System.Collections.Generic;
using XPARuntimeCore.Box;
using XPARuntimeCore.Box.Advanced;

namespace WizardOfOz.Witch.DataAccess;

internal class Locking
{
	private class NoneRowLocking : lockingBase
	{
		internal NoneRowLocking(RowLocker locker)
			: base(locker)
		{
		}

		public override void StartOfRow()
		{
		}

		public override void Loaded(object context, DataProviderRow row, Action reloadColumnData)
		{
		}

		public override void LockCurrentRow()
		{
			throw new InvalidOperationException("Rows cannot be locked when row locking is set to None");
		}

		public override void RowWasLeft()
		{
		}

		public override bool LockAllRows(Func<bool> inTransaction, bool isForRelation)
		{
			return false;
		}
	}

	private class lockingBase : ILockingStrategy, IDisposable
	{
		protected RowLocker _locker;

		protected bool _isRowLocked;

		protected bool _parkedOnRow;

		private Dictionary<object, DataProviderRow> _rowsToLock = new Dictionary<object, DataProviderRow>();

		internal lockingBase(RowLocker locker)
		{
			_locker = locker;
		}

		public virtual bool ShouldRollbackOnUndoAndRowTransaction(Activities activity, bool suppressLockingInBrowseMode)
		{
			return true;
		}

		public virtual void StartOfRow()
		{
			_locker.StartOfRow();
			_isRowLocked = false;
			_rowsToLock.Clear();
			if (_parkedOnRow)
			{
				throw new InvalidOperationException();
			}
			_parkedOnRow = true;
		}

		public virtual void RowAboutToBeSavedToDB()
		{
		}

		public virtual void UserEdit()
		{
		}

		public void RelationRowUnloaded(DataProviderRow row)
		{
			_locker.UnlockRelatedRow(row);
			foreach (KeyValuePair<object, DataProviderRow> item in _rowsToLock)
			{
				if (item.Value == row)
				{
					_rowsToLock.Remove(item.Key);
					break;
				}
			}
		}

		public virtual void Loaded(object context, DataProviderRow row, Action reloadColumnData)
		{
			if (_isRowLocked)
			{
				_locker.Lock(row, CheckForChanges: false);
			}
			else if (_parkedOnRow)
			{
				_rowsToLock[context] = row;
			}
		}

		public virtual void LockCurrentRow()
		{
			if (_isRowLocked || !_parkedOnRow)
			{
				return;
			}
			_isRowLocked = true;
			try
			{
				foreach (DataProviderRow value in _rowsToLock.Values)
				{
					_locker.Lock(value, CheckForChanges: true);
				}
				_locker.AfterLockWithCheckChanges();
			}
			catch
			{
				_isRowLocked = false;
				_locker.Unlock();
				throw;
			}
		}

		public virtual void RowWasLeft()
		{
			_parkedOnRow = false;
			_isRowLocked = false;
			_locker.Unlock();
		}

		public virtual void AboutToRunSavingRow()
		{
		}

		public virtual bool LockAllRows(Func<bool> inTransaction, bool isForRelation)
		{
			if (_isRowLocked)
			{
				return _locker.AllowLock();
			}
			return false;
		}

		public virtual void Dispose()
		{
		}
	}

	private class OnUserInput : lockingBase
	{
		public OnUserInput(RowLocker locker)
			: base(locker)
		{
		}

		public override void UserEdit()
		{
			base.LockCurrentRow();
		}

		public override void AboutToRunSavingRow()
		{
		}

		public override void RowAboutToBeSavedToDB()
		{
			if (!_isRowLocked)
			{
				LockCurrentRow();
			}
		}
	}

	private class OnRowSaveToDatabase : lockingBase
	{
		public OnRowSaveToDatabase(RowLocker locker)
			: base(locker)
		{
		}

		public override void RowAboutToBeSavedToDB()
		{
			base.LockCurrentRow();
			base.RowAboutToBeSavedToDB();
		}
	}

	private class OnRowLoaded : lockingBase
	{
		public OnRowLoaded(RowLocker locker)
			: base(locker)
		{
		}

		public override bool ShouldRollbackOnUndoAndRowTransaction(Activities activity, bool suppressLockingInBrowseMode)
		{
			if (suppressLockingInBrowseMode && activity == Activities.Browse)
			{
				return true;
			}
			return false;
		}

		public override void Loaded(object context, DataProviderRow row, Action reloadColumnData)
		{
			if (_parkedOnRow)
			{
				_locker.Lock(row, CheckForChanges: false);
				reloadColumnData();
			}
		}

		public override bool LockAllRows(Func<bool> inTransaction, bool isForRelation)
		{
			if ((isForRelation && _parkedOnRow) || (!isForRelation && inTransaction()))
			{
				return _locker.AllowLock();
			}
			return false;
		}
	}

	public static ILockingStrategy Create(LockingStrategy strategy, RowLocker locker)
	{
		return strategy switch
		{
			LockingStrategy.None => new NoneRowLocking(locker), 
			LockingStrategy.OnRowLoading => new OnRowLoaded(locker), 
			LockingStrategy.OnRowSaving => new OnRowSaveToDatabase(locker), 
			LockingStrategy.OnUserEdit => new OnUserInput(locker), 
			_ => throw new Error.DidNotAnticipateThis(), 
		};
	}
}
