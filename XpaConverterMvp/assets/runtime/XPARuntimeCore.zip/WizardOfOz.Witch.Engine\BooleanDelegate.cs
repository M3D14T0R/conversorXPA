namespace WizardOfOz.Witch.Engine;

internal delegate bool BooleanDelegate();
