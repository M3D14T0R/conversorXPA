namespace WizardOfOz.Witch.Engine;

internal interface ContextNode
{
	bool Matches(ContextNode newNode);
}
