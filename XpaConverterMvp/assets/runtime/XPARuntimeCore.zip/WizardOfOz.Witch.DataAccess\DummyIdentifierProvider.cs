using System;
using XPARuntimeCore.Box.Data.Advanced;

namespace WizardOfOz.Witch.DataAccess;

internal class DummyIdentifierProvider : IdentifierProvider
{
	private Func<ColumnBase, bool> _contains;

	public static IdentifierProvider Instance = new DummyIdentifierProvider();

	public DummyIdentifierProvider(Func<ColumnBase, bool> contains = null)
	{
		_contains = contains;
	}

	public bool Contains(ColumnBase column)
	{
		if (_contains == null)
		{
			return false;
		}
		return _contains(column);
	}
}
