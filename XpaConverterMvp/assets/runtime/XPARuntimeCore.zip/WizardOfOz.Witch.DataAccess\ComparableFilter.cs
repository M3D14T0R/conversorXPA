using System;
using System.Text;
using XPARuntimeCore.Box;
using XPARuntimeCore.Box.Data;
using XPARuntimeCore.Box.Data.Advanced;
using XPARuntimeCore.Box.Data.DataProvider;

namespace WizardOfOz.Witch.DataAccess;

internal class ComparableFilter : Filter, IValueSaver
{
	private string _filter;

	private StringBuilder sb = new StringBuilder();

	public ComparableFilter(FilterCondition condition, bool supportWildCard)
	{
		condition.ApplyTo(this, supportWildCard);
		_filter = sb.ToString();
		sb = null;
	}

	public override int GetHashCode()
	{
		return _filter.GetHashCode();
	}

	public override bool Equals(object obj)
	{
		if (!(obj is ComparableFilter comparableFilter))
		{
			return false;
		}
		return _filter.Equals(comparableFilter._filter);
	}

	public bool CompareTo(ComparableFilter f)
	{
		return _filter == f._filter;
	}

	public void AddBetweenCondition(ColumnBase column, ColumnFilterValue from, ColumnFilterValue to)
	{
		sb.Append(column.Name);
		sb.Append("{B ");
		from.SaveYourValueToDb(this);
		sb.Append(", ");
		to.SaveYourValueToDb(this);
		sb.Append("}");
	}

	public void AddEqual(ColumnBase column, ColumnFilterValue to)
	{
		sb.Append(column.Name);
		sb.Append("=");
		to.SaveYourValueToDb(this);
	}

	public void AddDifferent(ColumnBase column, ColumnFilterValue from)
	{
		sb.Append(column.Name);
		sb.Append("<>");
		from.SaveYourValueToDb(this);
	}

	public void AddStartsWith(ColumnBase column, ColumnFilterValue to)
	{
		sb.Append(column.Name);
		sb.Append("~");
		to.SaveYourValueToDb(this);
	}

	public void AddGreaterOrEqual(ColumnBase column, ColumnFilterValue to)
	{
		sb.Append(column.Name);
		sb.Append(">=");
		to.SaveYourValueToDb(this);
	}

	public void AddLessOrEqual(ColumnBase column, ColumnFilterValue to)
	{
		sb.Append(column.Name);
		sb.Append("<=");
		to.SaveYourValueToDb(this);
	}

	public void AddWhere(Action<TranslateToGatewayTerms, Action<string>> whereFactory)
	{
		whereFactory(delegate(WhereMeaningfullItem z)
		{
			z.SaveYourValueToDb(this);
			return "zzz";
		}, delegate(string y)
		{
			sb.Append(y);
		});
	}

	public void AddOr(FilterCondition a, FilterCondition b)
	{
		sb.Append("{");
		a.ApplyTo(this, supportWildCard: false);
		sb.Append("||");
		b.ApplyTo(this, supportWildCard: false);
		sb.Append("}");
	}

	public void AddLessThan(ColumnBase column, ColumnFilterValue to)
	{
		sb.Append(column.Name);
		sb.Append("<");
		to.SaveYourValueToDb(this);
	}

	public void AddGreaterThan(ColumnBase column, ColumnFilterValue to)
	{
		sb.Append(column.Name);
		sb.Append(">");
		to.SaveYourValueToDb(this);
	}

	public void AddUserCondition(Func<bool> condition)
	{
		AddTrueCondition();
	}

	public void AddLessOrEqualWithWildcard(TextColumn column, Text value, ColumnFilterValue filterItem)
	{
		sb.Append(column.Name);
		sb.Append("<=*");
		sb.Append(value);
	}

	public void AddTrueCondition()
	{
		sb.Append("1=1");
	}

	public void SaveInt(int value)
	{
		sb.Append(value);
	}

	public void SaveDecimal(decimal value, byte precision, byte scale)
	{
		sb.Append(value);
	}

	public void SaveString(string value, int length, bool fixedWidth)
	{
		sb.Append(value);
	}

	public void SaveAnsiString(string value, int length, bool fixedWidth)
	{
		sb.Append(value);
	}

	public void SaveNull()
	{
		sb.Append("null");
	}

	public void SaveDateTime(DateTime value)
	{
		sb.Append(value);
	}

	public void SaveTimeSpan(TimeSpan value)
	{
		sb.Append(value);
	}

	public void SaveBoolean(bool value)
	{
		sb.Append(value);
	}

	public void SaveByteArray(byte[] value)
	{
		foreach (byte value2 in value)
		{
			sb.Append(value2);
		}
	}

	public string GetCompareKey()
	{
		return _filter;
	}

	public void SaveEmptyDateTime()
	{
		sb.Append("EmptyDate");
	}
}
