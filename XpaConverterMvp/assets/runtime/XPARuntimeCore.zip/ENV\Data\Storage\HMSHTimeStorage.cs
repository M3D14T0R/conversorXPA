using ENV.Data.DataProvider;
using XPARuntimeCore.Box;
using XPARuntimeCore.Box.Data.DataProvider;

namespace ENV.Data.Storage
{
    public class HMSHTimeStorage : IColumnStorageSrategy<Time>
    {
        static StringTimeStorage _stringTimeStorage = new StringTimeStorage();

        public Time LoadFrom(IValueLoader loader)
        {
            var btr = loader as IBtrieveValueLoader;
            if (btr != null)
                return btr.GetTime();
            var ba = loader.GetByteArray();
            return new Time(ba[3], ba[2], ba[1]);
            
        }

        public void SaveTo(Time value, IValueSaver saver)
        {
            if (value == null)
                saver.SaveNull();
            else
            {
                var btr = saver as IBtrieveValueSaver;
                if (btr != null)
                    btr.SaveTime(value);
                else
                    saver.SaveByteArray(new byte[] { 0, (byte)value.Second, (byte)value.Minute, (byte)value.Hour });
            }
        }
    }
}
