﻿#if NET6_0_OR_GREATER
#else
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Web;

namespace ENV.IO
{
    internal class WebContextDotnetFramework : IWebContext
    {
        HttpContext Context => HttpContext.Current;
        NameValueCollection _badPostValues;
        public bool IsRunningOnWeb()
        {
            return Context != null;
        }
        public string GetFormBody()
        {
            var req = Context.Request;
            var result =  req.ContentEncoding.GetString(UserMethods.StreamToByteArray(req.InputStream));
            req.InputStream.Position = 0;
            return result;
        }
        public string GetPrgName()
        {
            var req = Context.Request;
            var prgName = req.Form["PRGNAME"];
            if (string.IsNullOrEmpty(prgName))
                prgName = req["PRGNAME"];
            if (string.IsNullOrEmpty(prgName) &&
              IsMethodPost &&
              req.Form.Count == 0)
            {
                try
                {
                    var x = req.ContentEncoding.GetString(UserMethods.StreamToByteArray(req.InputStream));
                    _badPostValues = HttpUtility.ParseQueryString(x);
                    _badPostValues.Add(req.Params);
                    prgName = _badPostValues["PRGNAME"];
                }
                catch
                {
                }

            }
            return prgName;
        }
        public byte[] GetFile(string key)
        {
            var file = Context.Request.Files[key];
            if (file != null)
            {
                return
                    UserMethods.StreamToByteArray(file.InputStream);
            }
            return null;



        }
        public string[] GetCookie(string key)
        {
            var cookie = Context.Request.Cookies[key];
            if (cookie == null)
                return null;
            var input = cookie.Values;

            var result = new string[input.Count];
            for (int i = 0; i < input.Count; i++)
            {
                if (Context != null)
                    result[i] = WebWriter.ProcessWebString(Context.Server.UrlDecode(input[i]));
                else
                    result[i] = input[i];
            }
            return result;
        }

        public string[] GetValues(string key)
        {
            if (WebWriter.HTTPServerVariablesBlackList.Contains(key))
            {
                var x = Context.Request.Params[key];
                var y = Context.Request.ServerVariables[key];
                if (x == y)
                    return null;
            }
            if (_badPostValues != null)
                return _badPostValues.GetValues(key);
            var r = Context.Request.Params.GetValues(key);
            FixHebrewUTFStuff(r);
            return r;
        }

        private static void FixHebrewUTFStuff(string[] r)
        {
            if (WebWriter.FixHebrewUTF8InUrlParameters && r != null)
            {
                for (int i = 0; i < r.Length; i++)
                {
                    if (r[i].IndexOf((char)1523) >= 0)
                    {
                        r[i] = Encoding.UTF8.GetString(Encoding.GetEncoding(1255).GetBytes(r[i]));
                    }
                }
            }
        }

        public string[] GetFormValues(string key)
        {
            if (WebWriter.HTTPServerVariablesBlackList.Contains(key))
            {
                var x = Context.Request.Params[key];
                var y = Context.Request.ServerVariables[key];
                if (x == y)
                    return null;
            }
            if (_badPostValues != null)
                return _badPostValues.GetValues(key);
            var z = Context.Request.Form.GetValues(key);
            if (z == null)
                z = Context.Request.ServerVariables.GetValues(key);
            FixHebrewUTFStuff(z);
            return z;
        }

        public void WriteFile(string path)
        {
            Context.Response.WriteFile(path, true);
        }

        public void SetContentType(string value)
        {
            Context.Response.ContentType = value;
        }

        public void AppendCookie(string key, string value)
        {
            Context.Response.AppendCookie(new HttpCookie(key, value));
        }

        public void AddHeader(string name, string value)
        {
            Context.Response.AddHeader(name, value);
        }

        public void WriteInitBytes(byte[] data)
        {
            Context.Response.BinaryWrite(data);
        }
        public void Write(string data)
        {
            Context.Response.Write(data);
        }

        public void LoadTo(Dictionary<string, object> memoryParams)
        {
            if (Context != null)
            {
                var c = Context.Request;
                if (c != null)
                {
                    foreach (var item in c.Form.AllKeys)
                    {
                        if (!memoryParams.ContainsKey(item.ToUpper(CultureInfo.InvariantCulture)))
                            memoryParams.Add(item.ToUpper(CultureInfo.InvariantCulture),
                                ParametersInMemory.Instance._outerValueProvide(item));
                    }
                    foreach (var item in c.Params.AllKeys)
                    {
                        if (!memoryParams.ContainsKey(item.ToUpper(CultureInfo.InvariantCulture)))
                            memoryParams.Add(item.ToUpper(CultureInfo.InvariantCulture),
                                ParametersInMemory.Instance._outerValueProvide(item));
                    }
                    foreach (var item in c.Cookies.AllKeys)
                    {
                        if (!memoryParams.ContainsKey(item.ToUpper(CultureInfo.InvariantCulture)))
                            memoryParams.Add(item.ToUpper(CultureInfo.InvariantCulture),
                                ParametersInMemory.Instance._outerValueProvide(item));
                    }

                }
            }
        }

        public void SetEncoding(Encoding encoding)
        {
            Context.Response.ContentEncoding = encoding;
        }

        public void SetCookie(string key, string value)
        {
            Context.Response.SetCookie(new HttpCookie(key, value));
        }

        public string GetUserHostAddress()
        {
            return Context.Request.UserHostAddress;
        }

        public bool IsMethodPost
        {
            get
            {
                return Context.Request.HttpMethod.Equals("POST",
                        StringComparison.InvariantCultureIgnoreCase);
            }
        }

        public string GetRequestBody(){
        Context.Request.InputStream.Position = 0;
            using (var sr = new System.IO.StreamReader(Context.Request.InputStream))
            {
                return sr.ReadToEnd();
            }
        }

        public string HttpMethod
        {
            get
            {
                return Context?.Request?.HttpMethod;
            }
        }

        public string RawUrl
        {
            get
            {
                return Context?.Request?.RawUrl;
            }
        }

        public string Path
        {
            get
            {
                return Context?.Request?.Path;
            }
        }

        public string ContentType
        {
            get
            {
                return Context?.Response?.ContentType;
            }
            set
            {
                if (Context?.Response != null)
                {
                    Context.Response.ContentType = value;
                }
            }
        }

        public int StatusCode
        {
            get
            {
                return Context?.Response?.StatusCode ?? 0;
            }
            set
            {
                if (Context?.Response != null)
                {
                    Context.Response.StatusCode = value;
                }
            }
        }

        public string this[string key]
        {
            get
            {
                return Context?.Request?[key];
            }
        }
    }
}

#endif