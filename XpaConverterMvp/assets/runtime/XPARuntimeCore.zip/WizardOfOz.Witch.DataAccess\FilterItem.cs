namespace WizardOfOz.Witch.DataAccess;

internal interface FilterItem
{
	void SaveTo(FilterItemSaver saver);
}
