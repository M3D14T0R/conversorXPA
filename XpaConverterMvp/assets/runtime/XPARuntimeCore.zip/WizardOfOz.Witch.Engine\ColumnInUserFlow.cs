using System;
using XPARuntimeCore.Box.Advanced;
using XPARuntimeCore.Box.Data.Advanced;
using XPARuntimeCore.Box.Flow;
using WizardOfOz.Witch.UI;

namespace WizardOfOz.Witch.Engine;

internal class ColumnInUserFlow : UserFlowConditionalItem, ParkedColumn
{
	private class myFocusedColumn : FocusedColumn
	{
		private ColumnInUserFlow _parent;

		public myFocusedColumn(ColumnInUserFlow parent)
		{
			_parent = parent;
		}

		public bool IsNullable()
		{
			return _parent._column.IsNullable();
		}

		public void Ditto()
		{
			_parent._column.Ditto();
		}

		public bool CanYouExpand()
		{
			return _parent._column.CanYouExpand();
		}

		public void SetToNull()
		{
			_parent._column.Value = null;
		}

		public void DoExpand(Action moveToNextColumnCommand, Action doDefault)
		{
			try
			{
				_parent._column.DoExpand(moveToNextColumnCommand, doDefault);
			}
			catch (FlowAbortException ex)
			{
				ex.DoYourStuff();
			}
		}

		public bool Matches(IControl control)
		{
			return _parent._control.AreYou(control);
		}

		public bool IsEditable()
		{
			return _parent._control.IsEditable();
		}
	}

	private ControlForFlow _control;

	private ColumnBase _column;

	public ColumnInUserFlow(ColumnBase column, ControlForFlow control)
	{
		_column = column;
		_control = control;
	}

	public ColumnInUserFlow(ControlForFlow control)
		: this(null, control)
	{
	}

	public void ActivateFlow(UserFlowItemActivationResult result, FlowMode mode, Direction direction, bool requiresTabStop, DuplicateIndexCheckHelper helper, bool noData, FlowMode flowModeForColumns, Action<Action> runInputValidation, Action<Action, FlowActionVisitor> runInFlowContext)
	{
		_control.Activate(flowModeForColumns, direction, requiresTabStop, noData, delegate
		{
			if (_column != null)
			{
				_column.PerformDuplicateIndexChecks(helper);
			}
		}, delegate
		{
			UserFlowItemActivationResult userFlowItemActivationResult = result;
			FocusedColumn column;
			if (_column == null)
			{
				FocusedColumn focusedColumn = new DummyFocusedColumn();
				column = focusedColumn;
			}
			else
			{
				FocusedColumn focusedColumn = new myFocusedColumn(this);
				column = focusedColumn;
			}
			userFlowItemActivationResult.ParkedOnColumn(column);
		}, runInputValidation, runInFlowContext);
	}

	public bool CanYouExpandBefore()
	{
		return _control.CanYouExpandBefore();
	}

	public bool CanYouExpandAfter()
	{
		return _control.CanYouExpandAfter();
	}

	public void LeaveColumn(Action andDo, LeaveColumnBehavior leaveColumnBehavior, DuplicateIndexCheckHelper helper)
	{
		leaveColumnBehavior.Leave(_control, delegate
		{
			if (_column != null)
			{
				_column.PerformDuplicateIndexChecks(helper);
			}
		}, andDo);
	}

	public bool LeaveColumnWithFlowBackwardInExpand()
	{
		if (_control != null)
		{
			return _control.LeaveColumnWithFlowBackwardInExpand();
		}
		return false;
	}

	public void WhoAreYouReally(UnderlyingUserFlowObjectVisitor visitor)
	{
		visitor.Iam(_control);
	}

	public bool CheckEnabled()
	{
		return _control.CheckEnabled();
	}

	public void RunExpandBeforeOrAfter(RunExpandResult result, Action noExpandBeforeOrAfter)
	{
		noExpandBeforeOrAfter();
	}

	public void LeaveControlWithoutCommiting()
	{
		_control.ExitEditing();
	}

	public void SaveDataAndDo(Action what, Action gotoNextControl)
	{
		_control.SaveYourDataAndDo(what, gotoNextControl);
	}

	public void ActivateFlowTemplateMode(UserFlowItemActivationResult result)
	{
		if (_column != null)
		{
			_control.ActivateTemplateMode(delegate
			{
				result.ParkedOnColumn(new myFocusedColumn(this));
			});
		}
	}

	public bool AreYou(ColumnBase column)
	{
		return _column == column;
	}

	public bool CanBeParkedOnWhenIdle()
	{
		return true;
	}

	public bool IsSameAs(UserFlowConditionalItem item)
	{
		if (!(item is ColumnInUserFlow columnInUserFlow))
		{
			return false;
		}
		return columnInUserFlow._column == _column;
	}
}
