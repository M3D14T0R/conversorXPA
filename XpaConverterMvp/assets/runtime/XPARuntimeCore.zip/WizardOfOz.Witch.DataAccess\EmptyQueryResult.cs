using System;

namespace WizardOfOz.Witch.DataAccess;

internal class EmptyQueryResult : QueryResult, IDisposable, ResetableQueryResult
{
	public DataProviderRow Current
	{
		get
		{
			throw new NotImplementedException();
		}
	}

	public bool MoveNext()
	{
		return false;
	}

	public bool TryResetAndReturnFalseIfNotSupported()
	{
		return false;
	}

	public void RemoveRow(DataProviderRow row)
	{
	}

	public void InsertRow(DataProviderRow row)
	{
	}

	public void Dispose()
	{
	}
}
