using System;

namespace WizardOfOz.Witch.DataAccess;

internal class EmptyCachedResult : CachedResult
{
	private class myQueryResult : QueryResult, IDisposable
	{
		public static myQueryResult Instanse = new myQueryResult();

		public DataProviderRow Current => null;

		public bool MoveNext()
		{
			return false;
		}

		public void Dispose()
		{
		}
	}

	public static EmptyCachedResult Instanse = new EmptyCachedResult();

	public QueryResult GetQueryResult()
	{
		return myQueryResult.Instanse;
	}

	public CachedResult Add(DataProviderRow current)
	{
		return new SingleQueryResult(current);
	}
}
