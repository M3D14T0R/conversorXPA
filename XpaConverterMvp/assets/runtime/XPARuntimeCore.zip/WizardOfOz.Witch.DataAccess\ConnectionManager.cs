using System;
using System.Data;
using XPARuntimeCore.Box.Data.DataProvider;

namespace WizardOfOz.Witch.DataAccess;

internal class ConnectionManager<type> where type : IDbConnection
{
	private class myTransactionMember : ITransaction
	{
		private IDbTransaction _trans;

		private ConnectionManager<type> _parent;

		public myTransactionMember(IDbTransaction trans, ConnectionManager<type> parent)
		{
			_trans = trans;
			_parent = parent;
		}

		public void DecorateSqlCommand(IDbCommand command)
		{
			command.Transaction = _trans;
		}

		public void Commit()
		{
			_trans.Commit();
			_parent._currentTransaction = null;
		}

		public void Rollback()
		{
			_trans.Rollback();
			_parent._currentTransaction = null;
		}
	}

	private type __connection;

	private bool _opened;

	private myTransactionMember _currentTransaction;

	private type Instance
	{
		get
		{
			if (__connection.State != ConnectionState.Open)
			{
				if (_opened)
				{
					throw new InvalidOperationException("The database connection is closed");
				}
				__connection.Open();
				_opened = true;
			}
			return __connection;
		}
	}

	public ConnectionManager(type _connection)
	{
		__connection = _connection;
	}

	public void AddActiveTransactionTo(ITransactionCollector collector)
	{
		if (_currentTransaction == null)
		{
			_currentTransaction = new myTransactionMember(Instance.BeginTransaction(), this);
		}
		collector.Add(_currentTransaction);
	}

	public IDbCommand CreateCommand()
	{
		IDbCommand dbCommand = Instance.CreateCommand();
		dbCommand.CommandTimeout = 0;
		if (_currentTransaction != null)
		{
			_currentTransaction.DecorateSqlCommand(dbCommand);
		}
		return dbCommand;
	}

	public void Close()
	{
		__connection.Close();
	}
}
