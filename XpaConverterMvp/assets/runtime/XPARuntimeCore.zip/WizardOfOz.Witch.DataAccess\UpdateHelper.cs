using XPARuntimeCore.Box.Data.Advanced;

namespace WizardOfOz.Witch.DataAccess;

internal interface UpdateHelper
{
	void AddChangedColumn(ColumnBase column);

	void AddValueToSetToOriginalAfterSave(ColumnDataInRow data);
}
