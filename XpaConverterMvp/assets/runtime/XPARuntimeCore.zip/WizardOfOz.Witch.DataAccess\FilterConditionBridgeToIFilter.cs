using XPARuntimeCore.Box.Data.DataProvider;

namespace WizardOfOz.Witch.DataAccess;

internal class FilterConditionBridgeToIFilter : IFilter
{
	private FilterCondition _theFilter;

	private IdentifierProvider _provider;

	private bool _supportWildCard;

	public FilterConditionBridgeToIFilter(FilterCondition theFilter, IdentifierProvider provider, bool supportWildCard)
	{
		_supportWildCard = supportWildCard;
		_theFilter = theFilter;
		_provider = provider;
	}

	public void AddTo(IFilterBuilder builder)
	{
		using FilterBridgeToIFilterConsumer filter = new FilterBridgeToIFilterConsumer(_provider, builder, _supportWildCard);
		_theFilter.ApplyTo(new FilterRelevanceDecorator(filter, _provider), _supportWildCard);
	}
}
