using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using XPARuntimeCore.Box.UI;

namespace ENV.Printing
{
    public class Shape:XPARuntimeCore.Box.UI.Shape
    {
        public Shape()
        {
            Style = XPARuntimeCore.Box.UI.ControlStyle.Flat;
            ColorScheme = new ColorScheme(Color.Black, Color.White);
        }
        protected override string Translate(string term)
        {
            return base.Translate(ENV.Languages.Translate(term));
        }
        public override FontScheme FontScheme
        {
            get
            {
                return base.FontScheme;
            }

            set
            {
                base.FontScheme = ENV.UI.LoadableFontScheme.GetPrintingFont(value);
            }
        }
    }
}
