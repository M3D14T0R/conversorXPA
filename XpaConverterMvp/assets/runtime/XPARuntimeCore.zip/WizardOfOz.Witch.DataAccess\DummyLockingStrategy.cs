using System;
using XPARuntimeCore.Box;

namespace WizardOfOz.Witch.DataAccess;

internal class DummyLockingStrategy : ILockingStrategy, IDisposable
{
	public void StartOfRow()
	{
	}

	public void RowAboutToBeSavedToDB()
	{
	}

	public void UserEdit()
	{
	}

	public void Loaded(object context, DataProviderRow row, Action reloadColumnData)
	{
	}

	public void LockCurrentRow()
	{
	}

	public void RowWasLeft()
	{
	}

	public void AboutToRunSavingRow()
	{
	}

	public bool LockAllRows(Func<bool> inTransaction, bool isForRelation)
	{
		return false;
	}

	public void Dispose()
	{
	}

	public bool ShouldRollbackOnUndoAndRowTransaction(Activities activity, bool suppressLockingInBrowseMode)
	{
		return false;
	}

	public void RelationRowUnloaded(DataProviderRow row)
	{
	}
}
