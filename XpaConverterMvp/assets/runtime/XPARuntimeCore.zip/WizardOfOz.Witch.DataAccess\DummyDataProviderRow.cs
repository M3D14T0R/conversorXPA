using System;
using XPARuntimeCore.Box.Data.Advanced;

namespace WizardOfOz.Witch.DataAccess;

internal class DummyDataProviderRow : DataProviderRow
{
	public static DummyDataProviderRow Instance => new DummyDataProviderRow();

	private DummyDataProviderRow()
	{
	}

	public void SetColumnsAcordingToYourValueOrDefaultValuesForANewRowAndRefreshJoinedLookups()
	{
	}

	public void UpdateDatabaseAcordingToValues()
	{
	}

	public void Delete()
	{
	}

	public void Lock(Action callIfRowDoesNotExist, bool checkForChanges)
	{
	}

	public bool IsNewRow()
	{
		return false;
	}

	public void ReloadRowData(Action callIfRowDoesNotExist)
	{
	}

	public void ReloadRowDataAndIgnoreExceptions()
	{
	}

	public bool IsEqualTo(DataProviderRow b)
	{
		return false;
	}

	public void Unlock()
	{
	}

	public void LockAndIgnoreExceptions()
	{
	}

	public bool HasJoins()
	{
		return false;
	}

	public DataRowFilter GetFilterChecker()
	{
		return DummyDataRowFitler.Instance;
	}

	public void AddEqualToColumn(ColumnBase parentIdColumn, ColumnBase columnToTakeTheValueFrom, FilterCollection fc)
	{
	}

	public void DoUpdateOrInsertOnSavingRow()
	{
	}

	public void DoDeleteOnSavingRow()
	{
	}
}
