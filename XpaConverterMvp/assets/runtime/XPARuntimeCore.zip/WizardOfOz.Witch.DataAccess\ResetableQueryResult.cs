using System;

namespace WizardOfOz.Witch.DataAccess;

internal interface ResetableQueryResult : IDisposable
{
	DataProviderRow Current { get; }

	bool MoveNext();

	bool TryResetAndReturnFalseIfNotSupported();

	void RemoveRow(DataProviderRow row);

	void InsertRow(DataProviderRow row);
}
