using WizardOfOz.Witch.DataAccess;

namespace WizardOfOz.Witch.Engine;

internal delegate void ActionForDisablePagingCommands(DataProviderRow firstRow, DataProviderRow lastRow);
