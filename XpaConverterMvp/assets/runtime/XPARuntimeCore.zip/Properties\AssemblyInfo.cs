using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("XPARuntimeCore.Box")]
[assembly: AssemblyDescription("The XPARuntimeCore Box Framework")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("XPARuntimeCore LTD")]
[assembly: AssemblyProduct("XPARuntimeCore.Box")]
[assembly: AssemblyCopyright("Copyright XPARuntimeCore LTD 2013")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("404cdb07-d3fd-4dec-9147-9fdd4ae9f8a2")]
[assembly: AssemblyFileVersion("4.6.0.35021")]
[assembly: AssemblyInformationalVersion("release-master-v:35021")]
[assembly: AssemblyVersion("4.6.0.35021")]
