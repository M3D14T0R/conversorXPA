namespace WizardOfOz.Witch.Engine;

internal delegate void DoDefaultAction();
