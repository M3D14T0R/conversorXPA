namespace WizardOfOz.Witch.DataAccess;

internal interface LookupInAQuery
{
	void SetCurrentRow(DataProviderRow row, RowWasUpdatedToDBDelegate callWhenRowIsUpdatedToDB);
}
