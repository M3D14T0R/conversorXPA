using System.Drawing;
using XPARuntimeCore.Box.UI;
using XPARuntimeCore.Box;
namespace ENV.Security.UI
{

    /// <summary>TextBox</summary>
    public partial class TextBox : XPARuntimeCore.Box.UI.TextBox
    {


        /// <summary>TextBox</summary>
        public TextBox()
        {
            InitializeComponent();
        }

    }
}
