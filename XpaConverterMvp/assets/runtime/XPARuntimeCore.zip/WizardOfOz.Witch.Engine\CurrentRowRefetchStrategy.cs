using System;

namespace WizardOfOz.Witch.Engine;

internal interface CurrentRowRefetchStrategy
{
	void Refetch(RefetchCurrentRow refech, Action doNotRefetch);
}
