using System;
using XPARuntimeCore.Box.Data.Advanced;

namespace WizardOfOz.Witch.Engine;

internal class DummyParkedColumn : ParkedColumn
{
	public void LeaveControlWithoutCommiting()
	{
	}

	public void SaveDataAndDo(Action what, Action gotoNextControl)
	{
		what();
	}

	public void LeaveColumn(Action andDo, LeaveColumnBehavior leaveColumnBehavior, DuplicateIndexCheckHelper helper)
	{
		andDo();
	}

	public bool LeaveColumnWithFlowBackwardInExpand()
	{
		return false;
	}
}
