using System;

namespace WizardOfOz.Witch.DataAccess;

internal delegate void ConsumeRows(Func<QueryResultProvider> getResultProvider, GetQueryResultDelegate getQueryResult, Func<CreateTemporaryNewRowDelegate> getCreateNewRow);
