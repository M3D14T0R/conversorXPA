using System;
using XPARuntimeCore.Box;
using XPARuntimeCore.Box.Data.Advanced;

namespace WizardOfOz.Witch.Engine;

internal class dummyTaskFlowRunner : TaskFlowRunner, ContextRunner
{
	public static dummyTaskFlowRunner Instance = new dummyTaskFlowRunner();

	public void Run(Action command)
	{
		command?.Invoke();
	}

	public void UserChangedValueReevaluateExpand()
	{
	}

	public bool IsNewRow()
	{
		return false;
	}

	public void GroupLeave(Group group)
	{
	}

	public void GroupEnter(Group group)
	{
	}

	public void InvokeComEvent(Command command, bool immediate, object[] args)
	{
	}

	public void ForEachObjectColumnEvent(ColumnBase comColumn, Action<string> doThis)
	{
	}

	public void RunInContext(Action command)
	{
		command();
	}

	public ContextInstance CreateContextInstance()
	{
		return DummyContextInstance.Instance;
	}

	public void AddDeltaOf(ColumnBase column, Action<Number> addValue, Func<Number> expression)
	{
		throw new InvalidOperationException("Add Delta Of is only valid in the context of a controller");
	}

	public void RefreshControl(Action refresh)
	{
	}
}
