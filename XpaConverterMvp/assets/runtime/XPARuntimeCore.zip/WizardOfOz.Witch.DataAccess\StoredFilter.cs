using System;
using System.Collections.Generic;
using XPARuntimeCore.Box;
using XPARuntimeCore.Box.Data;
using XPARuntimeCore.Box.Data.Advanced;

namespace WizardOfOz.Witch.DataAccess;

internal class StoredFilter
{
	private class myFilter : Filter
	{
		private class AddEqualFilterBase : FilterBase, FilterCondition
		{
			private ColumnBase _column;

			private ColumnFilterValue _to;

			public bool IsEmpty => false;

			public AddEqualFilterBase(ColumnBase column, ColumnFilterValue to)
			{
				_column = column;
				_to = to;
			}

			internal override FilterCondition GetFilterCondition()
			{
				return this;
			}

			public new void ApplyTo(Filter filter, bool supportWildCard)
			{
				filter.AddEqual(_column, _to);
			}
		}

		private Entity _referenceEntity;

		private bool _supportWildCard;

		private FilterCollection _filter = new FilterCollection();

		public myFilter(Entity referenceEntity, bool supportWildCard)
		{
			_supportWildCard = supportWildCard;
			_referenceEntity = referenceEntity;
		}

		public void AddBetweenCondition(ColumnBase column, ColumnFilterValue from, ColumnFilterValue to)
		{
			from.FixYourValue();
			to.FixYourValue();
			_filter.Add(delegate(Filter filter, bool supportWildCard)
			{
				filter.AddBetweenCondition(column, from, to);
			});
		}

		public void AddEqual(ColumnBase column, ColumnFilterValue to)
		{
			if (_referenceEntity != null && column.Entity != _referenceEntity)
			{
				to.IfYouBelongTo(_referenceEntity, delegate(ColumnBase x, ColumnFilterValue t)
				{
					to = t;
					column = x;
				});
			}
			to.FixYourValue();
			_filter.Add(new AddEqualFilterBase(column, to));
		}

		public void AddDifferent(ColumnBase column, ColumnFilterValue from)
		{
			from.FixYourValue();
			_filter.Add(delegate(Filter filter, bool supportWildCard)
			{
				filter.AddDifferent(column, from);
			});
		}

		public void AddStartsWith(ColumnBase column, ColumnFilterValue to)
		{
			to.FixYourValue();
			_filter.Add(delegate(Filter filter, bool supportWildCard)
			{
				filter.AddStartsWith(column, to);
			});
		}

		public void AddGreaterOrEqual(ColumnBase column, ColumnFilterValue to)
		{
			to.FixYourValue();
			_filter.Add(delegate(Filter filter, bool supportWildCard)
			{
				filter.AddGreaterOrEqual(column, to);
			});
		}

		public void AddLessOrEqual(ColumnBase column, ColumnFilterValue to)
		{
			to.FixYourValue();
			_filter.Add(delegate(Filter filter, bool supportWildCard)
			{
				filter.AddLessOrEqual(column, to);
			});
		}

		public void AddWhere(Action<TranslateToGatewayTerms, Action<string>> whereFactory)
		{
			List<WhereMeaningfullItem> r = new List<WhereMeaningfullItem>();
			string result = null;
			whereFactory(delegate(WhereMeaningfullItem item)
			{
				WhereMeaningfullItem whereMeaningfullItem = item;
				if (whereMeaningfullItem is ColumnBase columnBase)
				{
					ColumnFilterValue yourColumnFilterValue = columnBase.GetYourColumnFilterValue();
					yourColumnFilterValue.FixYourValue();
					whereMeaningfullItem = yourColumnFilterValue;
				}
				r.Add(whereMeaningfullItem);
				return "\0" + (r.Count - 1) + "\0";
			}, delegate(string s)
			{
				result = s;
			});
			_filter.Add(delegate(Filter filter, bool supportWildCard)
			{
				if (result != null)
				{
					filter.AddWhere(delegate(TranslateToGatewayTerms terms, Action<string> action)
					{
						string text = result;
						int num = 0;
						foreach (WhereMeaningfullItem item in r)
						{
							text = text.Replace("\0" + num++ + "\0", terms(item));
						}
						action(text);
					});
				}
			});
		}

		public void AddOr(FilterCondition a, FilterCondition b)
		{
			StoredFilter myA = new StoredFilter(a, _referenceEntity, _supportWildCard);
			StoredFilter myB = new StoredFilter(b, _referenceEntity, _supportWildCard);
			_filter.Add(delegate(Filter filter, bool supportWildCard)
			{
				filter.AddOr(myA.GetInnerFilter(), myB.GetInnerFilter());
			});
		}

		public void AddLessThan(ColumnBase column, ColumnFilterValue to)
		{
			to.FixYourValue();
			_filter.Add(delegate(Filter filter, bool supportWildCard)
			{
				filter.AddLessThan(column, to);
			});
		}

		public void AddGreaterThan(ColumnBase column, ColumnFilterValue to)
		{
			to.FixYourValue();
			_filter.Add(delegate(Filter filter, bool supportWildCard)
			{
				filter.AddGreaterThan(column, to);
			});
		}

		public void AddUserCondition(Func<bool> condition)
		{
			_filter.Add(delegate(Filter filter, bool supportWildCard)
			{
				filter.AddUserCondition(condition);
			});
		}

		public void AddLessOrEqualWithWildcard(TextColumn column, Text value, ColumnFilterValue filterItem)
		{
			_filter.Add(delegate(Filter filter, bool supportWildCard)
			{
				filter.AddLessOrEqualWithWildcard(column, value, filterItem);
			});
		}

		public void AddTrueCondition()
		{
			_filter.Add(delegate(Filter x, bool s)
			{
				x.AddTrueCondition();
			});
		}

		public void ApplyTo(Filter filter, bool supportWildCard)
		{
			_filter.ApplyTo(filter, supportWildCard);
		}

		public FilterCondition GetInnerFilter()
		{
			return _filter;
		}
	}

	private myFilter _filter;

	public FilterCondition GetInnerFilter()
	{
		return _filter.GetInnerFilter();
	}

	public StoredFilter(FilterCondition condition, Entity referenceEntity, bool supportWildCard)
	{
		_filter = new myFilter(referenceEntity, supportWildCard);
		condition.ApplyTo(_filter, supportWildCard);
	}

	public void ApplyTo(Filter filter, bool supportWildCard)
	{
		_filter.ApplyTo(filter, supportWildCard);
	}
}
