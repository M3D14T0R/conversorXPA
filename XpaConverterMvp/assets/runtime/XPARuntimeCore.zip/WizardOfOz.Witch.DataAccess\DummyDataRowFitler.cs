using System;
using XPARuntimeCore.Box;
using XPARuntimeCore.Box.Data;
using XPARuntimeCore.Box.Data.Advanced;

namespace WizardOfOz.Witch.DataAccess;

internal class DummyDataRowFitler : DataRowFilter, Filter
{
	public static DummyDataRowFitler Instance = new DummyDataRowFitler();

	public bool MatchesFilter => true;

	public void AddBetweenCondition(ColumnBase column, ColumnFilterValue from, ColumnFilterValue to)
	{
	}

	public void AddEqual(ColumnBase column, ColumnFilterValue to)
	{
	}

	public void AddDifferent(ColumnBase column, ColumnFilterValue from)
	{
	}

	public void AddStartsWith(ColumnBase column, ColumnFilterValue to)
	{
	}

	public void AddGreaterOrEqual(ColumnBase column, ColumnFilterValue to)
	{
	}

	public void AddLessOrEqual(ColumnBase column, ColumnFilterValue to)
	{
	}

	public void AddWhere(Action<TranslateToGatewayTerms, Action<string>> whereFactory)
	{
	}

	public void AddOr(FilterCondition a, FilterCondition b)
	{
	}

	public void AddLessThan(ColumnBase column, ColumnFilterValue to)
	{
	}

	public void AddGreaterThan(ColumnBase column, ColumnFilterValue to)
	{
	}

	public void AddUserCondition(Func<bool> condition)
	{
	}

	public void AddLessOrEqualWithWildcard(TextColumn column, Text value, ColumnFilterValue filterItem)
	{
	}

	public void AddTrueCondition()
	{
	}
}
