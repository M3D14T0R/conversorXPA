using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Net;
using ENV.Remoting.Data;
namespace ENV.Remoting
{
    public class CallRemoteRequest : Serializable
    {
        public static Func<object, string> ToJson = null;
        public static Func<Type, string, object> FromJson = null;
        public CallRemoteRequest(string url, string prgName = "")
        {
            _prgName = prgName;
            _sendAndRecieve = new CommunicationLayer(url).SendAndRecieve;
        }
        internal string _prgName = "";
        internal ArrayList _args = new ArrayList();
        internal Func<MemoryStream, Stream> _sendAndRecieve;
        public void AddArgument(object arg)
        {
            _args.Add(arg);
        }
        public object GetReturnedArgument(int index)
        {
            return _args[index];
        }
        byte[] _resultStream;
        public void Execute()
        {
            var s = new XPARuntimeCoreSerialization();
            s.AddSerializer("rr", l => new RequestResult(l));
            using (var ms = new MemoryStream())
            {
                s.Serialize(ms, this);
                this._resultStream = null;
                var resultStream = _sendAndRecieve(ms);
                var result = (RequestResult)s.Deserialize(resultStream);
                if (!result.Successful)
                    throw new Exception(result.ExceptionMessage);
                _args = new ArrayList((object[])result.ResultData);
                _resultStream = result.ResultStream;

            }
        }

        public CallRemoteRequest(Loader l)
        {
            _prgName = l.Get<string>();
            _args = new ArrayList(l.Get<object[]>());
        }

        public void SaveTo(Saver saver)
        {
            saver.SaveObjects(_prgName, _args.ToArray());
        }



        public T RunDTO<T>(params object[] args)
        {
            var sa = new SerializedArgs();
            foreach (var arg in args)
            {
                sa.Add(arg);

            }
            _args = new ArrayList() { sa };
            this.Execute();

            if (_args.Count == 1 && _args[0] is SerializedArgs)
                return (T)((SerializedArgs)_args[0]).Get(0, typeof(T));
            return default(T);
        }
    }
    internal class CommunicationLayer
    {
        public CommunicationLayer(string url)
        {
            _url = urlManager.GetUrlManagerFor(url);
        }
        urlManager _url;
        class urlManager
        {
            List<string> _availableUrls = new List<string>();
            public urlManager(string url)
            {
                _availableUrls.AddRange(url.Split(','));
            }


            [ThreadStatic]
            static Dictionary<string, urlManager> _managers = new Dictionary<string, urlManager>();
            public static urlManager GetUrlManagerFor(string url)
            {
                if (_managers == null)
                    _managers = new Dictionary<string, urlManager>();
                urlManager result;
                if (!_managers.TryGetValue(url, out result))
                {
                    result = new urlManager(url);
                    _managers.Add(url, result);
                }
                return result;
            }

            int _lastOkItem = 0;
            public WebResponse GetResponse(Action<WebRequest> whatToDoToTheRequest)
            {

                Exception lastException = null;
                for (int i = 0; i < _availableUrls.Count; i++)
                {
                    try
                    {
                        var r = WebRequest.Create(_availableUrls[_lastOkItem]);
                        whatToDoToTheRequest(r);
                        return r.GetResponse();
                    }
                    catch (Exception e)
                    {
                        lastException = e;
                        ReportError(e, "Remote Request Failed For URL - " + _availableUrls[_lastOkItem]);
                        _lastOkItem++;
                        if (_lastOkItem >= _availableUrls.Count)
                            _lastOkItem = 0;
                    }
                }
                throw lastException;



            }
        }
        internal static Action<Exception, string> ReportError = delegate { };

        public Stream SendAndRecieve(MemoryStream ms)
        {
            var webResponse = _url.GetResponse(rr =>
            {
                rr.Method = "POST";
                rr.Proxy = null;
                rr.Timeout = System.Threading.Timeout.Infinite;
                using (var content = rr.GetRequestStream())
                {
                    ms.WriteTo(content);

                }
            });

            var rs = webResponse.GetResponseStream();
            int count = 0;
            if (true)
            {
                var ms2 = new MemoryStream();
                int v;

                while ((v = rs.ReadByte()) > -1)
                {
                    count++;
                    ms2.WriteByte((byte)v);
                }
                ms2.Position = 0;
                rs = ms2;
            }
            return rs;
        }
    }
    [Serializable]
    public class RequestResult : Serializable
    {
        object _resultData;
        public object ResultData
        {
            get { return _resultData; }
        }

        long _messageId;
        public long MessageId
        {
            get { return _messageId; }
        }

        bool _successful;
        public bool Successful { get { return _successful; } }

        string _exceptionMessage;

        public string ExceptionMessage
        {
            get { return _exceptionMessage; }
        }

        byte[] _resultStream;
        public byte[] ResultStream
        {
            get { return _resultStream; }
        }

        public RequestResult(long messageId)
        {

            _messageId = messageId;

        }
        public RequestResult(Loader l)
        {
            _resultData = l.Get<object>();
            var r = l.Get<object[]>();
            if (r == null)
                _resultStream = null;
            else
                _resultStream = Array.ConvertAll(r, x => (byte)x);
            _messageId = (int)l.Get<long>();
            _exceptionMessage = l.Get<string>();
            _successful = l.Get<bool>();
        }
        public void SaveTo(Saver saver)
        {
            saver.SaveObjects(_resultData, this._resultStream, this._messageId,
                this._exceptionMessage, this._successful);
        }
        public void Success(object resultData, byte[] resultStream)
        {
            _resultData = resultData;
            _resultStream = resultStream;
            _successful = true;
        }

        public void Failed(Exception e)
        {

            _exceptionMessage = e.Message;
        }
    }

    public class SerializedArgs : Serializable
    {



        List<string> _args = new List<string>();
        public SerializedArgs() { }
        public SerializedArgs(Loader l)
        {
            foreach (var item in l.Get<object[]>())
            {
                _args.Add((string)item);

            }
        }
        public void Add(object o)
        {
            _args.Add(CallRemoteRequest.ToJson(o));
        }

        public void SaveTo(Saver saver)
        {
            saver.Save(_args.ToArray());
        }

        internal object Get(int j, Type parameterType)
        {
            if (j >= _args.Count)
                return null;
            return CallRemoteRequest.FromJson(parameterType, _args[j]);
        }
    }
}
