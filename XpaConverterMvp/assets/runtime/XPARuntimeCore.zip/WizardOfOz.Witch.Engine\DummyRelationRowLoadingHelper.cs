using System;
using WizardOfOz.Witch.DataAccess;

namespace WizardOfOz.Witch.Engine;

internal class DummyRelationRowLoadingHelper : RelationRowLoadingHelper
{
	public static DummyRelationRowLoadingHelper Instance = new DummyRelationRowLoadingHelper();

	public void OnRowLoaded(object context, DataProviderRow row, Action resetDataToColumns)
	{
	}

	public void OnRowUnLoaded(DataProviderRow row)
	{
	}

	public bool LockAllRows(bool isForRelation)
	{
		return false;
	}
}
