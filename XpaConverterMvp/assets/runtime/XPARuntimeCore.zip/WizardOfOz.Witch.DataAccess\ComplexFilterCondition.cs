namespace WizardOfOz.Witch.DataAccess;

internal interface ComplexFilterCondition : FilterCondition
{
	ComplexFilterCondition Or(FilterCondition filter);

	ComplexFilterCondition And(FilterCondition filter);
}
