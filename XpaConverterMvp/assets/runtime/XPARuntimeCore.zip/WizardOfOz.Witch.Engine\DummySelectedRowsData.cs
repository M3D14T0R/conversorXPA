using System;

namespace WizardOfOz.Witch.Engine;

internal class DummySelectedRowsData : SelectedRowsData, SelectedRows
{
	public static DummySelectedRowsData Instance = new DummySelectedRowsData();

	private DummySelectedRowsData()
	{
	}

	public int GetCurrentIndex()
	{
		return -1;
	}

	public void StopIteration()
	{
	}

	public void Clear()
	{
	}

	public void Iterate(Action runForEachRow)
	{
		runForEachRow();
	}

	public int GetCount()
	{
		return 0;
	}
}
