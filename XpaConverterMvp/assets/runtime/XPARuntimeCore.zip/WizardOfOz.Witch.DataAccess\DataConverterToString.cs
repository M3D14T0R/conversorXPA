using XPARuntimeCore.Box.Data.DataProvider;

namespace WizardOfOz.Witch.DataAccess;

internal interface DataConverterToString
{
	string Convert(IFilterItem item);
}
