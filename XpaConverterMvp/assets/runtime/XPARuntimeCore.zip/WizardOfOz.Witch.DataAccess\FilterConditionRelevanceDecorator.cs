namespace WizardOfOz.Witch.DataAccess;

internal class FilterConditionRelevanceDecorator : FilterCondition
{
	private FilterCondition _baseFilter;

	private IdentifierProvider _includeColumn;

	public bool IsEmpty => false;

	public FilterConditionRelevanceDecorator(FilterCondition baseFilter, IdentifierProvider includeColumn)
	{
		_baseFilter = baseFilter;
		_includeColumn = includeColumn;
	}

	public void ApplyTo(Filter filter, bool supportWildCard)
	{
		_baseFilter.ApplyTo(new FilterRelevanceDecorator(filter, _includeColumn), supportWildCard);
	}
}
