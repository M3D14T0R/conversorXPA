using System;
using System.Drawing;
using System.Windows.Forms;
using XPARuntimeCore.Box;
using XPARuntimeCore.Box.Advanced;
using XPARuntimeCore.Box.Data.Advanced;
using XPARuntimeCore.Box.UI;
using XPARuntimeCore.Box.UI.Advanced;
using WizardOfOz.Witch.DataAccess;
using WizardOfOz.Witch.UI;

namespace WizardOfOz.Witch.Engine;

internal class DummyTaskForForm : TaskForForm
{
	public void IncrementalSearch(Func<FilterCondition> byValue, ColumnBase column)
	{
	}

	public void HandleMouseHit(Control control, Point location, Action dispatchToWindows, Action sendMouseUp)
	{
		dispatchToWindows();
	}

	public void AutoSkipToNextColumn(char lastChar)
	{
	}

	public void AddMultipleRowsControl(GridForTask control)
	{
	}

	public void UserStartedEditing()
	{
	}

	public bool Has(ColumnBase column)
	{
		return false;
	}

	public bool TaskHasEnded()
	{
		return false;
	}

	public SelectedRowsData GetSelectedRowsData()
	{
		return null;
	}

	public SelectedRows GetSelectedRows()
	{
		return null;
	}

	public void RowWasChanged()
	{
	}

	public void Raise(Command e, IControl control, Action defaultAction)
	{
		defaultAction();
	}

	public void HandleCommand(Command command, object[] args, ControlBase sender, Action<CommandHandling> handle)
	{
	}

	public void ControlEditingEndedWithoutLeave()
	{
	}

	public bool IsExpandable(IControl control)
	{
		return false;
	}

	public void ClearBeforeControlClickCommand()
	{
	}

	public object GetContext()
	{
		return null;
	}

	public void InvokeOnUIThread(Action action)
	{
		action();
	}

	public void InvokeOnLogicThread(Action action)
	{
		action();
	}

	public void Enqueue(Action action)
	{
		action();
	}

	public void ReevaluateExpand()
	{
	}

	public void RefreshPartialView(Action refreshOnlyRelevantStuff)
	{
		refreshOnlyRelevantStuff();
	}

	public void CheckStateInCallStack(TaskStateInCallStackVisitor check)
	{
	}

	public bool FocusIsAllowedForAllControls()
	{
		return false;
	}

	public void SetAsFocusedContext()
	{
	}

	public void ExpandAttemptedOnNonFocusableControl()
	{
	}

	public void InnerTextBoxClicked()
	{
	}

	public void WrapTextBoxCursorMovementCommnad(Action action)
	{
		action();
	}

	public void MouseDownOnControlSentToWindows()
	{
	}

	public void SendCurrentRowTo(Action<DataProviderRow> action)
	{
	}

	public void BeginInvoke(Action action)
	{
		action();
	}

	public void RunInFlowContext(Action action, FlowActionVisitor flowActionVisitor)
	{
		action();
	}

	public void RunHandlers(KeyCombination key, ControlBase controlBase, Action defaultAction)
	{
	}

	public bool IsCurrentInCallStack()
	{
		return false;
	}

	public void ReloadSubFormInActiveTask(SubForm subForm)
	{
	}

	public void EnqueueAsFirst(Action action)
	{
		action();
	}

	public void HandleCloseFormByUser(Action handled)
	{
	}

	public void TabOrderChanged()
	{
	}

	public void ActivateOnDisplay(Action activate)
	{
		activate();
	}

	public void DoWhileCurrentHandledKeyIs(string key, Action action)
	{
		action();
	}
}
