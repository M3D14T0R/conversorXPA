namespace WizardOfOz.Witch.Engine;

internal class DummyReomputeItemChangedChecker : ReomputeItemChangedChecker
{
	public bool HasChanged()
	{
		return false;
	}
}
