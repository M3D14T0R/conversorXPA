using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;

using System.Text;


namespace ENV.Remoting.Data
{
    public class XPARuntimeCoreSerialization : Formatter
    {
        Serial _null = new Serial { SerializerTool = new NullSerializer(), Id = "n" }, _array = new Serial { SerializerTool = new ArraySerializer(), Id = "_a" };
        public XPARuntimeCoreSerialization()
        {
            _idDic.Add(_null.Id, _null);
            _idDic.Add(_array.Id, _array);
            AddSerializer<int>("_i", new IntSerializer());
            AddSerializer<bool>("_b", new BoolSerializer());
            AddSerializer<byte>("_by", new ByteSerializer());
            AddSerializer<decimal>("_d", new DecimalSerializer());
            AddSerializer<string>("_s", new StringSerializer());
            AddSerializer<System.Type>("_t", new TypeSerializer(this));
            AddSerializer<Guid>("_g", new GuidSerializer());
            AddSerializer<Hashtable>("_h", new HashtableSerializer());
            AddSerializer<DateTime>("_dt", new DatetimeSerializer());
            AddSerializer<long>("_l", new LongSerializer());
            AddSerializer(l => new CallRemoteRequest(l));
            AddSerializer(l=>new SerializedArgs(l));
            AddSerializer("dict_s_o", (x, s) =>
            {
                s.Save(x.Count);
                foreach (var y in x)
                {
                    s.Save(y.Key);
                    s.Save(y.Value);
                }
            }, l =>
            {
                var x = new Dictionary<string, object>();
                var c = l.Get<int>();
                for (int i = 0; i < c; i++)
                {
                    x.Add(l.Get<string>(), l.Get<object>());
                }
                return x;
            }

            );
        }
        class TypeSerializer : SerializerTool
        {
            XPARuntimeCoreSerialization _parent;

            public TypeSerializer(XPARuntimeCoreSerialization parent)
            {
                _parent = parent;
            }

            public void Save(object o, Saver saver)
            {
                var t = (System.Type)o;
                saver.SaveValue(_parent._typeDic[t].Id);
            }

            public object Load(Loader loader)
            {
                return _parent._idDic[loader.Get<string>()].Type;
            }
        }
        class Serial
        {
            public SerializerTool SerializerTool;
            public string Id;
            public Type Type;

        }

        Dictionary<Type, Serial> _typeDic = new Dictionary<Type, Serial>();
        Dictionary<string, Serial> _idDic = new Dictionary<string, Serial>();

        public void AddSerializer<T>(string id, Func<Loader, T> factory) where T : Serializable
        {
            AddSerializer<T>(id, new SerializableSerializer(x => factory(x)));
        }
        public void AddSerializer<T>(Func<Loader, T> factory) where T : Serializable
        {
            AddSerializer<T>(typeof(T).Name, new SerializableSerializer(x => factory(x)));
        }
        public void AddSerializer<T>(string id, Action<T, Saver> save, Func<Loader, T> factory)
        {
            AddSerializer<T>(id, new ArrowSerializer(x => factory(x),(o,s )=>save((T)o,s)));
        }
        class ArrowSerializer : SerializerTool
        {
            Func<Loader, object> _factory;
            Action<object, Saver> _save;

            public ArrowSerializer(Func<Loader, object> factory, Action<object, Saver> save)
            {
                _factory = factory;
                _save = save;
            }

            public void Save(object o, Saver saver)
            {
                _save(o, saver);
            }

            public object Load(Loader loader)
            {
                return _factory(loader);
            }
        }
        internal void Replace<T>(Func<Loader, T> factory) where T : Serializable
        {
            var x = _idDic[typeof(T).Name];
            x.SerializerTool = new SerializableSerializer(l => factory(l));
        }

        internal void AddSerializer<T>(string id, SerializerTool serializerTool)
        {
            AddSerializer(id, serializerTool, typeof(T));

        }
        internal void AddSerializer(string id, SerializerTool serializerTool, System.Type type)
        {
            var s = new Serial
            {
                SerializerTool = serializerTool,
                Id = id,
                Type = type
            };
            _typeDic.Add(type, s);
            _idDic.Add(id, s);

        }
        class SerializableSerializer : SerializerTool
        {
            Func<Loader, object> _factory;

            public SerializableSerializer(Func<Loader, object> factory)
            {
                _factory = factory;
            }

            public void Save(object o, Saver saver)
            {
                ((Serializable)o).SaveTo(saver);
            }

            public object Load(Loader loader)
            {
                return _factory(loader);
            }
        }

        public void Serialize(Stream stream, object o)
        {

            var sw = new StreamWriter(stream);
            {

                var s = new MySaver(sw, this);
                s.Save(o);
            }
            sw.Flush();



        }
        public object Deserialize(Stream s)
        {
            var l = new myLoader(new StreamReader(s), this);
            return l.Get<object>();

        }

        internal void AddSerializer<T>()
        {
            var fields = typeof(T).GetFields(System.Reflection.BindingFlags.Public | System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);
            AddSerializer<T>(typeof(T).Name, (x, s) => s.Save(Array.ConvertAll(fields, field => field.GetValue(x))), l =>
            {
                var result = (T)System.Activator.CreateInstance(typeof(T));
                foreach (var field in fields)
                {
                    field.SetValue(result, l.Get<object>());
                }
                return result;

            });
        }

        class MySaver : Saver
        {
            TextWriter sw;
            XPARuntimeCoreSerialization _parent;

            public MySaver(TextWriter sw, XPARuntimeCoreSerialization parent)
            {
                _parent = parent;
                this.sw = sw;
            }

            public void SaveValue(string s)
            {
                if (s.Contains("\"") || s.Contains(","))
                    sw.Write("\"" + s.Replace("\"", "\"\"") + "\"");
                else
                    sw.Write(s);
                sw.Write(",");
            }

            public void Save(object o)
            {
                if (o == null)
                {
                    SaveType(_parent._null.Id);
                }
                else
                {
                    var t = o.GetType();
                    if (t.IsArray)
                    {
                        SaveType(_parent._array.Id);
                        _parent._array.SerializerTool.Save(o, this);
                    }
                    else
                    {
                        if (o is System.Type)
                            t = typeof(System.Type);
                        Serial x;
                        if (_parent._typeDic.TryGetValue(t, out x))
                        {
                            SaveType(x.Id);
                            x.SerializerTool.Save(o, this);
                        }
                        else
                            throw new Exception("Cannot serialize object of type " + t.ToString());
                    }

                }
            }

            public void SaveObjects(params object[] o)
            {
                foreach (var o1 in o)
                {
                    Save(o1);
                }
            }

            void SaveType(string id)
            {
                sw.Write(id);
                sw.Write(",");
            }
        }
        class myLoader : Loader
        {
            TextReader r;
            XPARuntimeCoreSerialization _parent;
            public myLoader(TextReader r, XPARuntimeCoreSerialization parent)
            {
                _parent = parent;
                this.r = r;
            }
            string GetNextItem()
            {
                var sw = new StringBuilder();
                bool quoted = r.Peek() == (int)'\"';
                if (quoted)
                    r.Read();
                int i = 0;

                while (true)
                {
                    i = r.Read();
                    if (quoted)
                    {
                        switch (i)
                        {
                            case -1:
                                throw new Exception("wasn't suposed to end");
                            case '"':
                                var x = r.Read();
                                switch (x)
                                {
                                    case ',':
                                        return sw.ToString();
                                    case '"':
                                        sw.Append('"');
                                        break;
                                    default:
                                        throw new Exception("wasn't suposed to get " + (char)x + " after quote");

                                }
                                break;
                            default:
                                sw.Append((char)i);
                                break;
                        }
                    }
                    else
                        switch (i)
                        {
                            case -1:
                                throw new Exception("wasn't suposed to end");
                            case ',':
                                return sw.ToString();
                            default:
                                sw.Append((char)i);
                                break;
                        }
                }



            }

            public string GetValue()
            {
                return GetNextItem();
            }

            public T Get<T>()
            {
                var x = _parent._idDic[GetId()];
                var r = x.SerializerTool.Load(this);
                return (T)r;
            }



            string GetId()
            {
                return GetNextItem();
            }
        }

    }
    class IntSerializer : SerializerTool
    {
        public void Save(object o, Saver saver)
        {
            int i = (int)o;
            saver.SaveValue(i.ToString());
        }

        public object Load(Loader loader)
        {
            return int.Parse(loader.GetValue());
        }
    }
    class BoolSerializer : SerializerTool
    {
        public void Save(object o, Saver saver)
        {
            var i = (bool)o;
            saver.SaveValue(i ? "t" : "f");
        }

        public object Load(Loader loader)
        {
            return loader.GetValue() == "t";
        }
    }
    class LongSerializer : SerializerTool
    {
        public void Save(object o, Saver saver)
        {
            var i = (long)o;
            saver.SaveValue(i.ToString());
        }

        public object Load(Loader loader)
        {
            return long.Parse(loader.GetValue());
        }
    }
    class ByteSerializer : SerializerTool
    {
        public void Save(object o, Saver saver)
        {
            byte i = (byte)o;
            saver.SaveValue(i.ToString());
        }

        public object Load(Loader loader)
        {
            return byte.Parse(loader.GetValue());
        }
    }
    class DecimalSerializer : SerializerTool
    {
        public void Save(object o, Saver saver)
        {
            decimal i = (decimal)o;
            saver.SaveValue(i.ToString(CultureInfo.InvariantCulture));
        }

        public object Load(Loader loader)
        {
            return decimal.Parse(loader.GetValue());
        }
    }
    class StringSerializer : SerializerTool
    {
        public void Save(object o, Saver saver)
        {
            saver.SaveValue(o.ToString().TrimEnd());
        }

        public object Load(Loader loader)
        {
            return loader.GetValue();
        }
    }
    class NullSerializer : SerializerTool
    {
        public void Save(object o, Saver saver)
        {

        }

        public object Load(Loader loader)
        {
            return null;
        }
    }

    class GuidSerializer : SerializerTool
    {
        public void Save(object o, Saver saver)
        {
            var g = (Guid)o;
            saver.SaveValue(g.ToString());
        }

        public object Load(Loader loader)
        {
            return new Guid(loader.GetValue());
        }
    }
    class DatetimeSerializer : SerializerTool
    {
        public void Save(object o, Saver saver)
        {
            var g = (DateTime)o;
            saver.Save(g.ToBinary());
        }

        public object Load(Loader loader)
        {
            return DateTime.FromBinary(loader.Get<long>());
        }
    }
    class ArraySerializer : SerializerTool
    {
        public void Save(object o, Saver saver)
        {
            var x = (Array)o;
            var l = x.Length;
            saver.Save(l);
            for (int i = 0; i < l; i++)
            {
                saver.Save(x.GetValue(i));
            }
        }

        public object Load(Loader loader)
        {
            object[] x = new object[loader.Get<int>()];
            for (int i = 0; i < x.Length; i++)
            {
                x[i] = loader.Get<object>();
            }
            return x;

        }
    }
    class HashtableSerializer : SerializerTool
    {
        public void Save(object o, Saver saver)
        {
            var x = (Hashtable)o;
            int i = x.Count;
            saver.Save(i);

            foreach (DictionaryEntry y in x)
            {
                saver.SaveObjects(y.Key, y.Value);

            }

        }

        public object Load(Loader loader)
        {
            var x = new Hashtable();
            var l = loader.Get<int>();
            for (int i = 0; i < l; i++)
            {
                x.Add(loader.Get<object>(), loader.Get<object>());
            }
            return x;
        }
    }

    internal interface SerializerTool
    {
        void Save(object o, Saver saver);
        object Load(Loader loader);
    }
    public interface Serializable
    {
        void SaveTo(Saver saver);
    }
    public interface Saver
    {
        void SaveValue(string s);
        void Save(object o);
        void SaveObjects(params object[] o);
    }
    public interface Loader
    {
        string GetValue();
        T Get<T>();
    }
}
namespace ENV.Remoting
{
    public interface Formatter
    {
        object Deserialize(Stream stream);
        void Serialize(Stream stream, object item);
    }

}
