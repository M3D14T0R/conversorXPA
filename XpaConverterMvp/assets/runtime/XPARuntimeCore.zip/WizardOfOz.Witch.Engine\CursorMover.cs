using WizardOfOz.Witch.DataAccess;

namespace WizardOfOz.Witch.Engine;

internal interface CursorMover
{
	bool Move(Cursor cursor, bool validCurrentRow);

	void MoveOne(GridParkedRow parkedRow);

	bool ShouldCreateANewRowIfAtEnd();

	CursorMover Reverse();

	CursorMover AfterRowWasDeleted();

	bool ShouldMoveBackOneRowAfterCurrentRowIsRemoved();

	CursorMover NewRowWasNotFoundWhereItWasSupposedToBe();
}
