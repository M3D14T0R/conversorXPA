using System;
using System.Collections.Generic;
using XPARuntimeCore.Box;
using XPARuntimeCore.Box.Data;
using XPARuntimeCore.Box.Data.Advanced;
using WizardOfOz.Witch.Engine;

namespace WizardOfOz.Witch.DataAccess;

internal class FilterOnColumns : Filter
{
	private RecomputeManager.RowInitializer _initializer;

	private bool _ignoreCase;

	private bool _matchesFilter = true;

	private bool _supportWildCard;

	private IdentifierProvider _identifier;

	private bool _isEmpty = true;

	private List<Action> _calculateSteps = new List<Action>();

	private bool MatchesFilter
	{
		get
		{
			return _matchesFilter;
		}
		set
		{
			if (_matchesFilter && !value)
			{
				_matchesFilter = false;
			}
		}
	}

	public bool IsEmpty => _isEmpty;

	public FilterOnColumns(RecomputeManager.RowInitializer initializer, bool ignoreCase, bool supportWildCard, IdentifierProvider identifierForFilterExpression)
	{
		_identifier = identifierForFilterExpression;
		_supportWildCard = supportWildCard;
		_initializer = initializer;
		_ignoreCase = ignoreCase;
	}

	public bool GetIsTrue()
	{
		_matchesFilter = true;
		for (int i = 0; i < _calculateSteps.Count; i++)
		{
			_calculateSteps[i]();
			if (!_matchesFilter)
			{
				return false;
			}
		}
		return MatchesFilter;
	}

	private void Add(Action what)
	{
		if (_isEmpty)
		{
			_isEmpty = false;
		}
		_calculateSteps.Add(what);
	}

	public void AddBetweenCondition(ColumnBase column, ColumnFilterValue from, ColumnFilterValue to)
	{
		Add(delegate
		{
			InitToColumn(column);
			MatchesFilter = column.AlwaysMatchInMemoryFilter() || ((from.CompareToCurrentValueOfColumn() <= 0 || from.IsNull()) && to.CompareToCurrentValueOfColumn() >= 0);
		});
	}

	private void InitToColumn(ColumnBase column)
	{
		if (MatchesFilter)
		{
			_initializer.ComputeUntil(column);
		}
	}

	public void AddEqual(ColumnBase column, ColumnFilterValue to)
	{
		Add(delegate
		{
			InitToColumn(column);
			MatchesFilter = column.AlwaysMatchInMemoryFilter() || to.IsEqualToCurrentValueOfColumn(_ignoreCase);
		});
	}

	public void AddDifferent(ColumnBase column, ColumnFilterValue from)
	{
		Add(delegate
		{
			InitToColumn(column);
			MatchesFilter = column.AlwaysMatchInMemoryFilter() || !from.IsEqualToCurrentValueOfColumn(_ignoreCase);
		});
	}

	public void AddStartsWith(ColumnBase column, ColumnFilterValue to)
	{
		Add(delegate
		{
			InitToColumn(column);
			MatchesFilter = column.AlwaysMatchInMemoryFilter() || to.CompareIfCurrentValueStartsWithYourValue(_ignoreCase);
		});
	}

	public void AddGreaterOrEqual(ColumnBase column, ColumnFilterValue to)
	{
		Add(delegate
		{
			InitToColumn(column);
			MatchesFilter = column.AlwaysMatchInMemoryFilter() || to.IsNull() || to.CompareToCurrentValueOfColumn() <= 0;
		});
	}

	public void AddLessOrEqual(ColumnBase column, ColumnFilterValue to)
	{
		Add(delegate
		{
			InitToColumn(column);
			MatchesFilter = column.AlwaysMatchInMemoryFilter() || to.IsNull() || to.CompareToCurrentValueOfColumn() >= 0;
		});
	}

	public void AddWhere(Action<TranslateToGatewayTerms, Action<string>> whereFactory)
	{
	}

	public void AddOr(FilterCondition a, FilterCondition b)
	{
		FilterOnColumns filterA = new FilterOnColumns(_initializer, _ignoreCase, _supportWildCard, _identifier);
		FilterOnColumns filterB = new FilterOnColumns(_initializer, _ignoreCase, _supportWildCard, _identifier);
		Add(delegate
		{
			a.ApplyTo(filterA, _supportWildCard);
			bool isTrue = filterA.GetIsTrue();
			if (!isTrue)
			{
				b.ApplyTo(filterB, _supportWildCard);
			}
			MatchesFilter = isTrue || filterB.GetIsTrue();
		});
	}

	public void AddLessThan(ColumnBase column, ColumnFilterValue to)
	{
		Add(delegate
		{
			InitToColumn(column);
			MatchesFilter = column.AlwaysMatchInMemoryFilter() || to.IsNull() || to.CompareToCurrentValueOfColumn() > 0;
		});
	}

	public void AddGreaterThan(ColumnBase column, ColumnFilterValue to)
	{
		Add(delegate
		{
			InitToColumn(column);
			MatchesFilter = column.AlwaysMatchInMemoryFilter() || to.IsNull() || to.CompareToCurrentValueOfColumn() < 0;
		});
	}

	public void AddUserCondition(Func<bool> condition)
	{
		Add(delegate
		{
			if (MatchesFilter)
			{
				MatchesFilter = _initializer.ComputeExpression(condition, _identifier);
			}
		});
	}

	public void AddLessOrEqualWithWildcard(TextColumn column, Text value, ColumnFilterValue filterItem)
	{
		Add(delegate
		{
			InitToColumn(column);
			MatchesFilter = column.AlwaysMatchInMemoryFilter() || (bool)(column.Value.Substring(0, value.Length) <= value);
		});
	}

	public void AddTrueCondition()
	{
		Add(delegate
		{
			MatchesFilter = true;
		});
	}
}
