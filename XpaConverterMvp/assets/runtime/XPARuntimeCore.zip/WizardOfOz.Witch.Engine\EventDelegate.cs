namespace WizardOfOz.Witch.Engine;

internal delegate void EventDelegate(EventHandler eventHandler);
