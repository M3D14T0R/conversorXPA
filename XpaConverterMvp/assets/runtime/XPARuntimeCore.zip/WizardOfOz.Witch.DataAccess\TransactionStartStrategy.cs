using System;
using XPARuntimeCore.Box.Engine;

namespace WizardOfOz.Witch.DataAccess;

internal interface TransactionStartStrategy
{
	void StartTransaction(TaskRunContext context, bool checkLocking, Action yes);

	void ApplyLockingStrategy(Action yes);

	void CheckThatLockingIsInATransaction(Action yes);
}
