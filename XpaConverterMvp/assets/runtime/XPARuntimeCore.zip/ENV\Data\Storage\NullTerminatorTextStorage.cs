using ENV.Data.DataProvider;
using XPARuntimeCore.Box;
using XPARuntimeCore.Box.Data.DataProvider;

namespace ENV.Data.Storage
{
    public class NullTerminatorTextStorage : IColumnStorageSrategy<Text>
    {
        int _maxLength = -1;

        public NullTerminatorTextStorage()
        {
        }

        public NullTerminatorTextStorage(int maxLength)
        {
            _maxLength = maxLength;
        }

        public Text LoadFrom(IValueLoader loader)
        {
            if (loader.IsNull())
                return null;
            return loader.GetString().TrimEnd('\0');
        }

        public void SaveTo(Text value, IValueSaver saver)
        {
            if (ReferenceEquals(value, null))
                saver.SaveNull();
            else
            {
                var btrieveSaver = saver as IBtrieveValueSaver;
                if (btrieveSaver != null)
                    btrieveSaver.SaveNullTerminatedAnsiString(value, _maxLength > -1 ? _maxLength : value.Length);
                else
                    saver.SaveAnsiString(value + '\0', value.Length + 1, false);
            }
        }
    }
}
