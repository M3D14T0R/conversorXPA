namespace WizardOfOz.Witch.DataAccess;

internal interface InternalFilterCollector
{
	void Add(FilterCondition condition);

	void Add(string where, params object[] columnsAndValuesToFilter);
}
