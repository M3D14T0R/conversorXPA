namespace WizardOfOz.Witch.DataAccess;

internal delegate void FilterConditionDelegate(Filter filter, bool supportWildCard);
