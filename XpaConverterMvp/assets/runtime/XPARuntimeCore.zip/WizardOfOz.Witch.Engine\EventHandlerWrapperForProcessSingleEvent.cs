using System;

namespace WizardOfOz.Witch.Engine;

internal delegate EventHandler EventHandlerWrapperForProcessSingleEvent(EventHandler original, Action reEnqueueEvent);
