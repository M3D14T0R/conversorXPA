using XPARuntimeCore.Box;
using XPARuntimeCore.Box.Data.Advanced;
using XPARuntimeCore.Box.Data.DataProvider;

namespace WizardOfOz.Witch.DataAccess;

internal interface ColumnDataInRow : IValue
{
	void SetColumnAcordingToYourValue(bool updateUI);

	void IfYouWereUpdatedAddColumnsTo(UpdateHelper helper);

	void SaveCurrentValuesAsOriginalValues();

	bool IsEqualTo(ColumnDataInRow value);

	void AddInfoTo(RowWasChangedHelper ex, ColumnDataInRow columnDataInRow);

	void AddEqualToColumn(ColumnBase column, InternalFilterCollector collector);

	int CompareValueTo(ColumnFilterValue to);

	bool ValueStartsWith(ColumnFilterValue to);

	bool IsSubstringLessOrEqualTo(Text value);
}
