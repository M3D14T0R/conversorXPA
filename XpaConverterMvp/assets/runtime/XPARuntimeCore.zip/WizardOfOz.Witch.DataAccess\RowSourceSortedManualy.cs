using System;
using System.Collections.Generic;
using XPARuntimeCore.Box;
using XPARuntimeCore.Box.Advanced;
using WizardOfOz.Witch.Types;

namespace WizardOfOz.Witch.DataAccess;

internal class RowSourceSortedManualy : ResetableQueryResult, IDisposable
{
	private class myRow
	{
		internal class Comparer : IComparer<myRow>
		{
			private List<int> _multipliers = new List<int>();

			public int Compare(myRow x, myRow y)
			{
				int num = 0;
				foreach (int multiplier in _multipliers)
				{
					int num2 = XPARuntimeCore.Box.Advanced.Comparer.Compare(x._compareValues[num], y._compareValues[num]) * multiplier;
					num++;
					if (num2 != 0)
					{
						return num2;
					}
				}
				return x._order.CompareTo(y._order) * ((!x._sort.Reversed) ? 1 : (-1));
			}

			public void AddSortColumn(bool descending)
			{
				_multipliers.Add((!descending) ? 1 : (-1));
			}
		}

		private DataProviderRow _row;

		private DataType[] _compareValues;

		private int _order;

		private Sort _sort;

		public myRow(DataProviderRow row, Sort sort, int order)
		{
			_order = order;
			_row = row;
			_sort = sort;
			UpdateValues();
		}

		public DataProviderRow GetDataRow()
		{
			return _row;
		}

		public void UpdateValues()
		{
			List<DataType> list = new List<DataType>();
			foreach (SortSegment segment in _sort.Segments)
			{
				list.Add(segment.Column.GetCurrentValue());
			}
			_compareValues = list.ToArray();
		}
	}

	private List<myRow> _rows;

	private ApplyRowToColumnsForManualSort _applyRowToColumns;

	private myRow.Comparer _c;

	private Sort _sort;

	private RowsProgressHandler _sorting;

	private bool _ignoreReset = true;

	private IEnumerator<myRow> _enumerator;

	private List<myRow> _deletedRows = new List<myRow>();

	private List<myRow> _newRows = new List<myRow>();

	public DataProviderRow Current => _enumerator.Current.GetDataRow();

	public RowSourceSortedManualy(Sort sort, ApplyRowToColumnsForManualSort applyRowToColumns, RowsProgressHandler sorting)
	{
		_sorting = sorting;
		_applyRowToColumns = applyRowToColumns;
		_sort = sort;
		if (sort.Reversed)
		{
			sort = sort.CreateReversedSortBySegment();
		}
		_c = new myRow.Comparer();
		foreach (SortSegment segment in sort.Segments)
		{
			_c.AddSortColumn(segment.Direction == SortDirection.Descending);
		}
	}

	public bool MoveNext()
	{
		_ignoreReset = false;
		return _enumerator.MoveNext();
	}

	public bool TryResetAndReturnFalseIfNotSupported()
	{
		if (_rows == null || _ignoreReset)
		{
			return true;
		}
		foreach (myRow newRow in _newRows)
		{
			_applyRowToColumns(newRow.GetDataRow(), delegate
			{
			});
			newRow.UpdateValues();
			_rows.Add(newRow);
		}
		foreach (myRow deletedRow in _deletedRows)
		{
			_rows.Remove(deletedRow);
		}
		_newRows.Clear();
		_deletedRows.Clear();
		_rows.Sort(_c);
		Dispose();
		_enumerator = _rows.GetEnumerator();
		return true;
	}

	public void RemoveRow(DataProviderRow row)
	{
		foreach (myRow row2 in _rows)
		{
			if (row2.GetDataRow().IsEqualTo(row))
			{
				_deletedRows.Add(row2);
			}
		}
		_newRows.RemoveAll((myRow myRow2) => myRow2.GetDataRow().IsEqualTo(row));
		_ignoreReset = false;
	}

	public void InsertRow(DataProviderRow row)
	{
		_newRows.Add(new myRow(row, _sort, int.MaxValue));
		_ignoreReset = false;
	}

	public void Dispose()
	{
		if (_enumerator != null)
		{
			_enumerator.Dispose();
		}
	}

	public void Populate(Func<QueryResult> usingThisResult)
	{
		_rows = new List<myRow>();
		RowsProgressEventArgs e = null;
		if (_sorting != null)
		{
			e = new RowsProgressEventArgs();
		}
		try
		{
			QueryResult r = usingThisResult();
			try
			{
				int i = 0;
				while (r.MoveNext())
				{
					_applyRowToColumns(r.Current, delegate
					{
						_rows.Add(new myRow(r.Current, _sort, i++));
					});
					if (_sorting != null)
					{
						e.Rows = i;
						_sorting(e);
					}
				}
				_rows.Sort(_c);
				_enumerator = _rows.GetEnumerator();
			}
			finally
			{
				if (r != null)
				{
					r.Dispose();
				}
			}
		}
		finally
		{
			if (_sorting != null)
			{
				e.Done = true;
				_sorting(e);
			}
		}
	}
}
