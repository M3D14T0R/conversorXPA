using System;
using XPARuntimeCore.Box;
using XPARuntimeCore.Box.Engine;
using WizardOfOz.Witch.DataAccess;

namespace WizardOfOz.Witch.Engine;

internal class DummyGridForTask : GridForTask
{
	private class dummyRowsOnScreen : RowsOnScreen
	{
		public bool RowExists(DataProviderRow row)
		{
			return false;
		}

		public int HowManyRowsAreVisible()
		{
			return 1;
		}
	}

	public bool AllowMultiSelection => false;

	public bool ActiveRowConsideredSelected => false;

	public bool EnableInsertRowWhileInsertInUpdate => false;

	public void SelectedRowsChanged()
	{
	}

	public void Remove(DataProviderRow row, Action rowRemovedFromGrid)
	{
	}

	public void ScrollScreen(Scroller scroller, Action<Action<Navigator, Step>> leaveRowAndDo)
	{
		leaveRowAndDo(delegate(Navigator navigator, Step step)
		{
			navigator.Move(scroller.GetCursorForNonGridScreen());
		});
	}

	public void Clear()
	{
	}

	public void InsertCurrentState(DataProviderRow afterThisOne)
	{
	}

	public GridParkedRow GetGridParkedRow()
	{
		return new DummyGridParkedRow();
	}

	public void Deactivate()
	{
	}

	public void Initialize(SubQueryResultProvider queryResultProvider, Action<Action<RowInitializer>> provideRowInitializer, bool preloadData, Action<RowsNavigator> toMe, Action<RowsOnScreen> useRowsOnScreen)
	{
		useRowsOnScreen(new dummyRowsOnScreen());
	}

	public int GetParkedRowIndex()
	{
		return 0;
	}

	public void CollectState(Action<CollectStateHelper> collect)
	{
	}

	public void ForcePaintForEveryRowInBusinessProcess(Action forcePaint)
	{
	}

	public void ShowDummyRow()
	{
	}

	public void OrderByChanged()
	{
	}

	public bool PagingWouldDoNothing(DataProviderRow becauseThisRowIsAlreadyVisible)
	{
		return false;
	}

	public void ScrollToEdgeRow(Scroller scroller, Action<Action<Navigator, Step>> leaveRowAndDo)
	{
	}

	public void CheckKeyContext(KeyContextResult result)
	{
	}

	public bool AllowInsertActivity()
	{
		return true;
	}

	public void InsertCurrentStateAtTop()
	{
	}

	public void AddCurrentState()
	{
	}

	public void Repaint()
	{
	}

	public void ReplaceWithCurrentStateIfParkedOnRow()
	{
	}

	public void AddCurrentStateIfNotParkedOnRow()
	{
	}

	public void SetRowNavigator(RowNavigatorForControl rowNavigatorForControl)
	{
	}

	public void GotoNextOrPreviousRow(Action go)
	{
		go();
	}

	public void Idle()
	{
	}

	public bool ScrollRowsOnMouseWheel(bool mouseWheelScrollsRowsOnlyIfFormContainsGrid)
	{
		return !mouseWheelScrollsRowsOnlyIfFormContainsGrid;
	}
}
