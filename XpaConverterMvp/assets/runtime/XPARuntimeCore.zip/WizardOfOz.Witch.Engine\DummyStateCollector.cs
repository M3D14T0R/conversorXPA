namespace WizardOfOz.Witch.Engine;

internal class DummyStateCollector : StateCollector
{
	public static DummyStateCollector Instance = new DummyStateCollector();

	private DummyStateCollector()
	{
	}

	public void Add(SavedState state)
	{
	}
}
