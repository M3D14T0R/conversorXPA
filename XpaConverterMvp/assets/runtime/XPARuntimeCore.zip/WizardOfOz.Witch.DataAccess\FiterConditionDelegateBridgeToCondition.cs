using XPARuntimeCore.Box.Data.Advanced;

namespace WizardOfOz.Witch.DataAccess;

internal class FiterConditionDelegateBridgeToCondition : FilterBase, FilterCondition
{
	private FilterConditionDelegate _del;

	public bool IsEmpty => false;

	public FiterConditionDelegateBridgeToCondition(FilterConditionDelegate del)
	{
		_del = del;
	}

	public new void ApplyTo(Filter filter, bool supportWildCard)
	{
		_del(filter, supportWildCard);
	}

	internal override FilterCondition GetFilterCondition()
	{
		return this;
	}
}
