using System;
using System.Collections.Generic;
using XPARuntimeCore.Box;
using XPARuntimeCore.Box.Data;
using XPARuntimeCore.Box.Data.Advanced;
using XPARuntimeCore.Box.Data.DataAccess;
using XPARuntimeCore.Box.Data.DataProvider;

namespace WizardOfOz.Witch.DataAccess;

internal class FilterBridgeToIFilterConsumer : Filter, IDisposable
{
	private class DataFilterItem : IFilterItem
	{
		private WhereMeaningfullItem _item;

		public DataFilterItem(WhereMeaningfullItem item)
		{
			_item = item;
		}

		public bool IsAColumn()
		{
			return false;
		}

		public void SaveTo(IFilterItemSaver saver)
		{
			_item.SaveYourValueToDb(saver);
		}
	}

	private class FilterConditionBridgeToIFilter : IFilter
	{
		private FilterCondition _condition;

		private IdentifierProvider _parent;

		private bool _supportWildCard;

		public FilterConditionBridgeToIFilter(FilterCondition condition, IdentifierProvider parent, bool supportWildCard)
		{
			_supportWildCard = supportWildCard;
			_condition = condition;
			_parent = parent;
		}

		public void AddTo(IFilterBuilder builder)
		{
			using FilterBridgeToIFilterConsumer filter = new FilterBridgeToIFilterConsumer(_parent, builder, _supportWildCard);
			_condition.ApplyTo(filter, _supportWildCard);
		}
	}

	private IdentifierProvider _identifier;

	private IFilterBuilderDateTimeFixer _filterBuilder;

	private bool _supportWildCard;

	public FilterBridgeToIFilterConsumer(IdentifierProvider identifier, IFilterBuilder filterBuilder, bool supportWildCard)
	{
		_identifier = identifier;
		_filterBuilder = new IFilterBuilderDateTimeFixer(filterBuilder);
		_supportWildCard = supportWildCard;
	}

	private IFilterItem Translate(WhereMeaningfullItem item)
	{
		IFilterItem filterItem = item.SendIdentifierTo(_identifier);
		return filterItem ?? new DataFilterItem(item);
	}

	private bool IsAValue(WhereMeaningfullItem item)
	{
		return Translate(item) is DataFilterItem;
	}

	public void AddBetweenCondition(ColumnBase column, ColumnFilterValue from, ColumnFilterValue to)
	{
		IFilterItem filterItem = Translate(from);
		IFilterItem to2 = Translate(to);
		_filterBuilder.AddBetween(column, filterItem, to2);
	}

	public void AddEqual(ColumnBase column, ColumnFilterValue to)
	{
		IFilterItem item = Translate(to);
		_filterBuilder.AddEqualTo(column, item);
	}

	public void AddDifferent(ColumnBase column, ColumnFilterValue from)
	{
		_filterBuilder.AddDifferentFrom(column, Translate(from));
	}

	public void AddStartsWith(ColumnBase column, ColumnFilterValue to)
	{
		_filterBuilder.AddStartsWith(column, Translate(to));
	}

	public void AddGreaterOrEqual(ColumnBase column, ColumnFilterValue to)
	{
		_filterBuilder.AddGreaterOrEqualTo(column, Translate(to));
	}

	public void AddLessOrEqual(ColumnBase column, ColumnFilterValue to)
	{
		_filterBuilder.AddLessOrEqualTo(column, Translate(to));
	}

	public void AddWhere(Action<TranslateToGatewayTerms, Action<string>> whereFactory)
	{
		List<WhereMeaningfullItem> list = new List<WhereMeaningfullItem>();
		List<IFilterItem> outParams = new List<IFilterItem>();
		whereFactory(delegate(WhereMeaningfullItem x)
		{
			int num = list.IndexOf(x);
			if (num == -1)
			{
				outParams.Add(Translate(x));
				list.Add(x);
				return "{" + (list.Count - 1) + "}";
			}
			return "{" + num + "}";
		}, delegate(string y)
		{
			_filterBuilder.AddWhere(y, outParams.ToArray());
		});
	}

	public void AddOr(FilterCondition a, FilterCondition b)
	{
		_filterBuilder.AddOr(new FilterConditionBridgeToIFilter(a, _identifier, _supportWildCard), new FilterConditionBridgeToIFilter(b, _identifier, _supportWildCard));
	}

	public void AddLessThan(ColumnBase column, ColumnFilterValue to)
	{
		_filterBuilder.AddLessThan(column, Translate(to));
	}

	public void AddGreaterThan(ColumnBase column, ColumnFilterValue to)
	{
		_filterBuilder.AddGreaterThan(column, Translate(to));
	}

	public void AddUserCondition(Func<bool> condition)
	{
		_filterBuilder.AddTrueCondition();
	}

	public void AddLessOrEqualWithWildcard(TextColumn column, Text value, ColumnFilterValue filterItem)
	{
		IFilterItem filterItem2 = Translate(filterItem);
		if (filterItem2.IsAColumn() || value != (Text)"")
		{
			_filterBuilder.AddLessOrEqualWithWildcard(column, value, filterItem2);
		}
	}

	public void AddTrueCondition()
	{
		_filterBuilder.AddTrueCondition();
	}

	public void Dispose()
	{
		_filterBuilder.Dispose();
	}
}
