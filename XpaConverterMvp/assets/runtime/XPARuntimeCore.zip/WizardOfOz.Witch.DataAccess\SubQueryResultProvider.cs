namespace WizardOfOz.Witch.DataAccess;

internal interface SubQueryResultProvider
{
	QueryResult SubFilter(FilterCondition extraFilter);

	DataProviderRow CreateTemporaryNewRow();

	QueryResult FetchRowsThatMatchFilterOrAreAfterIt(FilterCondition filter, bool reverseParkOnRowOrder);

	bool ProvidesInfiniteQueryResults();
}
