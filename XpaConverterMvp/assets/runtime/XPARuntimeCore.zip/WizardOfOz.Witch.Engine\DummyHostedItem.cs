using System;
using XPARuntimeCore.Box;
using XPARuntimeCore.Box.Advanced;
using XPARuntimeCore.Box.UI;
using XPARuntimeCore.Box.UI.Advanced;
using WizardOfOz.Witch.UI;

namespace WizardOfOz.Witch.Engine;

internal class DummyHostedItem : HostedItem
{
	public long Counter => 0L;

	public void HandleCommand(Command command, ControlBase control, object[] args, Action<CommandRaisingAndInvoking> handle)
	{
	}

	public bool BelongsToTheTaskCreatedBy(CachedTaskBase taskFactory)
	{
		return false;
	}

	public void ExecuteEvent(EventDelegate @event)
	{
	}

	public void NavigateTo(NavigationTarget navigationTarget)
	{
	}

	public void Close(Action callBeforeActiallyClosing, bool closingAll)
	{
	}

	public void ProcessTimerAndExpressionEvents(bool forceEvents)
	{
	}

	public void Activated()
	{
	}

	public bool IsSameTaskAs(HostedItem item)
	{
		return false;
	}

	public void RemoveFromContextTree(Action<bool> remove)
	{
	}

	public void Deactivated()
	{
	}

	public void NavigateInFlow(TaskAction action)
	{
	}

	public void GetNavigationCommandInvoker(Action<InvokeCommand> sendInvoker)
	{
	}

	public void SearchForHandlerThatRunsYou(InvokeCommand runCommand)
	{
	}

	public void SearchForHandlerThatRuns(object thisTask, InvokeCommand andRunThisWithTheAppropriateCommand)
	{
	}

	public void MakeYourFormParentOf(Action<Form> me, Action delegateUpCallStack)
	{
	}

	public void ReactivateForm(Action activateFormInParent)
	{
		activateFormInParent();
	}

	public void ActivateForm(Action activateFormInParent)
	{
		activateFormInParent();
	}

	public bool CloseForm()
	{
		return false;
	}

	public void AddTaskTo(TaskCollection collection)
	{
	}

	public void SendMessageHandler(Action<WindowsMessageLoop.MessageHandler> toMe)
	{
		toMe(new DefaultMessageHandler());
	}

	public void RunActionWhichMayCauseNavigationAwayFromYou(Action action)
	{
		action();
	}

	public void ForTestingOnlyWrapEventProcessing(Action action)
	{
		action();
	}

	public bool IsRunning()
	{
		return false;
	}

	public void EndEditingDueToChangingFocus(ControlBase controlWhichMayRequireFocus, Action andDo)
	{
		andDo();
	}

	public bool IgnoreRootContextInFormNavigation()
	{
		return false;
	}

	public void RollbackHappened()
	{
	}

	public void RefreshSubForm(Func<IControl, bool> isThisTheSubformToRefresh, Action noSubformToRefresh)
	{
		noSubformToRefresh();
	}

	public void NavigationIdle()
	{
	}

	public void RecoverFromRowLevelExceptionWithoutRollback()
	{
	}

	public bool UseChildTransaction()
	{
		return false;
	}

	public ContextNode GetContextNodeBasedOn(ContextNode newNode)
	{
		return newNode;
	}

	public bool CloseWhen(HostedItem thisItemCloses)
	{
		return false;
	}

	public bool CloseDueToStartingOf(HostedItem hostedItem)
	{
		return false;
	}

	public bool KeepQueuedCommandsEvenIfCallStackCollapsed()
	{
		return false;
	}

	public void ReachedByNavigation()
	{
	}

	public void AddStateTo(Action<SavedState> add)
	{
	}

	public void EventProcessingCompleted()
	{
	}

	public void RunOnTask(Action<Task> runThis)
	{
	}
}
