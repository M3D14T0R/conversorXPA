namespace WizardOfOz.Witch.DataAccess;

internal interface DataRowFilter : Filter
{
	bool MatchesFilter { get; }
}
