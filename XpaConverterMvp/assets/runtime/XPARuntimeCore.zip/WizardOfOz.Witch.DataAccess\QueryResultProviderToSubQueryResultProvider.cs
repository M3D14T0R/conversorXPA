namespace WizardOfOz.Witch.DataAccess;

internal class QueryResultProviderToSubQueryResultProvider : SubQueryResultProvider
{
	private QueryResultProvider _qrp;

	public QueryResultProviderToSubQueryResultProvider(QueryResultProvider qrp)
	{
		_qrp = qrp;
	}

	public QueryResult SubFilter(FilterCondition extraFilter)
	{
		return _qrp.SubFilter(extraFilter);
	}

	public DataProviderRow CreateTemporaryNewRow()
	{
		return _qrp.CreateTemporaryNewRow();
	}

	public QueryResult FetchRowsThatMatchFilterOrAreAfterIt(FilterCondition filter, bool reverseParkOnRowOrder)
	{
		return _qrp.FetchRowsThatMatchFilterOrAreAfterIt(filter, reverseParkOnRowOrder);
	}

	public bool ProvidesInfiniteQueryResults()
	{
		return _qrp.ProvidesInfiniteQueryResults();
	}
}
