namespace WizardOfOz.Witch.DataAccess;

internal interface FilterCondition
{
	bool IsEmpty { get; }

	void ApplyTo(Filter filter, bool supportWildCard);
}
