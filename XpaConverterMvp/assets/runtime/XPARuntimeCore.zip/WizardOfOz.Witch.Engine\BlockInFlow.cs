using System;
using System.Collections.Generic;
using XPARuntimeCore.Box.Advanced;
using XPARuntimeCore.Box.Data.Advanced;
using XPARuntimeCore.Box.Flow;

namespace WizardOfOz.Witch.Engine;

internal class BlockInFlow
{
	private abstract class GroupInBlock : UserFlowConditionalItem, ParkedColumn
	{
		public abstract bool CheckCondition();

		public abstract void ActivateFlow(UserFlowItemActivationResult result, FlowMode mode, Direction direction, bool requiresTabStop, DuplicateIndexCheckHelper helper, bool noData, FlowMode flowModeForColumns, Action<Action> runInputValidation, Action<Action, FlowActionVisitor> runInFlowContext);

		public abstract bool CanYouExpandBefore();

		public abstract bool CanYouExpandAfter();

		public void LeaveColumn(Action andDo, LeaveColumnBehavior leaveColumnBehavior, DuplicateIndexCheckHelper helper)
		{
			andDo();
		}

		public bool LeaveColumnWithFlowBackwardInExpand()
		{
			return false;
		}

		public abstract void WhoAreYouReally(UnderlyingUserFlowObjectVisitor visitor);

		public bool CheckEnabled()
		{
			return CheckCondition();
		}

		public abstract void RunExpandBeforeOrAfter(RunExpandResult result, Action noExpandBeforeOrAfter);

		public void LeaveControlWithoutCommiting()
		{
		}

		public void SaveDataAndDo(Action what, Action gotoNextControl)
		{
			what();
		}

		public void ActivateFlowTemplateMode(UserFlowItemActivationResult result)
		{
		}

		public bool AreYou(ColumnBase column)
		{
			return false;
		}

		public bool CanBeParkedOnWhenIdle()
		{
			return false;
		}

		public bool IsSameAs(UserFlowConditionalItem item)
		{
			return item == this;
		}
	}

	private class MainBlockGroup : GroupInBlock
	{
		private BlockInFlow _parent;

		public MainBlockGroup(BlockInFlow parent)
		{
			_parent = parent;
		}

		public override bool CheckCondition()
		{
			return _parent._myFlow.CheckEnabled();
		}

		public override void ActivateFlow(UserFlowItemActivationResult result, FlowMode mode, Direction direction, bool requiresTabStop, DuplicateIndexCheckHelper helper, bool noData, FlowMode flowModeForColumns, Action<Action> runInputValidation, Action<Action, FlowActionVisitor> runInFlowContext)
		{
			if (direction == Direction.Backward)
			{
				return;
			}
			if (_parent._myFlow.Check(mode, direction))
			{
				foreach (GroupInBlock group in _parent._groups)
				{
					if (group.CheckCondition())
					{
						result.MovePositionTo(group);
						result.SwitchToStepModeIfYouAreTryingToMoveInFastModeToBetween(_parent._blockGroupStart, group);
						return;
					}
				}
			}
			if (_parent._myEndBlock == null)
			{
				throw new MissingEndBlockException();
			}
			result.MovePositionTo(_parent._myEndBlock);
			result.SwitchToStepModeIfYouAreTryingToMoveInFastModeToBetween(_parent._blockGroupStart, _parent._myEndBlock);
		}

		public override bool CanYouExpandBefore()
		{
			return false;
		}

		public override bool CanYouExpandAfter()
		{
			if (_parent._myFlow.Check(FlowMode.ExpandAfter, Direction.Any))
			{
				return AtLeastOneConditionInTheBlockIsTrue();
			}
			return false;
		}

		public bool AtLeastOneConditionInTheBlockIsTrue()
		{
			foreach (GroupInBlock group in _parent._groups)
			{
				if (group.CheckCondition())
				{
					return true;
				}
			}
			return false;
		}

		public override void WhoAreYouReally(UnderlyingUserFlowObjectVisitor visitor)
		{
			visitor.IamStartBlock(this, _parent._myEndBlock);
		}

		public override void RunExpandBeforeOrAfter(RunExpandResult result, Action noExpandBeforeOrAfter)
		{
			switch (_parent._myFlow.GetFlowMode())
			{
			case FlowMode.ExpandAfter:
				result(-1, this);
				break;
			case FlowMode.ExpandBefore:
				result(1, _parent._myEndBlock);
				break;
			default:
				noExpandBeforeOrAfter();
				break;
			}
		}

		public FlowMode GetFlowMode()
		{
			return _parent._myFlow.GetFlowMode();
		}
	}

	private class ElseGroup : GroupInBlock
	{
		private Func<bool> _condition;

		private BlockInFlow _parent;

		public ElseGroup(Func<bool> condition, BlockInFlow parent)
		{
			_condition = condition;
			_parent = parent;
		}

		public override void ActivateFlow(UserFlowItemActivationResult result, FlowMode mode, Direction direction, bool requiresTabStop, DuplicateIndexCheckHelper helper, bool noData, FlowMode flowModeForColumns, Action<Action> runInputValidation, Action<Action, FlowActionVisitor> runInFlowContext)
		{
			if (direction == Direction.Backward)
			{
				result.MovePositionTo(_parent._blockGroupStart);
			}
			else
			{
				result.MovePositionTo(_parent._myEndBlock);
			}
		}

		public override bool CanYouExpandBefore()
		{
			return false;
		}

		public override bool CanYouExpandAfter()
		{
			return false;
		}

		public override bool CheckCondition()
		{
			return _condition();
		}

		public override void WhoAreYouReally(UnderlyingUserFlowObjectVisitor visitor)
		{
		}

		public override void RunExpandBeforeOrAfter(RunExpandResult result, Action noExpandBeforeOrAfter)
		{
			throw new NotImplementedException();
		}
	}

	private class myEndBlock : UserFlowConditionalItem, ParkedColumn
	{
		private BlockInFlow _parent;

		public myEndBlock(BlockInFlow parent)
		{
			_parent = parent;
		}

		public void ActivateFlow(UserFlowItemActivationResult result, FlowMode mode, Direction direction, bool requiresTabStop, DuplicateIndexCheckHelper helper, bool noData, FlowMode flowModeForColumns, Action<Action> runInputValidation, Action<Action, FlowActionVisitor> runInFlowContext)
		{
			if (direction == Direction.Backward)
			{
				if (_parent._myFlow.Check(mode, direction))
				{
					int num = 0;
					foreach (GroupInBlock group in _parent._groups)
					{
						if (group.CheckCondition())
						{
							UserFlowConditionalItem a = ((num >= _parent._groups.Count - 1) ? ((UserFlowConditionalItem)_parent._myEndBlock) : ((UserFlowConditionalItem)_parent._groups[num + 1]));
							result.MovePositionTo(a);
							result.SwitchToStepModeIfYouAreTryingToMoveInFastModeToBetween(a, _parent._myEndBlock);
							return;
						}
						num++;
					}
				}
				result.MovePositionTo(_parent._blockGroupStart);
				result.SwitchToStepModeIfYouAreTryingToMoveInFastModeToBetween(_parent._blockGroupStart, _parent._myEndBlock);
			}
			else
			{
				if (mode != FlowMode.ExpandBefore || !_parent._myFlow.Check(mode, direction))
				{
					return;
				}
				foreach (GroupInBlock group2 in _parent._groups)
				{
					if (group2.CheckCondition())
					{
						result.MovePositionTo(group2);
						break;
					}
				}
			}
		}

		public bool CanYouExpandBefore()
		{
			if (_parent._blockGroupStart.GetFlowMode() == FlowMode.ExpandBefore)
			{
				return _parent._blockGroupStart.AtLeastOneConditionInTheBlockIsTrue();
			}
			return false;
		}

		public bool CanYouExpandAfter()
		{
			return false;
		}

		public void LeaveColumn(Action andDo, LeaveColumnBehavior leaveColumnBehavior, DuplicateIndexCheckHelper helper)
		{
			andDo();
		}

		public bool LeaveColumnWithFlowBackwardInExpand()
		{
			return false;
		}

		public void WhoAreYouReally(UnderlyingUserFlowObjectVisitor visitor)
		{
			visitor.IamEndBlock();
		}

		public bool CheckEnabled()
		{
			return true;
		}

		public void RunExpandBeforeOrAfter(RunExpandResult result, Action noExpandBeforeOrAfter)
		{
		}

		public void LeaveControlWithoutCommiting()
		{
		}

		public void SaveDataAndDo(Action what, Action gotoNextControl)
		{
		}

		public void ActivateFlowTemplateMode(UserFlowItemActivationResult result)
		{
		}

		public bool AreYou(ColumnBase column)
		{
			return false;
		}

		public bool CanBeParkedOnWhenIdle()
		{
			return false;
		}

		public bool IsSameAs(UserFlowConditionalItem item)
		{
			return item == this;
		}
	}

	private FlowClass _myFlow = new FlowClass(null);

	private myEndBlock _myEndBlock;

	private MainBlockGroup _blockGroupStart;

	private List<GroupInBlock> _groups = new List<GroupInBlock>();

	public BlockInFlow()
	{
		_blockGroupStart = new MainBlockGroup(this);
		_groups.Add(_blockGroupStart);
	}

	public FlowClass GetFlowSettings()
	{
		return _myFlow;
	}

	public UserFlowConditionalItem GetBlocksConditionalItem()
	{
		return _blockGroupStart;
	}

	public UserFlowConditionalItem AddElseBlock(Func<bool> condition)
	{
		ElseGroup elseGroup = new ElseGroup(condition, this);
		_groups.Add(elseGroup);
		return elseGroup;
	}

	internal UserFlowConditionalItem CreateEndBlockUserFlowItem()
	{
		if (_myEndBlock != null)
		{
			throw new InvalidOperationException("this block has already ended, there is a mismatch between start and end blocks");
		}
		_myEndBlock = new myEndBlock(this);
		return _myEndBlock;
	}
}
