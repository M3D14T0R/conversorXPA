using System.Drawing;
using XPARuntimeCore.Box.UI;
using XPARuntimeCore.Box;
namespace ENV.Security.UI
{

    /// <summary>UserForm</summary>
    public partial class Form : XPARuntimeCore.Box.UI.Form
    {
        /// <summary>UserForm</summary>
        public Form()
        {
            InitializeComponent();
            RightToLeft = LocalizationInfo.Current.RightToLeft;
            Modal = true;
        }
    }
}
