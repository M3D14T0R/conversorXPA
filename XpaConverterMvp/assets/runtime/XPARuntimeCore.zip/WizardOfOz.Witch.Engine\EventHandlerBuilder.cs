using System;
using XPARuntimeCore.Box;

namespace WizardOfOz.Witch.Engine;

internal interface EventHandlerBuilder
{
	void Add(Command command, ActionWithParameters actionInTask);

	void Add(Command command, ActionWithParameters actionInTask, Action<Action<bool>> notifyEnabledTo);
}
