using System.Drawing;
using XPARuntimeCore.Box.UI;
using XPARuntimeCore.Box;
namespace ENV.Security.UI
{
    partial class Grid
    {
        void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // Grid
            // 
            this.Location = new System.Drawing.Point(0, 0);
            this.RowHeight = 22;
            DrawPartialRow = false;
            this.ResumeLayout(false);

        }
    }
}
