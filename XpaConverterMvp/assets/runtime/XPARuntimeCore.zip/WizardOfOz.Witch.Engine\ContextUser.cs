namespace WizardOfOz.Witch.Engine;

internal interface ContextUser
{
	void NeedContext();
}
