using System;
using System.Collections.Generic;
using XPARuntimeCore.Box;

namespace WizardOfOz.Witch.Engine;

internal class AllowActivityValue
{
	private bool _lastValue;

	private List<Action<bool>> _listeners = new List<Action<bool>>();

	private Func<bool> _expression;

	private bool _evaluating;

	public AllowActivityValue(bool defaultValue)
	{
		_lastValue = defaultValue;
		SetValue(() => defaultValue);
	}

	public void SetValue(Func<bool> reference)
	{
		_expression = delegate
		{
			_evaluating = true;
			try
			{
				bool x = reference();
				_listeners.ForEach(delegate(Action<bool> action)
				{
					action(x);
				});
				return x;
			}
			finally
			{
				_evaluating = false;
			}
		};
	}

	public void SetValue(bool value)
	{
		SetValue(Bool.From(value));
		GetValue();
	}

	public void AddListener(Action<bool> listener, Action<Action> sendDisposeCommandToMe)
	{
		_listeners.Add(listener);
		listener(_lastValue);
		sendDisposeCommandToMe(delegate
		{
			_listeners.Remove(listener);
		});
	}

	public bool GetValue()
	{
		if (_evaluating)
		{
			return _lastValue;
		}
		return _lastValue = _expression();
	}

	public bool GetLastValue()
	{
		return _lastValue;
	}
}
