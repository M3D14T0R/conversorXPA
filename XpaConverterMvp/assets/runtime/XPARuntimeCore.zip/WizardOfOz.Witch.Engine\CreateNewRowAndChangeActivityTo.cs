namespace WizardOfOz.Witch.Engine;

internal delegate void CreateNewRowAndChangeActivityTo(ActivityStrategy thisActivity);
