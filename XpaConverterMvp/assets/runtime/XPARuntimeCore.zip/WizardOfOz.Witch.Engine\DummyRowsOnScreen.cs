using WizardOfOz.Witch.DataAccess;

namespace WizardOfOz.Witch.Engine;

internal class DummyRowsOnScreen : RowsOnScreen
{
	public bool RowExists(DataProviderRow row)
	{
		return false;
	}

	public int HowManyRowsAreVisible()
	{
		return 1;
	}
}
