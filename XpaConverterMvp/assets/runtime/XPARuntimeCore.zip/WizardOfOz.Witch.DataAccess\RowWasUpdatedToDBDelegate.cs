namespace WizardOfOz.Witch.DataAccess;

internal delegate void RowWasUpdatedToDBDelegate(DataProviderRow row);
