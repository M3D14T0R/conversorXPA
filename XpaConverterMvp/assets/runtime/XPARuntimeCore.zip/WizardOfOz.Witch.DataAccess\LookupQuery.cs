using System;
using XPARuntimeCore.Box.Data.Advanced;

namespace WizardOfOz.Witch.DataAccess;

internal interface LookupQuery
{
	void DoOnRows(UberFilter filter, Action<QueryResult> rows, bool supportWildCard, bool lockAllRows);

	DataProviderRow CreateTemporaryNewRow();

	void ClearCache();

	IdentifierProvider GetIdentifier();

	void AddColumnIfItsNotThere(ColumnBase column);
}
