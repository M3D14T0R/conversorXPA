using System.Drawing;
using XPARuntimeCore.Box.UI;
using XPARuntimeCore.Box;
namespace ENV.Security.UI
{

    /// <summary>GridColumn</summary>
    public partial class GridColumn : XPARuntimeCore.Box.UI.GridColumn
    {


        /// <summary>GridColumn</summary>
        public GridColumn()
        {
            InitializeComponent();
        }

    }
}
