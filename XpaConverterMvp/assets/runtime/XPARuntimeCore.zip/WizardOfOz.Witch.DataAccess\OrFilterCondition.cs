using XPARuntimeCore.Box.Data.Advanced;

namespace WizardOfOz.Witch.DataAccess;

internal class OrFilterCondition : FilterBase, ComplexFilterCondition, FilterCondition
{
	private FilterCondition _a;

	private FilterCondition _b;

	public bool IsEmpty => false;

	public OrFilterCondition(FilterCondition a, FilterCondition b)
	{
		_a = a;
		_b = b;
	}

	public ComplexFilterCondition Or(FilterCondition filter)
	{
		return new OrFilterCondition(this, filter);
	}

	public ComplexFilterCondition And(FilterCondition filter)
	{
		return new AndFilterCondition(this, filter);
	}

	public new void ApplyTo(Filter filter, bool supportWildCard)
	{
		filter.AddOr(_a, _b);
	}

	internal override FilterCondition GetFilterCondition()
	{
		return this;
	}
}
