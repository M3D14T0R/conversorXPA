using XPARuntimeCore.Box.Data.Advanced;
using XPARuntimeCore.Box.Data.DataProvider;

namespace WizardOfOz.Witch.DataAccess;

internal interface FilterItemSaver : IValueSaver
{
	void Column(ColumnBase column);
}
