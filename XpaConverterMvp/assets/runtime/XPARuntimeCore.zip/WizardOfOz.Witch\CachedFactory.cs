using System.Collections.Generic;
using XPARuntimeCore.Box;

namespace WizardOfOz.Witch;

internal class CachedFactory<Item>
{
	public delegate Item ItemFactoryDelegate(string key);

	private ItemFactoryDelegate _factory;

	private Dictionary<string, Item> _cache = new Dictionary<string, Item>();

	private Item _itemForNull;

	public CachedFactory(ItemFactoryDelegate factory)
	{
		_factory = factory;
	}

	public Item GetItemFor(string key)
	{
		if (key == null)
		{
			key = "";
		}
		key = Text.SpeedTrimEndAll(key);
		if (!_cache.TryGetValue(key, out var value))
		{
			lock (_cache)
			{
				if (!_cache.TryGetValue(key, out value))
				{
					value = _factory(key);
					_cache.Add(key ?? "", value);
				}
			}
		}
		return value;
	}

	public void Add(string format, Item date)
	{
		_cache.Add(format, date);
	}

	public void Clear()
	{
		_cache.Clear();
	}
}
