using System;

namespace WizardOfOz.Witch.Engine;

internal delegate void CommandForRecomputeMonitorDelegate(bool doActualUpdate, Action callMeToStopMonitoring);
