using System;
using XPARuntimeCore.Box.Data.Advanced;

namespace WizardOfOz.Witch.DataAccess;

internal interface DataProviderRow
{
	void SetColumnsAcordingToYourValueOrDefaultValuesForANewRowAndRefreshJoinedLookups();

	void UpdateDatabaseAcordingToValues();

	void DoUpdateOrInsertOnSavingRow();

	void DoDeleteOnSavingRow();

	void Delete();

	void Lock(Action callIfRowDoesNotExist, bool checkForChanges);

	bool IsNewRow();

	void ReloadRowData(Action callIfRowDoesNotExist);

	void ReloadRowDataAndIgnoreExceptions();

	bool IsEqualTo(DataProviderRow b);

	void Unlock();

	void LockAndIgnoreExceptions();

	bool HasJoins();

	DataRowFilter GetFilterChecker();

	void AddEqualToColumn(ColumnBase parentIdColumn, ColumnBase columnToTakeTheValueFrom, FilterCollection fc);
}
