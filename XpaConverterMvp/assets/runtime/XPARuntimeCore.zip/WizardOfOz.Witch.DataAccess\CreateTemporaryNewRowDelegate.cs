namespace WizardOfOz.Witch.DataAccess;

internal delegate DataProviderRow CreateTemporaryNewRowDelegate();
