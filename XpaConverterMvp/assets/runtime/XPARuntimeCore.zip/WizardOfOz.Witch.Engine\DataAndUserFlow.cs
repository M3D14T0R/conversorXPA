using System;
using System.Collections.Generic;
using XPARuntimeCore.Box;
using XPARuntimeCore.Box.Advanced;
using XPARuntimeCore.Box.Data;
using XPARuntimeCore.Box.Data.Advanced;
using XPARuntimeCore.Box.Data.DataProvider;
using WizardOfOz.Witch.DataAccess;

namespace WizardOfOz.Witch.Engine;

internal class DataAndUserFlow
{
	private class myDelegateToRelationRowLoadingHelper : RelationRowLoadingHelper
	{
		private DataAndUserFlow _parent;

		public myDelegateToRelationRowLoadingHelper(DataAndUserFlow parent)
		{
			_parent = parent;
		}

		public void OnRowLoaded(object context, DataProviderRow row, Action resetDataToColumns)
		{
			_parent._onRowLoaded.OnRowLoaded(context, row, resetDataToColumns);
		}

		public bool LockAllRows(bool isForRelation)
		{
			return _parent._onRowLoaded.LockAllRows(isForRelation);
		}

		public void OnRowUnLoaded(DataProviderRow currentRow)
		{
			_parent._onRowLoaded.OnRowUnLoaded(currentRow);
		}
	}

	private delegate void FetchRowsStrategy(Action<Action<QueryConsumer>> consumer, bool reloadData, Action notifyThisMayTakeLong, bool donotFetchSort);

	private class ExcludeIdentifier : IdentifierProvider
	{
		private IdentifierProvider _source;

		public ExcludeIdentifier(IdentifierProvider source)
		{
			_source = source;
		}

		public bool Contains(ColumnBase column)
		{
			return !_source.Contains(column);
		}
	}

	private class monitoredCommandForRowWasChangedSinceLoadedError : RunMonitoredCommand
	{
		public void Run()
		{
			throw new DatabaseErrorException(DatabaseErrorType.RowWasChangedSinceLoaded, DatabaseErrorHandlingStrategy.Rollback);
		}
	}

	private class FilterWhichOnlyChecksUserCondition : Filter
	{
		private Action _callMeIfUserConditionFailed;

		public FilterWhichOnlyChecksUserCondition(Action callMeIfUserConditionFailed)
		{
			_callMeIfUserConditionFailed = callMeIfUserConditionFailed;
		}

		public void AddBetweenCondition(ColumnBase column, ColumnFilterValue from, ColumnFilterValue to)
		{
		}

		public void AddDifferent(ColumnBase column, ColumnFilterValue from)
		{
		}

		public void AddEqual(ColumnBase column, ColumnFilterValue to)
		{
		}

		public void AddGreaterOrEqual(ColumnBase column, ColumnFilterValue to)
		{
		}

		public void AddGreaterThan(ColumnBase column, ColumnFilterValue to)
		{
		}

		public void AddLessOrEqual(ColumnBase column, ColumnFilterValue to)
		{
		}

		public void AddLessOrEqualWithWildcard(TextColumn column, Text value, ColumnFilterValue filterItem)
		{
		}

		public void AddLessThan(ColumnBase column, ColumnFilterValue to)
		{
		}

		public void AddOr(FilterCondition a, FilterCondition b)
		{
		}

		public void AddStartsWith(ColumnBase column, ColumnFilterValue to)
		{
		}

		public void AddTrueCondition()
		{
		}

		public void AddUserCondition(Func<bool> condition)
		{
			if (!condition())
			{
				_callMeIfUserConditionFailed();
			}
		}

		public void AddWhere(Action<TranslateToGatewayTerms, Action<string>> whereFactory)
		{
		}
	}

	private class myQueryForGetFilter : Query
	{
		private FilterCollection _filter;

		public myQueryForGetFilter(FilterCollection filter)
		{
			_filter = filter;
		}

		public void AddJoin(Entity t, IEnumerable<ColumnBase> selectedColumns, FilterCondition joinFilter, LookupInAQuery lookup)
		{
			_filter.InternalAdd(joinFilter);
		}

		public void AddLeftOuterJoin(Entity t, IEnumerable<ColumnBase> selectedColumns, FilterCondition joinFilter, LookupInAQuery lookup)
		{
			_filter.InternalAdd(joinFilter);
		}

		public void Construct(QueryConsumer client, ApplyRowToColumnsForManualSort applyRowToColumns, RowsProgressHandler sorting, bool donotFetchSort)
		{
		}

		public void Prepare(ApplyRowToColumnsForManualSort applyRowToColumns, Action notifyThisMayTakeLong, RowsProgressHandler sorting, bool donotFetchSort)
		{
		}
	}

	private List<ColumnBase> _localColumns = new List<ColumnBase>();

	private ColumnCollection _columns;

	private Sort _orderBy = Empty;

	private static Sort Empty = new Sort();

	private List<ColumnBase> _selectedColumnBases = new List<ColumnBase>();

	private RecomputeManager _recomputeManager;

	private EntityCollection _entities;

	private List<TransactionProvider> _transactionProviders = new List<TransactionProvider>();

	private FilterCollection _filterCollector = new FilterCollection();

	private FilterCollection _nonFixedNonDbFilterCollector = new FilterCollection();

	private FilterCondition __filter;

	private FilterCondition __fixedNonDbFilterCollector;

	private MonitoredDatabaseClient _monitor;

	private Action<ColumnBase> _selectListener;

	private RelationRowLoadingHelper _onRowLoaded = new DummyRelationRowLoadingHelper();

	private Func<IRowsSource, IRowsSource> _wrapRowsSource;

	private Action<Action> _prepareQuery;

	private RowsProgressHandler _sorting;

	private bool _hasLookupColumns;

	private SelectionVerifier _rootVerifier = new SelectionVerifierDummy();

	private RelationCollection _relations;

	private List<Relation> _lookups = new List<Relation>();

	private List<Relation> _lookupsThatWerentAddedToTheFlow = new List<Relation>();

	private Action<Action<ColumnBase>> _selectFromColumns = delegate
	{
	};

	private IdentifierProvider _mainIdentifierProvider = DummyIdentifierProvider.Instance;

	private Entity _from;

	private Action _onCreateQuery;

	private bool _runOnce;

	private FetchRowsStrategy _fetchRows = delegate
	{
	};

	private HashSet<ColumnBase> _columnsThatWereAddedBecauseTheyWereNotSelectedButWereNeeded = new HashSet<ColumnBase>();

	private Entity[] _fromAndJoins;

	public EntityCollection Entities => _entities;

	public Sort TableKey
	{
		set
		{
			_orderBy = value;
		}
	}

	private FilterCondition _filter
	{
		get
		{
			if (__filter == null)
			{
				__fixedNonDbFilterCollector = _nonFixedNonDbFilterCollector.CreateFixedFilter(_from, supportWildCard: true);
				__filter = _filterCollector.CreateFixedFilter(_from, supportWildCard: true);
			}
			return __filter;
		}
	}

	private FilterCondition _nonDbFilterCollector
	{
		get
		{
			if (__fixedNonDbFilterCollector == null)
			{
				__fixedNonDbFilterCollector = _nonFixedNonDbFilterCollector.CreateFixedFilter(_from, supportWildCard: true);
			}
			return __fixedNonDbFilterCollector;
		}
	}

	public FilterCollection Filter => _filterCollector;

	public FilterCollection NonDbFilter => _nonFixedNonDbFilterCollector;

	public RelationCollection Relations => _relations;

	public ColumnCollection Columns => _columns;

	public bool HasAnyRelationThatShouldInsert
	{
		get
		{
			foreach (Relation lookup in _lookups)
			{
				if (lookup.ShouldInsert)
				{
					return true;
				}
			}
			return false;
		}
	}

	public void SetRowLoadedListener(RelationRowLoadingHelper onRowLoaded)
	{
		_onRowLoaded = onRowLoaded;
	}

	internal DataAndUserFlow(RecomputeManager recomputeManager, MonitoredDatabaseClient monitor, Action<ColumnBase> selectListener, Func<IRowsSource, IRowsSource> wrapRowsSource, Action<Action> prepareQuery, RowsProgressHandler sorting)
	{
		_sorting = sorting;
		myDelegateToRelationRowLoadingHelper myWrapper = new myDelegateToRelationRowLoadingHelper(this);
		_selectListener = selectListener;
		_recomputeManager = recomputeManager;
		_wrapRowsSource = wrapRowsSource;
		_prepareQuery = prepareQuery;
		_entities = new EntityCollection(delegate(Entity a)
		{
			_transactionProviders.Add(a);
		});
		_columns = new ColumnCollection(delegate(ColumnBase column)
		{
			column.YouAreSelectedInATask();
			ChainOfResponsability c = new ChainOfResponsability();
			c.Do(delegate
			{
				_rootVerifier.SelectIfYouCan(column, delegate(ColumnBase obj)
				{
					c.Done();
					if (!_selectedColumnBases.Contains(obj))
					{
						_selectedColumnBases.Add(obj);
					}
					AddRecomputeItemToFlow(new ColumnInDataView(_recomputeManager, column));
				});
			});
			c.Foreach(_lookups).Do(delegate(Relation obj)
			{
				obj.SelectIfYouCan(column, delegate
				{
					if (_lookupsThatWerentAddedToTheFlow.Contains(obj))
					{
						obj.AddToRecomputeFlow(_monitor, AddRecomputeItemToFlow, _recomputeManager, myWrapper, CallMeIfColumnBelongsToCurrentTask);
						_lookupsThatWerentAddedToTheFlow.Remove(obj);
					}
					_hasLookupColumns = true;
					c.Done();
				});
			});
			c.Do(delegate
			{
				if (column.IsEntityBasedColumn())
				{
					throw new Exception(string.Format("Column '{0}({2})' is associated with Entity '{1}' that is not included in the dataview. Did you forget to set the From or include that entity in a relation?", column.Name, column.Entity.ToString(), column.Caption));
				}
				_localColumns.Add(column);
				AddRecomputeItemToFlow(new ColumnInDataView(_recomputeManager, column));
			});
			_selectListener(column);
		}, delegate
		{
			throw new NotSupportedException("Can't remove a column from a task");
		});
		_monitor = monitor;
		_relations = new RelationCollection(delegate(Relation relationBase)
		{
			_lookups.Add(relationBase);
			_lookupsThatWerentAddedToTheFlow.Add(relationBase);
		}, _entities.Add, delegate(ColumnBase x)
		{
			Columns.Add(x);
		}, _lookups.ToArray);
		_onCreateQuery = delegate
		{
			foreach (Relation item in _lookupsThatWerentAddedToTheFlow)
			{
				item.AddToRecomputeFlow(_monitor, AddRecomputeItemToFlow, _recomputeManager, myWrapper, CallMeIfColumnBelongsToCurrentTask);
			}
			_lookupsThatWerentAddedToTheFlow.Clear();
			_onCreateQuery = delegate
			{
			};
		};
	}

	private void CallMeIfColumnBelongsToCurrentTask(ColumnBase column, Action callIfColumnBelonds)
	{
		if (_columns.Contains(column))
		{
			callIfColumnBelonds();
		}
	}

	private void AddRecomputeItemToFlow(RecomputeItem item)
	{
		_recomputeManager.AddItemToRecomputeFlow(item, delegate
		{
		});
	}

	internal void UpdateLookupedTablesToTheDatabase(bool suppressCreationOfRowsByRelations)
	{
		foreach (Relation lookup in _lookups)
		{
			lookup.UpdateDatabaseAcordingToValues(suppressCreationOfRowsByRelations);
		}
	}

	internal void DoOnSavingRowForLookupedTables()
	{
		foreach (Relation lookup in _lookups)
		{
			lookup.DoOnSavingRowAccordingToValues();
		}
	}

	internal void SetFrom(Entity mainTable)
	{
		_rootVerifier = mainTable;
		_selectFromColumns = mainTable.SelectAllColumns;
		_mainIdentifierProvider = mainTable.GetIdendtifierProvider();
		_from = mainTable;
		_fetchRows = delegate(Action<Action<QueryConsumer>> consumer, bool reloadData, Action notifyThisMayTakeLong, bool donotFetchSort)
		{
			Sort orderBy = _orderBy;
			bool forceFinilizeCompute = false;
			foreach (SortSegment segment in orderBy.Segments)
			{
				SelectIfNotSelected(segment.Column, dummyTaskFlowRunner.Instance, delegate(Action action)
				{
					action();
				});
				if (segment.Column.Entity != _from)
				{
					forceFinilizeCompute = true;
				}
			}
			mainTable.CreateQuery(_selectedColumnBases, _filter, orderBy, _monitor, delegate(Query query)
			{
				foreach (Relation lookup in _lookups)
				{
					lookup.AddYourSelfTo(query);
				}
				ApplyRowToColumnsForManualSort a = delegate(DataProviderRow row, Action doOnColumnsOfRow)
				{
					RelationRowLoadingHelper onRowLoaded = _onRowLoaded;
					_onRowLoaded = DummyRelationRowLoadingHelper.Instance;
					try
					{
						_recomputeManager.Init(row, updateOriginalValues: false, delegate(RecomputeManager.RowInitializer initializer)
						{
							if (CurrentDataFitsRange(excludeDatabaseRange: false, initializer))
							{
								if (forceFinilizeCompute)
								{
									initializer.FinilizeCompute();
								}
								doOnColumnsOfRow();
							}
						});
					}
					finally
					{
						_onRowLoaded = onRowLoaded;
					}
				};
				_prepareQuery(delegate
				{
					query.Prepare(a, notifyThisMayTakeLong, _sorting, donotFetchSort);
				});
				consumer(delegate(QueryConsumer queryConsumer)
				{
					query.Construct(queryConsumer, a, _sorting, donotFetchSort);
				});
			}, reloadData, _wrapRowsSource);
		};
	}

	public void ProviderQueryConsumerHandler(bool refreshFilter, Action<Action<QueryConsumer>> provideQeueryConsumerHandler, Action notifyThisMayTakeLong, bool donotFetchSort)
	{
		_onCreateQuery();
		if (refreshFilter)
		{
			__filter = null;
			__fixedNonDbFilterCollector = null;
		}
		_fetchRows(provideQeueryConsumerHandler, refreshFilter, notifyThisMayTakeLong, donotFetchSort);
	}

	public void DisposeTaskResources()
	{
		__filter = null;
		__fixedNonDbFilterCollector = null;
		foreach (Relation lookup in _lookups)
		{
			lookup.DisposeTaskResources();
		}
	}

	internal void AddTransactionProviderTo(Action<TransactionProvider> add)
	{
		foreach (TransactionProvider transactionProvider in _transactionProviders)
		{
			add(transactionProvider);
		}
	}

	public void SelectIfNotSelected(ColumnBase obj, TaskFlowRunner runner, Action<Action> collector)
	{
		if (!_columns.Contains(obj))
		{
			obj.DoIfNotSelected(delegate
			{
				Columns.Add(obj);
				obj.StartTask(runner, collector);
				_columnsThatWereAddedBecauseTheyWereNotSelectedButWereNeeded.Add(obj);
			});
		}
	}

	public bool WasColumnAddedBecauseItWasMandatoryAndNotBecauseItExisted(ColumnBase col)
	{
		return _columnsThatWereAddedBecauseTheyWereNotSelectedButWereNeeded.Contains(col);
	}

	internal void BeginTaskForColumns(TaskFlowRunner runner, Action<Action> collector)
	{
		if (!_runOnce && _selectedColumnBases.Count == 0 && !_hasLookupColumns && _localColumns.Count == 0)
		{
			SelectAll();
		}
		foreach (ColumnBase column in _columns)
		{
			column.StartTask(runner, collector);
		}
	}

	internal void AddMandatoryColumns(TaskFlowRunner runner, Action<Action> collector, Action<Action<ColumnBase>> selectNeededFieldsThatWereNotSelected, Action<Action> letTaskTypeKnowAddingMandatoryColumns)
	{
		if (_runOnce)
		{
			return;
		}
		selectNeededFieldsThatWereNotSelected(delegate(ColumnBase x)
		{
			SelectIfNotSelected(x, runner, collector);
		});
		letTaskTypeKnowAddingMandatoryColumns(delegate
		{
			_rootVerifier.SendMandatoryColumnsTo(delegate(ColumnBase x)
			{
				SelectIfNotSelected(x, runner, collector);
			});
			foreach (Relation lookup in _lookups)
			{
				lookup.SendMandatoryColumnsTo(delegate(ColumnBase x)
				{
					SelectIfNotSelected(x, runner, collector);
				});
			}
			foreach (SortSegment segment in _orderBy.Segments)
			{
				int count = _columns.Count;
				SelectIfNotSelected(segment.Column, runner, collector);
				if (count != _columns.Count)
				{
					segment.Column.DbReadOnly = true;
				}
			}
		});
		_runOnce = true;
	}

	public void SelectAll()
	{
		Action<ColumnBase> action = delegate(ColumnBase prop)
		{
			if (!Columns.Contains(prop))
			{
				Columns.Add(prop);
			}
		};
		_selectFromColumns(action);
		foreach (Relation lookup in _lookups)
		{
			lookup.SelectAllColumns(action);
		}
	}

	public void DoIfHasEntities(Action action)
	{
		if (_entities.Count > 0)
		{
			action();
		}
	}

	public void ClearRelationsCache()
	{
		foreach (Entity entity in Entities)
		{
			entity.ClearRelationCache();
		}
	}

	public void BeginTaskForEntities(Action<Action> collector, Func<bool> useOptimisticConcurrency)
	{
		_entities.BeginTask(useOptimisticConcurrency, collector, _monitor, _wrapRowsSource);
	}

	public bool ColumnInDataView(ColumnBase column)
	{
		return _columns.Contains(column);
	}

	public bool CurrentDataFitsRange(bool excludeDatabaseRange, RecomputeManager.RowInitializer initializer)
	{
		bool flag = _filter.IsEmpty && _nonDbFilterCollector.IsEmpty;
		if (!flag)
		{
			if (_nonDbFilterCollector.IsEmpty)
			{
				flag = true;
			}
			else
			{
				FilterOnColumns filterOnColumns = new FilterOnColumns(initializer, ignoreCase: false, supportWildCard: true, _mainIdentifierProvider);
				_nonDbFilterCollector.ApplyTo(filterOnColumns, supportWildCard: true);
				flag = filterOnColumns.GetIsTrue();
			}
			if (flag)
			{
				FilterOnColumns filterOnColumns2 = new FilterOnColumns(initializer, ignoreCase: false, supportWildCard: true, _mainIdentifierProvider);
				FilterCondition filter = _filter;
				Filter filter3;
				if (!excludeDatabaseRange)
				{
					Filter filter2 = filterOnColumns2;
					filter3 = filter2;
				}
				else
				{
					Filter filter2 = new FilterRelevanceDecorator(filterOnColumns2, new ExcludeIdentifier(_mainIdentifierProvider));
					filter3 = filter2;
				}
				filter.ApplyTo(filter3, supportWildCard: true);
				flag = filterOnColumns2.GetIsTrue();
			}
		}
		if (!flag)
		{
			return false;
		}
		for (int i = 0; i < _lookups.Count; i++)
		{
			if (!_lookups[i].CurrentRowMatchesConditions())
			{
				return false;
			}
		}
		return true;
	}

	public void ResetDataToNoRowAndNoDataState()
	{
		foreach (Entity entity in _entities)
		{
			entity.ResetYourColumnsToDefaultValue();
		}
	}

	public void PerformDuplicationIndexCheckFor(Entity entity, Sort sort)
	{
		entity.PerformActualDuplicateIndexCheck(_monitor, sort);
	}

	public void SetOriginalValuesForRelationColumns()
	{
		foreach (Relation lookup in _lookups)
		{
			lookup.SetOriginalValuesForColumns();
		}
	}

	internal void RecheckCurrentDataFitsRangeAfterLock()
	{
		if (_lookups.Count <= 0 && !_nonDbFilterCollector.IsEmpty)
		{
			_nonDbFilterCollector.ApplyTo(new FilterWhichOnlyChecksUserCondition(delegate
			{
				new MonitoredDatabaseRunnerClass(_monitor, _from).RunQuery(new monitoredCommandForRowWasChangedSinceLoadedError(), isUpdateOrInsert: false);
			}), supportWildCard: true);
		}
	}

	internal void AfterFormDisplay()
	{
		_entities.AfterFormDisplay(_monitor);
	}

	internal string GetCurrentFilterString()
	{
		FilterCollection filterCollection = new FilterCollection();
		filterCollection.InternalAdd(_filterCollector);
		if (_fromAndJoins == null)
		{
			List<Entity> list = new List<Entity>();
			list?.Add(_from);
			foreach (Relation lookup in _lookups)
			{
				if (lookup.Type == RelationType.Join || lookup.Type == RelationType.OuterJoin)
				{
					list.Add(lookup.From);
				}
			}
			_fromAndJoins = list.ToArray();
		}
		foreach (Relation lookup2 in _lookups)
		{
			lookup2.AddYourSelfTo(new myQueryForGetFilter(filterCollection));
		}
		return filterCollection.ToFilterString(_fromAndJoins);
	}
}
