using System.Drawing;
using XPARuntimeCore.Box.UI;
using XPARuntimeCore.Box;
namespace ENV.Labs.UI
{
    partial class ScreenPicture
    {
        void InitializeComponent()
        {
        }
    }
}
