using System;

namespace WizardOfOz.Witch.DataAccess;

internal class QueryResultToNotResetable : ResetableQueryResult, IDisposable
{
	private QueryResult _r = new DummyQuery();

	private Func<QueryResult> _getQueryResult;

	public DataProviderRow Current => _r.Current;

	public QueryResultToNotResetable(Func<QueryResult> getQueryResult)
	{
		_getQueryResult = getQueryResult;
		_r = _getQueryResult();
	}

	public void Dispose()
	{
		_r.Dispose();
	}

	public bool MoveNext()
	{
		return _r.MoveNext();
	}

	public bool TryResetAndReturnFalseIfNotSupported()
	{
		return false;
	}

	public void RemoveRow(DataProviderRow row)
	{
	}

	public void InsertRow(DataProviderRow row)
	{
	}
}
