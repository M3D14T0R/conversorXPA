namespace WizardOfOz.Witch.DataAccess;

internal delegate QueryResult GetQueryResultDelegate(bool allowLockAllRows);
