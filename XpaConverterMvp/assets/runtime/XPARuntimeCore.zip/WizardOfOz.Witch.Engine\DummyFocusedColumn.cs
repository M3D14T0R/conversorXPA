using System;
using WizardOfOz.Witch.UI;

namespace WizardOfOz.Witch.Engine;

internal class DummyFocusedColumn : FocusedColumn
{
	public bool CanYouExpand()
	{
		return false;
	}

	public void Ditto()
	{
	}

	public bool IsNullable()
	{
		return false;
	}

	public void SetToNull()
	{
	}

	public void DoExpand(Action moveToNextColumnCommand, Action doDefault)
	{
		doDefault();
	}

	public bool Matches(IControl control)
	{
		return false;
	}

	public bool IsEditable()
	{
		return false;
	}
}
