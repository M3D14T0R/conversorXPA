using XPARuntimeCore.Box;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ENV.IO
{
    public class WebContext
    {
        public static ContextStatic<IWebContext> Current
            = new ContextStatic<IWebContext>(() =>
#if NET6_0_OR_GREATER
new WebContextDummy()
#else
            new WebContextDotnetFramework()
#endif
            );
    }
    public interface IWebContext
    {
        string GetPrgName();
        byte[] GetFile(string key);
        string[] GetCookie(string key);
        string[] GetValues(string key);
        string[] GetFormValues(string key);
        bool IsRunningOnWeb();
        string GetFormBody();
        void WriteFile(string path);
        void SetContentType(string value);
        void AppendCookie(string key, string value);
        void AddHeader(string name, string value);
        void WriteInitBytes(byte[] data);
        void Write(string data);
        void LoadTo(Dictionary<string, object> memoryParams);
        void SetEncoding(Encoding encoding);
        void SetCookie(string key, string value);
        string GetUserHostAddress();

        bool IsMethodPost { get; }
        string GetRequestBody();
        string HttpMethod { get; }
        string RawUrl { get; }
        string Path { get; }
        string ContentType { get; set; }
        int StatusCode { get; set; }

        string this[string key] { get; }
    }
}
