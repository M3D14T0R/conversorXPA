using XPARuntimeCore.Box;
using XPARuntimeCore.Box.Data.DataProvider;

namespace ENV.Data.Storage
{
    public class HebrewOemToAnsiTextStorage : XPARuntimeCore.Box.Data.DataProvider.IColumnStorageSrategy<Text>
    {
        XPARuntimeCore.Box.Data.TextColumn _column;

        public HebrewOemToAnsiTextStorage(XPARuntimeCore.Box.Data.TextColumn column)
        {
            _column = column;
        }
        public static bool DoNotDoAnsiToOEMOnLoad = false;

        public Text LoadFrom(IValueLoader loader)
        {
            if (DoNotDoAnsiToOEMOnLoad)
                return UserDbMethods.InternalAdjustOem(loader.GetString(), false);
            else
                return HebrewOemTextStorage.Decode(loader.GetString());
        }

        public void SaveTo(Text value, IValueSaver saver)
        {
            saver.SaveAnsiString(UserDbMethods.InternalAdjustOem(value, true), _column.FormatInfo.MaxDataLength,false);
        }
    }
}
