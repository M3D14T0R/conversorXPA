namespace WizardOfOz.Witch.DataAccess;

internal interface QueryConsumer
{
	void UserResultProvider(QueryResultProvider provider);

	void UseQueryResult(ResetableQueryResult result, SubQueryResultProvider subQueryResultProvider);
}
