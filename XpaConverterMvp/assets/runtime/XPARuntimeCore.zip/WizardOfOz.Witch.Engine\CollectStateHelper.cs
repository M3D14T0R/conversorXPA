using System;
using WizardOfOz.Witch.DataAccess;

namespace WizardOfOz.Witch.Engine;

internal interface CollectStateHelper
{
	void RepositionTo(RowOrientedCursor cursor, Action<WhereToParkAfterRefreshingView> whereToPark, int oldParkedRowIndex);

	DataProviderRow GetTopRow();

	void Repaint();

	DataProviderRow GetRowAtPosition(int i);

	void Clear();

	bool Contains(DataProviderRow oldRow);
}
