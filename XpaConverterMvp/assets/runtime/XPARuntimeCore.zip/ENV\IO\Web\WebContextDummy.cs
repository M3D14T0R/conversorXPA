﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace ENV.IO
{
    internal class WebContextDummy : IWebContext
    {
        public bool IsMethodPost => false;

        

        public string HttpMethod => throw new NotImplementedException();

        public string RawUrl => throw new NotImplementedException();

        public string Path => throw new NotImplementedException();

        public string ContentType { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }
        public int StatusCode { get => throw new NotImplementedException(); set => throw new NotImplementedException(); }

        public string this[string key] => throw new NotImplementedException();

        public void AddHeader(string name, string value)
        {
            throw new NotImplementedException();
        }

        public void AppendCookie(string key, string value)
        {
            throw new NotImplementedException();
        }

        public void WriteInitBytes(byte[] data)
        {
            throw new NotImplementedException();
        }

        public string[] GetCookie(string key)
        {
            throw new NotImplementedException();
        }

        public byte[] GetFile(string key)
        {
            throw new NotImplementedException();
        }

        public string GetFormBody()
        {
            throw new NotImplementedException();
        }

        public string[] GetFormValues(string key)
        {
            throw new NotImplementedException();
        }

        public string GetPrgName()
        {
            throw new NotImplementedException();
        }

        public string GetUserHostAddress()
        {
            throw new NotImplementedException();
        }

        public string[] GetValues(string key)
        {
            throw new NotImplementedException();
        }

        public bool IsRunningOnWeb()
        {
            return false;
        }

        public void LoadTo(Dictionary<string, object> memoryParams)
        {
            throw new NotImplementedException();
        }

        public void SetContentType(string value)
        {
            throw new NotImplementedException();
        }

        public void SetCookie(string key, string value)
        {
            throw new NotImplementedException();
        }

        public void SetEncoding(Encoding encoding)
        {
            throw new NotImplementedException();
        }

        public void Write(string data)
        {
            throw new NotImplementedException();
        }

        public void WriteFile(string path)
        {
            throw new NotImplementedException();
        }

        public string GetRequestBody()
        {
            throw new NotImplementedException();
        }
    }
}