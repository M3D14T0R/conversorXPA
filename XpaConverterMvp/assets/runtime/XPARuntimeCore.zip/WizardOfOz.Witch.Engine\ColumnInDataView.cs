using System;
using XPARuntimeCore.Box.Data.Advanced;
using WizardOfOz.Witch.DataAccess;
using WizardOfOz.Witch.Types;

namespace WizardOfOz.Witch.Engine;

internal class ColumnInDataView : RecomputeItem, StateSaver, ColumnChangeObserver, ColumnQueryObserver
{
	private ColumnBase _column;

	private ColumnExpression _expression;

	private RecomputeManager _recomputeManager;

	private RecomputeItem _myIdentifier;

	private bool _entityColumn;

	public RecomputeInfo Info { get; set; }

	internal ColumnInDataView(RecomputeManager recomputeManager, ColumnBase column)
	{
		_column = column;
		column.AttachValueBindingTo(recomputeManager, delegate(ColumnExpression expression)
		{
			_expression = expression;
		}, this);
		_column.SetChangeObserver(this);
		_recomputeManager = recomputeManager;
		_myIdentifier = this;
		_entityColumn = _column.IsEntityBasedColumn();
	}

	public override string ToString()
	{
		return _column.ToString();
	}

	public void ValueWasSet(bool supressRowChange, ValueChangedHandler valueChanged, ValueChangedHandler valueHasChangedForRecomputeUse, bool becauseOfBindValue)
	{
		_recomputeManager.ValueWasSetFor(_myIdentifier, valueChanged, valueHasChangedForRecomputeUse, supressRowChange, becauseOfBindValue);
	}

	public void DoCompute(bool isNewRow, bool updateOriginalValues, ContextUser contextUser)
	{
		if (isNewRow || !_entityColumn)
		{
			_expression.SetTheColumnAcordingToYou(contextUser, _myIdentifier);
		}
		else
		{
			_expression.ExtractRecomputePathButDoNotRecompute(contextUser, _myIdentifier);
		}
	}

	public void ExtractRecumputePathButDoNotDoCompute(bool inNoRowsState, ContextUser contextUser)
	{
		if (inNoRowsState && !_column.OnChangeMarkRowAsChanged)
		{
			_expression.SetTheColumnAcordingToYou(contextUser, _myIdentifier);
		}
		else
		{
			_expression.ExtractRecomputePathButDoNotRecompute(contextUser, _myIdentifier);
		}
	}

	public void ReComputeBecause(RecomputeItem itemChanged, ContextUser contextUser)
	{
		_expression.RecomputeBecause(itemChanged, contextUser, _myIdentifier);
	}

	public void SetOriginalValue(bool useDefaultValue, bool startOfRow)
	{
		_column.SetOriginalValue(useDefaultValue, startOfRow);
	}

	public void RestoreToStartOfRow()
	{
		_column.RestoreToStartOfRow();
	}

	public bool AreYou(ColumnBase column)
	{
		return _column == column;
	}

	public void ReevaulateControlExpressions(ContextUser contextUser)
	{
	}

	public ReomputeItemChangedChecker GetState()
	{
		return _column.GetStateChangedChecker();
	}

	public void AddToQueryRecomputePathArray(Action<ColumnBase> add)
	{
		add(_column);
	}

	public void AddStateTo(StateCollector stateCollector)
	{
		_column.AddStateTo(stateCollector);
	}

	public void ValueWasQueried()
	{
		_recomputeManager.ValueWasQueriedFor(_myIdentifier);
	}

	public void SetIdentifier(RecomputeItem item)
	{
		_myIdentifier = item;
	}

	internal void CollectRecomputeChangeInRelation(Action<RecomputeChangeInRelation> add, RecomputeItem item)
	{
		_column.CollectRecomputeChangeInRelation(item, add);
	}

	public bool AreYouFrom(IdentifierProvider identifier)
	{
		return identifier.Contains(_column);
	}

	public void ComputeControlExpressionsForNonCurrentRow(ContextUser contextUser)
	{
	}

	public void RecomputeAfterValueChangedEvents(ContextInstance ctx)
	{
	}
}
