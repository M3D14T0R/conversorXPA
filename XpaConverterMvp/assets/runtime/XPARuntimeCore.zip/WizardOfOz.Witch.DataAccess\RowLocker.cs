namespace WizardOfOz.Witch.DataAccess;

internal interface RowLocker
{
	void Lock(DataProviderRow row, bool CheckForChanges);

	void StartOfRow();

	void Unlock();

	bool AllowLock();

	void AfterLockWithCheckChanges();

	void UnlockRelatedRow(DataProviderRow row);
}
