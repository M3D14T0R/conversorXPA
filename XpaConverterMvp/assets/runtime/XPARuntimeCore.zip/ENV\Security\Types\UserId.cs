using System;
using System.Collections.Generic;
using System.Text;
using XPARuntimeCore.Box;

namespace ENV.Security.Types
{
    class UserId:ID
    {
        

        
    }
}
