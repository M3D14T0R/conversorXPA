using System;
using XPARuntimeCore.Box;

namespace WizardOfOz.Witch.Engine;

internal interface ActivityStrategy
{
	bool DoForceDelete { get; }

	void UpdateRowToDatabase(Row row);

	void CreateNewRow(bool allowInsertInUpdateMode, Func<bool> allowInsert, CreateNewRowAndChangeActivityTo createNewRowAfterCurrentPosition, Action cannotCreateRow);

	bool UseEmptyDataView();

	bool DoLocate();

	ActivityStrategy GetStatusForExistingRow();

	void AffectUI(FormForUIController ui);

	void EnableRowActions(Action<bool> enableInsertRow, Action<bool> enableDeleteRow, Action<bool> enableDitto, bool enableInsertRowWhileInsertInUpdate);

	Activities GetMode();

	bool AllowsEditing();

	bool InitialActivityIsLegal(TaskType taskType);

	Number EvaluateCurrentValue(Func<Number> evaluateExpression);

	Number EvaluateOriginalValue(Func<Number> evaluateExpression);

	bool IsNewRow();

	void NoRowsFound(Action insertNewRow, Action<Action<Action>> switchToInsertIfAllowed);

	bool AllowInsert(bool allowInsertInUpdateActivity, bool allowInsert);

	bool IsInsertActivityOrUpdateInInsert();

	bool AllowMovingToExistingRowAfterUndo(Func<bool> updateAllowed);

	bool StayOnNewRowAfterUndo();

	void ReplaceActivityWithActivityOfParent(Action replace);

	bool SuppressCreationOfRowsByRelations();
}
