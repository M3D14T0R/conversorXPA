namespace WizardOfOz.Witch.DataAccess;

internal class QueryResultProviderForEmptyDataView : QueryResultProvider, SubQueryResultProvider
{
	private SubQueryResultProvider _provider;

	public QueryResultProviderForEmptyDataView(QueryResultProvider provider)
		: this(new QueryResultProviderToSubQueryResultProvider(provider))
	{
	}

	public QueryResultProviderForEmptyDataView(SubQueryResultProvider provider)
	{
		_provider = provider;
	}

	public QueryResult After(DataProviderRow row, bool reverse)
	{
		return new EmptyQueryResult();
	}

	public QueryResult AllRows(bool lockAllRows)
	{
		return new EmptyQueryResult();
	}

	public QueryResult Preload()
	{
		return new EmptyQueryResult();
	}

	public DataProviderRow CreateTemporaryNewRow()
	{
		return _provider.CreateTemporaryNewRow();
	}

	public QueryResult FetchRowsThatMatchFilterOrAreAfterIt(FilterCondition filter, bool reverseParkOnRowOrder)
	{
		return new EmptyQueryResult();
	}

	public QueryResult From(DataProviderRow row, bool reverse)
	{
		return new EmptyQueryResult();
	}

	public QueryResult FromEnd()
	{
		return new EmptyQueryResult();
	}

	public QueryResult FromStart()
	{
		return new EmptyQueryResult();
	}

	public bool ProvidesInfiniteQueryResults()
	{
		return _provider.ProvidesInfiniteQueryResults();
	}

	public QueryResult SubFilter(FilterCondition extraFilter)
	{
		return new EmptyQueryResult();
	}
}
