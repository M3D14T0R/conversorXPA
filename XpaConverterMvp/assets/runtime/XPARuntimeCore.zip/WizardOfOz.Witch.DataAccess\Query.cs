using System;
using System.Collections.Generic;
using XPARuntimeCore.Box;
using XPARuntimeCore.Box.Data;
using XPARuntimeCore.Box.Data.Advanced;

namespace WizardOfOz.Witch.DataAccess;

internal interface Query
{
	void AddJoin(Entity t, IEnumerable<ColumnBase> selectedColumns, FilterCondition joinFilter, LookupInAQuery lookup);

	void AddLeftOuterJoin(Entity t, IEnumerable<ColumnBase> selectedColumns, FilterCondition joinFilter, LookupInAQuery lookup);

	void Prepare(ApplyRowToColumnsForManualSort applyRowToColumns, Action notifyThisMayTakeLong, RowsProgressHandler sorting, bool donotFetchSort);

	void Construct(QueryConsumer client, ApplyRowToColumnsForManualSort applyRowToColumns, RowsProgressHandler sorting, bool donotFetchSort);
}
