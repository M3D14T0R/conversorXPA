using System;

namespace WizardOfOz.Witch.DataAccess;

internal class CursorClass : Cursor, IDisposable
{
	private Func<QueryResult> _getQueryResult;

	private ForCursor _forCursor;

	private QueryResult _source;

	public CursorClass(Func<QueryResult> getQueryResult, ForCursor forCursor)
	{
		_getQueryResult = getQueryResult;
		_forCursor = forCursor;
	}

	private QueryResult GetSource()
	{
		if (_source == null)
		{
			try
			{
				_source = _getQueryResult();
			}
			catch
			{
				_forCursor.SetPositionToByondEdgeOfList();
				throw;
			}
		}
		return _source;
	}

	public bool MoveNext()
	{
		if (_forCursor.Reversed())
		{
			return MoveAgainstDirection();
		}
		return MoveWithDirection();
	}

	private bool MoveWithDirection()
	{
		if (_forCursor.PositionBeforeEndOfList())
		{
			_forCursor.Step();
			return true;
		}
		if (_forCursor.OnTheEdgeOfTheList())
		{
			while (GetSource().MoveNext())
			{
				if (_forCursor.TryAddingRowToListAndReturnTrueIfSucceeded(GetSource().Current))
				{
					return true;
				}
			}
			_forCursor.SetPositionToByondEdgeOfList();
			return false;
		}
		return false;
	}

	private bool MoveAgainstDirection()
	{
		if (_forCursor.PositionAfterBeginningOfList())
		{
			_forCursor.StepBack();
			return true;
		}
		if (_forCursor.ThereIsNothingBeyondTheEdgeOfKnownData())
		{
			_forCursor.SetPositionToBeforeBeginningOfList();
			return false;
		}
		return _forCursor.MoveByondTheEdgeOfKnownData();
	}

	public bool MovePrevious()
	{
		if (_forCursor.Reversed())
		{
			return MoveWithDirection();
		}
		return MoveAgainstDirection();
	}

	public void Dispose()
	{
		if (_source != null)
		{
			_source.Dispose();
		}
	}
}
