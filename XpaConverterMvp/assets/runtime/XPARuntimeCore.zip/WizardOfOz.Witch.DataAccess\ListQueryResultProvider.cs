using System;
using System.Collections.Generic;

namespace WizardOfOz.Witch.DataAccess;

internal class ListQueryResultProvider : CachedResult
{
	private class myQueryResult : QueryResult, IDisposable
	{
		private IEnumerator<DataProviderRow> _enumerator;

		public DataProviderRow Current => _enumerator.Current;

		public myQueryResult(IEnumerator<DataProviderRow> enumerator)
		{
			_enumerator = enumerator;
		}

		public bool MoveNext()
		{
			return _enumerator.MoveNext();
		}

		public void Dispose()
		{
		}
	}

	private List<DataProviderRow> _source = new List<DataProviderRow>();

	public ListQueryResultProvider()
	{
	}

	public ListQueryResultProvider(List<DataProviderRow> row)
	{
		_source = row;
	}

	public QueryResult GetQueryResult()
	{
		return new myQueryResult(_source.GetEnumerator());
	}

	public CachedResult Add(DataProviderRow current)
	{
		_source.Add(current);
		return this;
	}
}
