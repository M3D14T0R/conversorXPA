namespace WizardOfOz.Witch.Engine;

internal class CheckIfFlowItemIsControl : UnderlyingUserFlowObjectVisitorBase
{
	public bool Result;

	public override void Iam(ControlForFlow control)
	{
		Result = true;
	}
}
