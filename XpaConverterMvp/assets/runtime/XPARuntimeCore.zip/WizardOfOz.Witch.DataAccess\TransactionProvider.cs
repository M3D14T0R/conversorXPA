using XPARuntimeCore.Box;
using XPARuntimeCore.Box.Data;
using XPARuntimeCore.Box.Data.DataProvider;

namespace WizardOfOz.Witch.DataAccess;

internal interface TransactionProvider
{
	void AddActiveTransactionTo(ITransactionCollector collector, MonitoredDatabaseClient monitorClient);

	void CallMeIfYouHaveTransactions(TaskTransactionalEntitiesInfo andTellMeIfLocksAreOn);
}
