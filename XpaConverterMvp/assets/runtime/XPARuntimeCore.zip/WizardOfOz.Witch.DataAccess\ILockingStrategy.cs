using System;
using XPARuntimeCore.Box;

namespace WizardOfOz.Witch.DataAccess;

internal interface ILockingStrategy : IDisposable
{
	void StartOfRow();

	void RowAboutToBeSavedToDB();

	void UserEdit();

	void Loaded(object context, DataProviderRow row, Action reloadColumnData);

	void LockCurrentRow();

	void RowWasLeft();

	void AboutToRunSavingRow();

	bool LockAllRows(Func<bool> inTransaction, bool isForRelation);

	bool ShouldRollbackOnUndoAndRowTransaction(Activities activity, bool suppressLockingInBrowseMode);

	void RelationRowUnloaded(DataProviderRow row);
}
