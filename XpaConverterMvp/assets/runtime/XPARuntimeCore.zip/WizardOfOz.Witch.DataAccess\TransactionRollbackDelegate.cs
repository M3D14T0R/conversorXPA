namespace WizardOfOz.Witch.DataAccess;

internal delegate void TransactionRollbackDelegate(bool recover);
