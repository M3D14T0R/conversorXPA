namespace WizardOfOz.Witch.Engine;

internal class DummyValueChange : ValueChangedHandler
{
	public static DummyValueChange Instance = new DummyValueChange();

	public bool HasAny => false;

	private DummyValueChange()
	{
	}

	public void ExecuteValueChangedEvent(ContextUser contextUser)
	{
	}
}
