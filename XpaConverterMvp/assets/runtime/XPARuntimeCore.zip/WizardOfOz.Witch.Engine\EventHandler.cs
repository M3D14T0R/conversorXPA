using System;
using System.Windows.Forms;
using XPARuntimeCore.Box;
using XPARuntimeCore.Box.UI.Advanced;
using WizardOfOz.Witch.UI;

namespace WizardOfOz.Witch.Engine;

internal interface EventHandler
{
	void Handle(Command command, CommandInvokationStuff stuff, Action defaultAction);

	void UserAskedToPutString(string text, Action defaultAction);

	void DoUserActionByName(string actionName);

	void CheckKeyContext(KeyContextResult result);

	void Invoke(ListenerRunner runner);

	void ProcessNavigationCommand(Action cmd, Func<bool> abortCommand);

	void RunCustomCommand(CustomCommandPrecondition precondition, Action action, Action<Action<Action>> runBeforeLeavingControl);

	bool ParkedControlIs(ControlBase controlBase);

	void WrapInvokingFromQueue(Command command, Func<IControl, IControl> controlBase, bool doNotRepeatInMultiSelect, Action<IControl> invoke, Action raiseAgain);

	void ProcessUnhandledCommand(Command c, Action doDefault);

	void SendKeys(Keys keys);

	void GoTo(Func<IControl, IControl> control, Command commandToInvokeBefore, Action gotoAction);

	void ExpandParkedColumn();
}
