using WizardOfOz.Witch.UI;

namespace WizardOfOz.Witch.Engine;

internal delegate void ActionWithParameters(IControl control, object[] args);
