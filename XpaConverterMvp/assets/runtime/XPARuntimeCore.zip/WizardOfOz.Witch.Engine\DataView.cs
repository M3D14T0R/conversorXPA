using System.Collections.Generic;

namespace WizardOfOz.Witch.Engine;

internal class DataView
{
	private List<RecomputeItem> _myDataViewList = new List<RecomputeItem>();

	private RecomputeItem[] _myDataView;

	public void Add(RecomputeItem item)
	{
		_myDataViewList.Add(item);
		_myDataView = _myDataViewList.ToArray();
	}

	public void DoCompute(bool newRow, bool updateOriginalValues, ContextUser contextUser, bool isRecompute)
	{
		if (_myDataView == null)
		{
			return;
		}
		RecomputeItem[] myDataView = _myDataView;
		foreach (RecomputeItem recomputeItem in myDataView)
		{
			recomputeItem.DoCompute(newRow, updateOriginalValues, contextUser);
			if (updateOriginalValues)
			{
				recomputeItem.SetOriginalValue(useDefaultValue: false, !isRecompute);
			}
		}
	}

	public void ExtractRecomputePathButDoNotRecompute(ContextUser contextUser, bool inNoRowsState)
	{
		if (_myDataView != null)
		{
			RecomputeItem[] myDataView = _myDataView;
			for (int i = 0; i < myDataView.Length; i++)
			{
				myDataView[i].ExtractRecumputePathButDoNotDoCompute(inNoRowsState, contextUser);
			}
		}
	}

	public void NotifyChangeOnAllItemsInDataViewTo(RecomputeManager recomputeManager)
	{
		if (_myDataView != null)
		{
			RecomputeItem[] myDataView = _myDataView;
			foreach (RecomputeItem item in myDataView)
			{
				recomputeManager.ValueWasSetFor(item, DummyValueChange.Instance, DummyValueChange.Instance, supressRowWasChanged: true, becauseOfBindValue: false);
			}
		}
	}
}
