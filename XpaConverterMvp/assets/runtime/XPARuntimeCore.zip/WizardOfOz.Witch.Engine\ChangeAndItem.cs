using System.Collections.Generic;

namespace WizardOfOz.Witch.Engine;

internal class ChangeAndItem
{
	public ValueChangedHandler _handler;

	private RecomputeItem _item;

	public ChangeAndItem(ValueChangedHandler handler, RecomputeItem item)
	{
		_handler = handler;
		_item = item;
	}

	public void ExecuteValueChangedEvent()
	{
		_handler.ExecuteValueChangedEvent(DummyContextInstance.Instance);
	}

	public bool IsSameAs(RecomputeItem item)
	{
		return _item == item;
	}

	public void RemoveFrom(HashSet<RecomputeItem> itemsUsed)
	{
		itemsUsed.Remove(_item);
	}
}
