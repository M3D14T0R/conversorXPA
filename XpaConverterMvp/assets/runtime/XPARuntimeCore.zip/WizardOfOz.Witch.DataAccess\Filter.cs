using System;
using XPARuntimeCore.Box;
using XPARuntimeCore.Box.Data;
using XPARuntimeCore.Box.Data.Advanced;

namespace WizardOfOz.Witch.DataAccess;

internal interface Filter
{
	void AddBetweenCondition(ColumnBase column, ColumnFilterValue from, ColumnFilterValue to);

	void AddEqual(ColumnBase column, ColumnFilterValue to);

	void AddDifferent(ColumnBase column, ColumnFilterValue from);

	void AddStartsWith(ColumnBase column, ColumnFilterValue to);

	void AddGreaterOrEqual(ColumnBase column, ColumnFilterValue to);

	void AddLessOrEqual(ColumnBase column, ColumnFilterValue to);

	void AddWhere(Action<TranslateToGatewayTerms, Action<string>> whereFactory);

	void AddOr(FilterCondition a, FilterCondition b);

	void AddLessThan(ColumnBase column, ColumnFilterValue to);

	void AddGreaterThan(ColumnBase column, ColumnFilterValue to);

	void AddUserCondition(Func<bool> condition);

	void AddLessOrEqualWithWildcard(TextColumn column, Text value, ColumnFilterValue filterItem);

	void AddTrueCondition();
}
