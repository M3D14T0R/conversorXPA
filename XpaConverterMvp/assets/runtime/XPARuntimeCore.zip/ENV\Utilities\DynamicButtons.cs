using ENV.Data;
using XPARuntimeCore.Box;
using XPARuntimeCore.Box.Data.Advanced;
using XPARuntimeCore.Box.UI;
using XPARuntimeCore.Box.UI.Advanced;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;

namespace ENV.Utilities
{
    public class DynamicButtons
    {
        bool _inited = false;
        bool _expressionsCalced = false;
        bool _suspended = false;

        public class Helper
        {

            DynamicButtons _parent;
            internal Helper(DynamicButtons parent, int i)
            {
                _parent = parent;
                _myRowIndex = i;
            }
            int _myRowIndex;

            string rowToKey() => string.Join(",", _parent.abstractUIController.From.PrimaryKeyColumns.Select(x => x.Value.ToString()));

            public ButtonClickEventHandler Bind(ButtonClickEventHandler exp)
            {
                return (x, y) =>
                {
                    GotoTheRow(() => exp(x, y));
                };
            }
            public BindingEventHandler<StringBindingEventArgs> Bind(Func<string> exp)
            {
                var result = GetRowValueFor(exp);
                return (_, e) =>
                {
                    if (!_parent._suspended)
                        e.Value = result();
                };
            }
            Func<T> GetUnique<T>(object item, Func<T> mappedItem)
            {
                if (_parent._uniqueObjectMapping.TryGetValue(item, out var existing))
                {
                    return (Func<T>)existing;
                }
                _parent._uniqueObjectMapping[item] = mappedItem;
                return mappedItem;

            }
            public BindingEventHandler<IntBindingEventArgs> Bind(BindingEventHandler<IntBindingEventArgs> y, string what = null)
            {
                return Bind(GetUnique(y, () =>
                {
                    var x = new IntBindingEventArgs(0);
                    y(null, x);
                    return x.Value;
                }), what);

            }
            public BindingEventHandler<StringBindingEventArgs> Bind(BindingEventHandler<StringBindingEventArgs> y)
            {
                return Bind(GetUnique(y, () =>
                {
                    var x = new StringBindingEventArgs("");
                    y(null, x);
                    return x.Value;
                }));

            }
            public BindingEventHandler<BooleanBindingEventArgs> Bind(BindingEventHandler<BooleanBindingEventArgs> y)
            {
                return Bind(GetUnique(y, () =>
                {
                    var x = new BooleanBindingEventArgs(false);
                    y(null, x);
                    return x.Value;
                }));

            }
            public BindingEventHandler<ColorSchemeBindingEventArgs> Bind(BindingEventHandler<ColorSchemeBindingEventArgs> y)
            {
                return Bind(GetUnique(y, () =>
                {
                    var x = new ColorSchemeBindingEventArgs(null);
                    y(null, x);
                    return x.Value;
                }));
            }
            public BindingEventHandler<BooleanBindingEventArgs> Bind(Func<bool> exp)
            {
                var result = GetRowValueFor(exp);
                return (_, e) =>
                {
                    if (!_parent._suspended)
                        e.Value = result();
                };
            }
            public BindingEventHandler<ColorSchemeBindingEventArgs> Bind(Func<ColorScheme> exp)
            {
                var result = GetRowValueFor(exp);
                return (_, e) =>
                {
                    if (!_parent._suspended)
                        e.Value = result();
                };
            }
            public BindingEventHandler<IntBindingEventArgs> Bind(Func<int> exp, string what = null)
            {
                var result = GetRowValueFor(exp, what);
                return (_, e) =>
                {
                    if (!_parent._suspended)
                        e.Value = result();
                };
            }

            public Func<T> GetRowValueFor<T>(Func<T> exp, string what = null)
            {
                Dictionary<string, object> formatPerRow;
                if (!this._parent.expressionRowValues.TryGetValue(exp, out formatPerRow))
                {
                    formatPerRow = new Dictionary<string, object>();
                    _parent._recompute.Add(() =>
                    {
                        formatPerRow[rowToKey()] = exp();
                    });
                    _parent.expressionRowValues.Add(exp, formatPerRow);


                }
                var i = _myRowIndex;
                return () =>
                {
                    var result = _parent.keyPerIndex.Count > i ? (T)formatPerRow[_parent.keyPerIndex[i]] : default(T);
                    if (what != null)
                        Debug.WriteLine($"{what} for row {i} is {result}");
                    return result;
                };

            }

            internal void InitRow(int i, FilterBase f)
            {
                var rowKey = rowToKey();
                _parent.keyPerIndex[i] = rowKey;
                _parent.filterPerIndex[i] = f;
                if (_controlsRemoved)
                {
                    _parent.view.Controls.AddRange(_controls.ToArray());
                    _controlsRemoved = false;
                }
                foreach (var item in _parent._recompute)
                {
                    item();
                }
            }

            public void GotoTheRow(Action andDoOnRow)
            {
                if (FilterCollection.IsTrue(_parent.filterPerIndex[this._myRowIndex]))
                {
                    andDoOnRow?.Invoke();
                    return;
                }
                _parent.abstractUIController._uiController.SaveRowAndDo(o =>
                {
                    o.GoToRow(_parent.filterPerIndex[this._myRowIndex]);
                    andDoOnRow?.Invoke();
                });

            }
            public void AddControl(ControlBase control)
            {
                _controls.Add(control);
                _parent.view.Controls.Add(control);

            }
            bool _controlsRemoved = false;
            List<ControlBase> _controls = new List<ControlBase>();
            internal void RemoveYourControls()
            {
                if (_controlsRemoved)
                    return;
                _controlsRemoved = true;
                foreach (var item in _controls)
                {
                    item.Parent.Controls.Remove(item);
                }
            }

            public ControlData DataFor(TextColumn teurParit)
            {
                return ControlData.FromText(GetRowValueFor(() => teurParit.Value));
            }
            public ControlData DataFor(Func<Text> teurParit)
            {
                return ControlData.FromText(GetRowValueFor(() => teurParit()));
            }
            public ControlData DataFor(NumberColumn column)
            {
                return ControlData.FromNumber(GetRowValueFor(() => column.Value));
            }
            public EventHandler OnClickGotoRow()
            {
                return delegate { this.GotoTheRow(null); };
            }
            internal void ReApplyProperties()
            {
                foreach (var item in _controls)
                {
                    if (item is ControlBase x)
                        x.ReApplyProperties();
                }
            }
        }
        AbstractUIController abstractUIController;
        List<Action> _recompute = new List<Action>();
        Dictionary<int, string> keyPerIndex = new Dictionary<int, string>();
        Dictionary<int, FilterBase> filterPerIndex = new Dictionary<int, FilterBase>();
        Dictionary<object, Dictionary<string, object>> expressionRowValues = new Dictionary<object, Dictionary<string, object>>();
        Dictionary<object, object> _uniqueObjectMapping = new Dictionary<object, object>();
        ENV.UI.Form view;
        public void Init<T, U>(AbstractUIController abstractUIController, Func<U> createButton,
            Func<Number> leftExpression,
            Func<Number> topExpression, Func<Number> widthExpression, Func<Number> heightExpression,
            Func<Text> formatExpression,
            Func<T> buttonId,
            Func<T, FilterBase> rowFilterForButtonId,
            Command command,
            Func<Bool> enabledExpression = null,
            Func<Bool> visibleExpression = null,
            Func<ColorScheme> colorExpression = null,
            ENV.UI.Form view = null) where U : XPARuntimeCore.Box.UI.Advanced.ControlBase
        {
            InitNew(view, abstractUIController, buttonId, rowFilterForButtonId, h =>
            {
                var b = createButton();

                b.BindLeft += h.Bind(() => this.view.ToPixelHorizontal(leftExpression()));
                b.BindTop += h.Bind(() => this.view.ToPixelVertical(topExpression()));
                if (widthExpression != null)
                    b.BindWidth += h.Bind(() => this.view.ToPixelHorizontal(widthExpression()));
                if (heightExpression != null)
                    b.BindHeight += h.Bind(() => this.view.ToPixelVertical(heightExpression()));

                if (enabledExpression != null)
                    b.BindEnabled += h.Bind(() => enabledExpression());
                if (visibleExpression != null)
                    b.BindVisible += h.Bind(() => visibleExpression());
                if (colorExpression != null)
                    b.BindColorScheme += h.Bind(() => colorExpression());

                var tb = b as ENV.UI.TextBox;
                if (tb != null)
                {
                    tb.Data = ControlData.FromText(h.GetRowValueFor(formatExpression));
                    tb.Enter += () =>
                    {
                        h.GotoTheRow(null);
                    };
                    tb.Click += (s, a) =>
                    {
                        h.GotoTheRow(null);
                    };
                }
                var btn = b as ENV.UI.Button;
                if (btn != null)
                {
                    btn.BindFormat += h.Bind(() => formatExpression());
                    btn.Click += (s, a) =>
                    {
                        var b1 = s as ENV.UI.Button;
                        if (!b1.Enabled) return;
                        h.GotoTheRow(() => abstractUIController.Raise(command));
                    };
                }


                h.AddControl(b);

            });
        }
        Action _triggerRecompute;
        public void InitNew<T>(ENV.UI.Form view, AbstractUIController abstractUIController,
    Func<T> buttonId,
    Func<T, FilterBase> rowFilterForButtonId, Action<Helper> addRowLevelControls
    )
        {
            if (_inited) return;
            _inited = true;

            this.abstractUIController = abstractUIController;
            var tc = new ENV.Data.TextColumn();
            _triggerRecompute = () => tc.SilentSet(" ");
            abstractUIController.Columns.Add(tc).BindValue(() =>
            {
                foreach (var item in _recompute)
                {
                    item();
                }
                return "";
            });
            var buttons = new List<Helper>();
            var uic = abstractUIController._uiController;

            this.view = view ?? uic.View as ENV.UI.Form;


            for (int i = 0; i < 9 * 8; i++)
            {
                var h = new Helper(this, i);
                buttons.Add(h);
                addRowLevelControls(h);

            }
            abstractUIController.Handlers.Add(Command.ReloadData).Invokes += e =>
            {
                _expressionsCalced = false;
            };

            Action init = () =>
            {
                if (_expressionsCalced) return;
                _expressionsCalced = true;
                keyPerIndex.Clear();
                filterPerIndex.Clear();
                var i = 0;
                _suspended = true;
                uic.ReadAllRows(() =>
                {
                    if (i >= buttons.Count) return;
                    var h = buttons[i];
                    h.InitRow(i++, rowFilterForButtonId(buttonId()));

                });
                _suspended = false;
                for (; i < buttons.Count; i++)
                {
                    var b = buttons[i];
                    b.RemoveYourControls();
                }
                tc.SilentSet("");
                //foreach (var item in buttons)
                //{
                //    item.ReApplyProperties();
                //}

                //   Form.CompleteUIChanges();
            };

            abstractUIController.EnterRow += init;
            abstractUIController.End += init;
        }

        static string AddSlashBeforeEachChar(string original)
        {
            if (string.IsNullOrEmpty(original)) return original;
            var result = string.Empty;
            foreach (var c in original)
            {
                result += "\\" + c;
            }
            return result;
        }
    }
}
