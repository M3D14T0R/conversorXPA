namespace WizardOfOz.Witch.Engine;

internal class DummyGridParkedRow : GridParkedRow
{
	public void MoveDownOne()
	{
	}

	public void MoveUpOne()
	{
	}
}
