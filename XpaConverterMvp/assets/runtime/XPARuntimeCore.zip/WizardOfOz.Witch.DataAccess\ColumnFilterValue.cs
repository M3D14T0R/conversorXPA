using System;
using XPARuntimeCore.Box.Data;
using XPARuntimeCore.Box.Data.Advanced;

namespace WizardOfOz.Witch.DataAccess;

internal interface ColumnFilterValue : WhereMeaningfullItem
{
	int CompareToCurrentValueOfColumn();

	bool IsEqualToCurrentValueOfColumn(bool ignoreCase);

	bool CompareIfCurrentValueStartsWithYourValue(bool ignoreCase);

	int CompareTo(object value);

	int CompareTo(ColumnFilterValue value);

	bool DoesValuesStartsWithYou(string s);

	void FixYourValue();

	bool IsNull();

	void Visit(ColumnFilterValueVisitor visitor);

	void IfYouBelongTo(Entity referenceEntity, Action<ColumnBase, ColumnFilterValue> call);
}
