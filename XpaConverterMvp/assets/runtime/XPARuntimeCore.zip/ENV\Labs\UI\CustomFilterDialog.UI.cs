using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using XPARuntimeCore.Box;
using XPARuntimeCore.Box.Data.Advanced;

namespace ENV.Labs.UI
{
    partial class CustomFilterDialogUI : ENV.UI.Form
    {
        Action _applyFilter;

        public CustomFilterDialogUI(Action applyFilter)
        {
            _applyFilter = applyFilter;
            InitializeComponent();
            BackColor = Labs.FaceLiftDemo.BackGroundColor;

        }

        private void okButton_Click(object sender, XPARuntimeCore.Box.UI.Advanced.ButtonClickEventArgs e)
        {
            _applyFilter();
            XPARuntimeCore.Box.Context.Current.InvokeUICommand(() =>
            {
                Close();
            });
        }

        private void cancelButton_Click(object sender, XPARuntimeCore.Box.UI.Advanced.ButtonClickEventArgs e)
        {
            XPARuntimeCore.Box.Context.Current.InvokeUICommand(() => { 
            Close();
            });
        }

        private void label2_BindVisible(object sender, XPARuntimeCore.Box.UI.Advanced.BooleanBindingEventArgs e)
        {
            e.Value = filterTypeComboBox.Text == "Is Between";
        }
    }
}