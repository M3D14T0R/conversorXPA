namespace WizardOfOz.Witch.Engine;

internal delegate bool DontMoveTheFirstTime();
