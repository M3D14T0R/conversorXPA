using System;
using System.Collections.Generic;
using XPARuntimeCore.Box;
using XPARuntimeCore.Box.Data;
using XPARuntimeCore.Box.Data.Advanced;

namespace WizardOfOz.Witch.DataAccess;

internal class DummyQuery : Query, QueryResult, IDisposable, QueryResultProvider
{
	private DataProviderRow _current;

	public DataProviderRow Current => _current;

	public QueryResult SubFilter(FilterCondition extraFilter)
	{
		return this;
	}

	public QueryResult FromStart()
	{
		return this;
	}

	public QueryResult From(DataProviderRow row, bool reverse)
	{
		return this;
	}

	public DataProviderRow CreateTemporaryNewRow()
	{
		return new DummyNewDataProviderRow();
	}

	public bool ProvidesInfiniteQueryResults()
	{
		return true;
	}

	public QueryResult AllRows(bool lockAllRows)
	{
		return this;
	}

	public QueryResult Preload()
	{
		return this;
	}

	public QueryResult FromEnd()
	{
		return this;
	}

	public QueryResult After(DataProviderRow row, bool reverse)
	{
		return this;
	}

	public QueryResult FetchRowsThatMatchFilterOrAreAfterIt(FilterCondition filter, bool reverseParkOnRowOrder)
	{
		return this;
	}

	public QueryResultProvider Reversed()
	{
		return this;
	}

	public void Construct(QueryConsumer client, ApplyRowToColumnsForManualSort a, RowsProgressHandler sorting, bool donotFetchSort)
	{
		client.UserResultProvider(this);
	}

	public void Dispose()
	{
	}

	public bool MoveNext()
	{
		_current = DummyDataProviderRow.Instance;
		return true;
	}

	public void Reset()
	{
	}

	public void AddJoin(Entity t, IEnumerable<ColumnBase> selectedColumns, FilterCondition joinFilter, LookupInAQuery lookup)
	{
		throw new InvalidOperationException("cant add join to duumy query");
	}

	public void AddLeftOuterJoin(Entity t, IEnumerable<ColumnBase> selectedColumns, FilterCondition joinFilter, LookupInAQuery lookup)
	{
		throw new InvalidOperationException("cant add join to duumy query");
	}

	public void Prepare(ApplyRowToColumnsForManualSort applyRowToColumns, Action notifyThisMayTakeLong, RowsProgressHandler sorting, bool donotFetchSort)
	{
	}
}
