using System;
using System.Collections.Generic;
using XPARuntimeCore.Box.Engine;
using XPARuntimeCore.Box.Testing;
using WizardOfOz.Witch.DataAccess;

namespace WizardOfOz.Witch.Engine;

internal class CachedRowsNavigator : RowsNavigator, IDisposable
{
	private class myCursorWrapper : Cursor, IDisposable
	{
		private CachedRowsNavigator _parent;

		private Cursor _cursor;

		public myCursorWrapper(CachedRowsNavigator parent, Cursor cursor)
		{
			_parent = parent;
			_cursor = cursor;
		}

		public void Dispose()
		{
			_cursor.Dispose();
		}

		public bool MoveNext()
		{
			bool x = _cursor.MoveNext();
			if (!x)
			{
				_parent._cacheStrategy.RetryCursorPastEdgeRows(delegate
				{
					_parent.DisposeCursors();
					_parent.SetForwardCursor();
					x = _parent._cursor.MoveNext();
				});
			}
			if (x)
			{
				if (++_parent._scrollBarIndex >= _parent._scrollBarCount)
				{
					_parent._scrollBarCount++;
				}
				return true;
			}
			_parent._scrollBarIndex = _parent._scrollBarCount;
			return false;
		}

		public bool MovePrevious()
		{
			bool x = _cursor.MovePrevious();
			if (!x)
			{
				_parent._cacheStrategy.RetryCursorPastEdgeRows(delegate
				{
					_parent.DisposeCursors();
					_parent.SetForwardCursor();
					x = _parent._cursor.MovePrevious();
				});
			}
			if (x)
			{
				if (_parent._scrollBarIndex <= 0)
				{
					_parent._scrollBarCount++;
				}
				else
				{
					_parent._scrollBarIndex--;
				}
				return true;
			}
			_parent._scrollBarIndex = -1;
			return false;
		}
	}

	private class ForForwardCursor : ForCursor
	{
		private CachedRowsNavigator _parent;

		public ForForwardCursor(CachedRowsNavigator parent)
		{
			_parent = parent;
		}

		public bool PositionBeforeEndOfList()
		{
			return _parent._position < _parent._list.Count - 1;
		}

		public void Step()
		{
			_parent._position++;
		}

		public bool OnTheEdgeOfTheList()
		{
			return _parent._position == _parent._list.Count - 1;
		}

		public bool TryAddingRowToListAndReturnTrueIfSucceeded(DataProviderRow dataProviderRow)
		{
			if (!_parent.TryToAddRowToCacheAndReturnTrueIfSucceeded(dataProviderRow, trueToInsertAtBeginningOfList: false))
			{
				return false;
			}
			_parent._position++;
			_parent._cacheStrategy.RowAdded(_parent._list.Count, delegate
			{
				_parent._list.RemoveAt(0);
				_parent._firstReached = false;
				_parent._position--;
				if (_parent._backCursor != null)
				{
					_parent._backCursor.Dispose();
					_parent._backCursor = null;
				}
			});
			return true;
		}

		public void SetPositionToByondEdgeOfList()
		{
			_parent._lastReached = true;
			_parent._position = _parent._list.Count;
		}

		public bool PositionAfterBeginningOfList()
		{
			return _parent._position > 0;
		}

		public void StepBack()
		{
			_parent._position--;
		}

		public bool MoveByondTheEdgeOfKnownData()
		{
			if (_parent._backCursor == null)
			{
				_parent._backCursor = new CursorClass(delegate
				{
					DataProviderRow anchorRow = _parent.GetAnchorRow(fromEnd: false);
					return (anchorRow != null) ? _parent._resultProvider.After(anchorRow, reverse: true) : _parent._resultProvider.FromEnd();
				}, new ForBackCursor(_parent));
			}
			_parent._cursor = _parent._backCursor;
			return _parent._cursor.MovePrevious();
		}

		public bool Reversed()
		{
			return false;
		}

		public void SetPositionToBeforeBeginningOfList()
		{
			_parent._position = -1;
		}

		public bool ThereIsNothingBeyondTheEdgeOfKnownData()
		{
			if (_parent._firstReached)
			{
				return !_parent._cacheStrategy.AlwaysLookBeyondTheEdgeOfKnownData();
			}
			return false;
		}
	}

	private class ForBackCursor : ForCursor
	{
		private CachedRowsNavigator _parent;

		public ForBackCursor(CachedRowsNavigator parent)
		{
			_parent = parent;
		}

		public bool PositionBeforeEndOfList()
		{
			return _parent._position > 0;
		}

		public void Step()
		{
			_parent._position--;
		}

		public bool OnTheEdgeOfTheList()
		{
			return _parent._position == 0;
		}

		public bool TryAddingRowToListAndReturnTrueIfSucceeded(DataProviderRow dataProviderRow)
		{
			if (!_parent.TryToAddRowToCacheAndReturnTrueIfSucceeded(dataProviderRow, trueToInsertAtBeginningOfList: true))
			{
				return false;
			}
			_parent._cacheStrategy.RowAdded(_parent._list.Count, delegate
			{
				_parent._list.RemoveAt(_parent._list.Count - 1);
				_parent._lastReached = false;
				if (_parent._forwardCursor != null)
				{
					_parent._forwardCursor.Dispose();
					_parent._forwardCursor = null;
				}
			});
			return true;
		}

		public void SetPositionToByondEdgeOfList()
		{
			_parent._firstReached = true;
			_parent._position = -1;
		}

		public bool PositionAfterBeginningOfList()
		{
			return _parent._position < _parent._list.Count - 1;
		}

		public void StepBack()
		{
			_parent._position++;
		}

		public bool MoveByondTheEdgeOfKnownData()
		{
			_parent.SetForwardCursor();
			return _parent._cursor.MoveNext();
		}

		public bool Reversed()
		{
			return true;
		}

		public void SetPositionToBeforeBeginningOfList()
		{
			_parent._position = _parent._list.Count;
		}

		public bool ThereIsNothingBeyondTheEdgeOfKnownData()
		{
			if (_parent._lastReached)
			{
				return !_parent._cacheStrategy.AlwaysLookBeyondTheEdgeOfKnownData();
			}
			return false;
		}
	}

	private class SingleRowCursor : Cursor, IDisposable
	{
		private CachedRowsNavigator _parent;

		private ForCursor _forwardCursor;

		private ForCursor _backCursor;

		public SingleRowCursor(CachedRowsNavigator parent)
		{
			_parent = parent;
			_forwardCursor = new ForForwardCursor(_parent);
			_backCursor = new ForBackCursor(_parent);
		}

		public bool MoveNext()
		{
			if (_forwardCursor.OnTheEdgeOfTheList())
			{
				return _backCursor.MoveByondTheEdgeOfKnownData();
			}
			_forwardCursor.Step();
			return true;
		}

		public bool MovePrevious()
		{
			if (_backCursor.OnTheEdgeOfTheList())
			{
				return _forwardCursor.MoveByondTheEdgeOfKnownData();
			}
			_backCursor.Step();
			return true;
		}

		public void Dispose()
		{
		}
	}

	private class StateForRerun
	{
		public List<DataProviderRow> List;

		public bool FirstReached;

		public bool LastReached;
	}

	private List<DataProviderRow> _list;

	private QueryResultProvider _resultProvider;

	private bool _firstReached;

	private bool _lastReached;

	private CacheStrategy _cacheStrategy;

	private int _scrollBarIndex = -1;

	private int _scrollBarCount;

	private RowsOnScreen _rowsOnScreen;

	private int _position = -1;

	private DataProviderRow _tempAnchor;

	private List<DataProviderRow> _rowsToReload = new List<DataProviderRow>();

	private Cursor _cursor;

	private Cursor _forwardCursor;

	private Cursor _backCursor;

	public DataProviderRow CurrentRow => _list[_position];

	public Cursor Cursor => new myCursorWrapper(this, _cursor);

	public CachedRowsNavigator(QueryResultProvider source, CacheStrategy cacheStrategy, RowsOnScreen rowsOnScreen)
	{
		_list = new List<DataProviderRow>();
		_resultProvider = source;
		_cacheStrategy = cacheStrategy;
		_rowsOnScreen = rowsOnScreen;
	}

	private bool TryToAddRowToCacheAndReturnTrueIfSucceeded(DataProviderRow row, bool trueToInsertAtBeginningOfList)
	{
		if (_rowsOnScreen.RowExists(row) && _list.Exists((DataProviderRow providerRow) => providerRow.IsEqualTo(row)))
		{
			return false;
		}
		if (trueToInsertAtBeginningOfList)
		{
			_list.Insert(0, row);
		}
		else
		{
			_list.Add(row);
		}
		return true;
	}

	public void AssertCachedRowsCount(int count)
	{
		Should.Equal(count, _list.Count);
	}

	public QueryResult FetchRowsThatMatchFilterOrAreAfterIt(FilterCondition filter, bool reverseParkOnRowOrder)
	{
		return _resultProvider.FetchRowsThatMatchFilterOrAreAfterIt(filter, reverseParkOnRowOrder);
	}

	public SavedState SavePositionState()
	{
		int savedPosition = _position;
		return new SavedStateCommand(delegate
		{
			_position = savedPosition;
		});
	}

	public bool ShouldCreateANewRowIfAtEnd()
	{
		return true;
	}

	public int IndexOf(DataProviderRow row)
	{
		return _list.IndexOf(row);
	}

	public DataProviderRow GetRowAt(int index)
	{
		return _list[index];
	}

	public void ProvideStateForScrollBar(StateForScrollBar toMe)
	{
		toMe(_scrollBarIndex, _scrollBarCount, _firstReached, _lastReached);
	}

	private DataProviderRow GetAnchorRow(bool fromEnd)
	{
		if (_list.Count == 0)
		{
			return _tempAnchor;
		}
		int num = -1;
		if (fromEnd && _position >= 0)
		{
			num = _list.FindLastIndex(Math.Min(_position, _list.Count - 1), (DataProviderRow row) => !row.IsNewRow());
		}
		else if (!fromEnd && _position < _list.Count)
		{
			num = _list.FindIndex(Math.Max(_position, 0), (DataProviderRow row) => !row.IsNewRow());
		}
		if (num == -1)
		{
			return _tempAnchor;
		}
		_tempAnchor = null;
		return _list[num];
	}

	public void PrepareForCollectStateForGrid(Action cacheCleared, Action reloadRowsWhileCollectingState)
	{
		_cacheStrategy.ClearCache(delegate
		{
			ClearCache();
			cacheCleared();
		});
	}

	public void RefreshDisplayedData(Action reloadDisplayedRows)
	{
	}

	public void YouAreReplacing(RowsNavigator rowsNavigator)
	{
	}

	public void AddRowToReloadTheNextTimeItBecomesCurrent(DataProviderRow row)
	{
		_rowsToReload.Add(row);
	}

	public bool ShouldReloadCurrentRow()
	{
		return _rowsToReload.Remove(CurrentRow);
	}

	public void ReloadDataInInsertActivity(Action switchToUpdateActivity)
	{
		switchToUpdateActivity();
	}

	public void ActivateRowNavigationCommands(Action<RowNavigationCommandsActivator> listener)
	{
		_cacheStrategy.NotifyCurrentRowChangedListener(new RowNavigationCommandsActivatorClass(_firstReached && _position <= 0, _lastReached && _position >= _list.Count - 1), listener);
	}

	public bool ShouldReloadEachRowDataWhenRefreshingDisplayedData()
	{
		return _cacheStrategy.ShouldReloadEachRowDataWhenRefreshingDisplayedData();
	}

	public void DisablePagingCommands(ActionForDisablePagingCommands action)
	{
		_cacheStrategy.DisablePagingCommands(delegate
		{
			action((_firstReached && _list.Count > 0) ? _list[0] : null, (_lastReached && _list.Count > 0) ? _list[_list.Count - 1] : null);
		});
	}

	public void ClearCache()
	{
		if (_list.Count != 0 && (_list.Count != 1 || !_list[0].IsNewRow()))
		{
			DataProviderRow currentRow = CurrentRow;
			DataProviderRow previousRow = null;
			if (_position > 0)
			{
				previousRow = _list[_position - 1];
			}
			Clear(-1);
			if (currentRow != null)
			{
				SetPositionTo(currentRow, previousRow, clearCache: false, new RefechCurrentRowRefetchStrategy(reverseFetching: true));
			}
			else
			{
				ClearAndGoToBeforeStartOfRows();
			}
		}
	}

	private void Clear(int startingPosition, bool clearScrollBarState = true)
	{
		_list.Clear();
		_rowsToReload.Clear();
		_position = startingPosition;
		if (clearScrollBarState)
		{
			_scrollBarCount = 0;
			_scrollBarIndex = startingPosition;
		}
		_firstReached = false;
		_lastReached = false;
		DisposeCursors();
		_tempAnchor = null;
	}

	private void DisposeCursors()
	{
		if (_forwardCursor != null)
		{
			_forwardCursor.Dispose();
			_forwardCursor = null;
		}
		if (_backCursor != null)
		{
			_backCursor.Dispose();
			_backCursor = null;
		}
	}

	public void GoToBeforeStartOfRows()
	{
		bool clear = !_firstReached;
		_cacheStrategy.ClearCache(delegate
		{
			clear = true;
		});
		if (clear)
		{
			ClearAndGoToBeforeStartOfRows();
		}
		else
		{
			_scrollBarIndex = (_position = -1);
		}
	}

	private void ClearAndGoToBeforeStartOfRows()
	{
		Clear(-1);
		_forwardCursor = new CursorClass(() => _resultProvider.FromStart(), new ForForwardCursor(this));
		_cursor = _forwardCursor;
		_firstReached = true;
	}

	public void GoToAfterEndOfRows()
	{
		bool clear = !_lastReached;
		_cacheStrategy.ClearCache(delegate
		{
			clear = true;
		});
		if (clear)
		{
			ClearAndGoToAfterEndOfRows();
		}
		else
		{
			_scrollBarIndex = (_position = _list.Count);
		}
	}

	private void ClearAndGoToAfterEndOfRows()
	{
		Clear(0);
		_backCursor = new CursorClass(() => _resultProvider.FromEnd(), new ForBackCursor(this));
		_cursor = _backCursor;
		_lastReached = true;
	}

	public void SetPositionTo(DataProviderRow row, bool clearCache, CurrentRowRefetchStrategy currentRowRefetchStrategy)
	{
		SetPositionTo(row, null, clearCache, currentRowRefetchStrategy);
	}

	private void SetPositionTo(DataProviderRow row, DataProviderRow previousRow, bool clearCache, CurrentRowRefetchStrategy currentRowRefetchStrategy)
	{
		if (row == null)
		{
			ClearAndGoToBeforeStartOfRows();
			return;
		}
		bool reallyClearCache = false;
		if (clearCache)
		{
			_cacheStrategy.ClearCache(delegate
			{
				reallyClearCache = true;
			});
		}
		int i = 0;
		if ((i = _list.FindIndex((DataProviderRow providerRow) => DataProviderRowComparer.AreRowsSame(providerRow, row))) != -1 && !reallyClearCache)
		{
			_scrollBarIndex += i - _position;
			_position = i;
			return;
		}
		if (i != -1)
		{
			Clear(-1, clearScrollBarState: false);
			_scrollBarIndex += i - _position;
		}
		else
		{
			Clear(-1);
		}
		Action<DataProviderRow> insertRow = delegate(DataProviderRow r)
		{
			_list.Insert(0, r);
			_position++;
			if (i == -1)
			{
				_scrollBarIndex++;
				_scrollBarCount++;
			}
		};
		DataProviderRow anchorRow = row;
		if (row.IsNewRow())
		{
			insertRow(row);
			anchorRow = previousRow;
		}
		Action<DataProviderRow> insertAnchorRow = delegate(DataProviderRow r)
		{
			insertRow(r);
			_cursor = new SingleRowCursor(this);
			_tempAnchor = _list[0];
		};
		currentRowRefetchStrategy.Refetch(delegate(bool reverseFetching, bool ifNotFoundGotoLastRow)
		{
			DataProviderRow dataProviderRow = null;
			try
			{
				using QueryResult queryResult = _resultProvider.From(anchorRow, reverseFetching);
				if (queryResult.MoveNext())
				{
					dataProviderRow = queryResult.Current;
				}
			}
			finally
			{
				if (dataProviderRow != null)
				{
					insertAnchorRow(dataProviderRow);
				}
				else if (ifNotFoundGotoLastRow)
				{
					ClearAndGoToAfterEndOfRows();
					Cursor.MovePrevious();
				}
				else
				{
					ClearAndGoToBeforeStartOfRows();
					Cursor.MoveNext();
				}
			}
		}, delegate
		{
			insertAnchorRow(anchorRow);
		});
	}

	public void InsertRowAfterCurrentPosition()
	{
		DataProviderRow item = _resultProvider.CreateTemporaryNewRow();
		if (_position < _list.Count)
		{
			_position++;
		}
		_list.Insert(_position, item);
		if (_scrollBarIndex < _scrollBarCount)
		{
			_scrollBarIndex++;
		}
		_scrollBarCount++;
	}

	public void RemoveCurrentRow(bool andMoveBackOneRow)
	{
		if (_list.Count == 1 && _position == 0 && !_list[0].IsNewRow())
		{
			_tempAnchor = _list[0];
		}
		_list.RemoveAt(_position);
		_scrollBarCount--;
		if (andMoveBackOneRow)
		{
			_position--;
			_scrollBarIndex--;
		}
	}

	public bool PositionOutsideKnownList()
	{
		if (_position >= 0)
		{
			return _position >= _list.Count;
		}
		return true;
	}

	private void SetForwardCursor()
	{
		if (_forwardCursor == null)
		{
			_forwardCursor = new CursorClass(delegate
			{
				DataProviderRow anchorRow = GetAnchorRow(fromEnd: true);
				return (anchorRow != null) ? _resultProvider.After(anchorRow, reverse: false) : _resultProvider.FromStart();
			}, new ForForwardCursor(this));
		}
		_cursor = _forwardCursor;
	}

	public void Dispose()
	{
		Clear(-1);
	}

	public bool CurrentRowIsLast()
	{
		if (_lastReached)
		{
			return _position == _list.Count - 1;
		}
		return false;
	}

	public void ProvideStateForRerun(Action<object> toMe)
	{
		_cacheStrategy.ProvideStateForRerun(delegate
		{
			toMe(new StateForRerun
			{
				List = new List<DataProviderRow>(_list),
				FirstReached = _firstReached,
				LastReached = _lastReached
			});
		});
	}

	public void RestoreState(object state)
	{
		if (state is StateForRerun stateForRerun)
		{
			_list = stateForRerun.List;
			_firstReached = stateForRerun.FirstReached;
			_lastReached = stateForRerun.LastReached;
			SetForwardCursor();
		}
	}
}
