using System;

namespace WizardOfOz.Witch.DataAccess;

internal interface QueryResult : IDisposable
{
	DataProviderRow Current { get; }

	bool MoveNext();
}
