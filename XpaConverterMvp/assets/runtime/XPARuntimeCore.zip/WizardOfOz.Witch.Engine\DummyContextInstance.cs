using System;

namespace WizardOfOz.Witch.Engine;

internal class DummyContextInstance : ContextInstance, ContextUser, IDisposable
{
	public static DummyContextInstance Instance = new DummyContextInstance();

	private DummyContextInstance()
	{
	}

	public void NeedContext()
	{
	}

	public void Dispose()
	{
	}
}
