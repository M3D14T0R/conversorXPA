namespace WizardOfOz.Witch.Engine;

internal interface ColumnExpression
{
	void ExtractRecomputePathButDoNotRecompute(ContextUser contextUser, RecomputeItem identifier);

	void SetTheColumnAcordingToYou(ContextUser contextUser, RecomputeItem identifier);

	void RecomputeBecause(RecomputeItem changed, ContextUser contextUser, RecomputeItem identifier);
}
