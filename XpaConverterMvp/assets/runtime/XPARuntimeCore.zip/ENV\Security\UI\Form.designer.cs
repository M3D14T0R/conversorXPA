using System.Drawing;
using XPARuntimeCore.Box.UI;
using XPARuntimeCore.Box;
namespace ENV.Security.UI
{
    partial class Form
    {
        void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // Form
            // 
            this.AllowDrop = false;
            this.ClientSize = new System.Drawing.Size(492, 370);
            this.Name = "Form";
            this.StartPosition = XPARuntimeCore.Box.UI.WindowStartPosition.CenterMDI;
            this.ResumeLayout(false);

        }
    }
}
