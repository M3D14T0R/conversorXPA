namespace WizardOfOz.Witch.DataAccess;

internal interface CachedResult
{
	QueryResult GetQueryResult();

	CachedResult Add(DataProviderRow current);
}
