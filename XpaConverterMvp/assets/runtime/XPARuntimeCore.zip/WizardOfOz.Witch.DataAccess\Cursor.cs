using System;

namespace WizardOfOz.Witch.DataAccess;

internal interface Cursor : IDisposable
{
	bool MoveNext();

	bool MovePrevious();
}
