using System;
using System.Collections.Generic;
using System.Data;
using XPARuntimeCore.Box;
using XPARuntimeCore.Box.Advanced;
using XPARuntimeCore.Box.Data.Advanced;
using XPARuntimeCore.Box.Data.DataProvider;

namespace WizardOfOz.Witch.DataAccess.DataProviders;

internal class CheckNull
{
	private class NullCheckerFilterItemSaver : IFilterItemSaver, IValueSaver
	{
		public bool IsNull;

		public byte[] _byteArrayValue;

		public object _value;

		public void SaveInt(int value)
		{
			_value = value;
		}

		public void SaveDecimal(decimal value, byte precision, byte scale)
		{
			_value = value;
		}

		public void SaveString(string value, int length, bool fixedWidth)
		{
			IsNull = value == null;
			_value = value;
		}

		public void SaveAnsiString(string value, int length, bool fixedWidth)
		{
			SaveString(value, length, fixedWidth);
		}

		public void SaveNull()
		{
			IsNull = true;
		}

		public void SaveDateTime(DateTime value)
		{
			_value = value;
		}

		public void SaveTimeSpan(TimeSpan value)
		{
			_value = value;
		}

		public void SaveBoolean(bool value)
		{
			_value = value;
		}

		public void SaveByteArray(byte[] value)
		{
			IsNull = value == null;
			_byteArrayValue = value;
		}

		public void SaveColumn(ColumnBase column)
		{
			IsNull = false;
		}

		public void SaveEmptyDateTime()
		{
			_value = Date.Empty;
		}
	}

	private Action<string, IFilterItem[]> _saveTo;

	private List<Func<DataRow, bool>> _conditions = new List<Func<DataRow, bool>>();

	private List<Func<DataRow, bool>> _allConditions = new List<Func<DataRow, bool>>();

	public CheckNull(Action<string, IFilterItem[]> saveTo)
	{
		_saveTo = saveTo;
	}

	internal void AddNullEquality(ColumnBase column)
	{
		Action<string, IFilterItem[]> saveTo = _saveTo;
		IFilterItem[] arg = new ColumnBase[1] { column };
		saveTo("{0} is null", arg);
	}

	public bool IsNull(IFilterItem item)
	{
		NullCheckerFilterItemSaver nullCheckerFilterItemSaver = new NullCheckerFilterItemSaver();
		item.SaveTo(nullCheckerFilterItemSaver);
		return nullCheckerFilterItemSaver.IsNull;
	}

	public void AddOperator(ColumnBase column, IFilterItem to, string op, Func<int, bool> check)
	{
		NullCheckerFilterItemSaver x = new NullCheckerFilterItemSaver();
		to.SaveTo(x);
		if (x.IsNull)
		{
			if (op != "<>")
			{
				AddNullEquality(column);
				return;
			}
			Action<string, IFilterItem[]> saveTo = _saveTo;
			IFilterItem[] arg = new ColumnBase[1] { column };
			saveTo("{0} is not null", arg);
		}
		else if (x._byteArrayValue != null)
		{
			_conditions.Add((DataRow r) => check(Comparer.Compare(r[column.Name], x._byteArrayValue)));
		}
		else if (x._value is TimeSpan)
		{
			_conditions.Add((DataRow r) => check(Comparer.Compare(r[column.Name], x._value)));
		}
		else
		{
			_saveTo("{0} " + op + " {1}", new IFilterItem[2] { column, to });
			_allConditions.Add((DataRow r) => check(Comparer.Compare(r[column.Name], x._value)));
		}
	}

	public bool NeedManualCheck()
	{
		return _conditions.Count > 0;
	}

	public bool CheckOnlyManualConditions(DataRow dataRow)
	{
		foreach (Func<DataRow, bool> condition in _conditions)
		{
			if (!condition(dataRow))
			{
				return false;
			}
		}
		return true;
	}

	public bool CheckAllConditions(DataRow dataRow)
	{
		if (!CheckOnlyManualConditions(dataRow))
		{
			return false;
		}
		foreach (Func<DataRow, bool> allCondition in _allConditions)
		{
			if (!allCondition(dataRow))
			{
				return false;
			}
		}
		return true;
	}
}
