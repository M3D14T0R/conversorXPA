using System;
using WizardOfOz.Witch.DataAccess;

namespace WizardOfOz.Witch.Engine;

internal delegate void BeforeEnteringRow(DataProviderRow row, Action discardRow, Action<DataProviderRow> useThisRowForReloadData);
