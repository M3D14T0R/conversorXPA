using System;

namespace WizardOfOz.Witch.Engine;

internal class DummyContextRunner : ContextRunner
{
	public static readonly DummyContextRunner Instance = new DummyContextRunner();

	public void RunInContext(Action command)
	{
		command();
	}

	public ContextInstance CreateContextInstance()
	{
		return DummyContextInstance.Instance;
	}

	public bool IsInTemplateState()
	{
		return false;
	}
}
