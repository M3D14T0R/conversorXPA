using WizardOfOz.Witch.DataAccess;

namespace WizardOfOz.Witch.Engine;

internal class DoNotMoveTheFirstTime : CursorMover
{
	private CursorMover _decorated;

	private bool _first = true;

	public DoNotMoveTheFirstTime(CursorMover decorated)
	{
		_decorated = decorated;
	}

	public bool Move(Cursor cursor, bool validCurrentRow)
	{
		if (_first && validCurrentRow)
		{
			_first = false;
			return true;
		}
		_first = false;
		return _decorated.Move(cursor, validCurrentRow);
	}

	public void MoveOne(GridParkedRow parkedRow)
	{
	}

	public bool ShouldCreateANewRowIfAtEnd()
	{
		return _decorated.ShouldCreateANewRowIfAtEnd();
	}

	public CursorMover Reverse()
	{
		return new DoNotMoveTheFirstTime(_decorated.Reverse());
	}

	public CursorMover AfterRowWasDeleted()
	{
		return this;
	}

	public bool ShouldMoveBackOneRowAfterCurrentRowIsRemoved()
	{
		return _decorated.ShouldMoveBackOneRowAfterCurrentRowIsRemoved();
	}

	public CursorMover NewRowWasNotFoundWhereItWasSupposedToBe()
	{
		return this;
	}
}
