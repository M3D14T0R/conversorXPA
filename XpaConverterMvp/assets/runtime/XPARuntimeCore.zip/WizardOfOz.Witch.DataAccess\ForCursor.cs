namespace WizardOfOz.Witch.DataAccess;

internal interface ForCursor
{
	bool PositionBeforeEndOfList();

	void Step();

	bool OnTheEdgeOfTheList();

	bool TryAddingRowToListAndReturnTrueIfSucceeded(DataProviderRow dataProviderRow);

	void SetPositionToByondEdgeOfList();

	bool PositionAfterBeginningOfList();

	void StepBack();

	bool MoveByondTheEdgeOfKnownData();

	bool Reversed();

	void SetPositionToBeforeBeginningOfList();

	bool ThereIsNothingBeyondTheEdgeOfKnownData();
}
