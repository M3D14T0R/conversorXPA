using System;
using XPARuntimeCore.Box;
using XPARuntimeCore.Box.Data;
using XPARuntimeCore.Box.Data.Advanced;

namespace WizardOfOz.Witch.DataAccess;

internal class FilterRelevanceDecorator : Filter
{
	private Filter _filter;

	private IdentifierProvider _includeColumn;

	public FilterRelevanceDecorator(Filter filter, IdentifierProvider includeColumn)
	{
		_filter = filter;
		_includeColumn = includeColumn;
	}

	private bool DoIfColumnMatchesOrSendTrueCondition(ColumnBase column)
	{
		if (!column.ExcludeFromDbWhere && _includeColumn.Contains(column))
		{
			return true;
		}
		_filter.AddTrueCondition();
		return false;
	}

	public void AddBetweenCondition(ColumnBase column, ColumnFilterValue from, ColumnFilterValue to)
	{
		if (DoIfColumnMatchesOrSendTrueCondition(column))
		{
			_filter.AddBetweenCondition(column, from, to);
		}
	}

	public void AddEqual(ColumnBase column, ColumnFilterValue to)
	{
		if (DoIfColumnMatchesOrSendTrueCondition(column))
		{
			_filter.AddEqual(column, to);
		}
	}

	public void AddDifferent(ColumnBase column, ColumnFilterValue from)
	{
		if (DoIfColumnMatchesOrSendTrueCondition(column))
		{
			_filter.AddDifferent(column, from);
		}
	}

	public void AddStartsWith(ColumnBase column, ColumnFilterValue to)
	{
		if (DoIfColumnMatchesOrSendTrueCondition(column))
		{
			_filter.AddStartsWith(column, to);
		}
	}

	public void AddGreaterOrEqual(ColumnBase column, ColumnFilterValue to)
	{
		if (DoIfColumnMatchesOrSendTrueCondition(column))
		{
			_filter.AddGreaterOrEqual(column, to);
		}
	}

	public void AddLessOrEqual(ColumnBase column, ColumnFilterValue to)
	{
		if (DoIfColumnMatchesOrSendTrueCondition(column))
		{
			_filter.AddLessOrEqual(column, to);
		}
	}

	public void AddWhere(Action<TranslateToGatewayTerms, Action<string>> whereFactory)
	{
		_filter.AddWhere(whereFactory);
	}

	public void AddOr(FilterCondition a, FilterCondition b)
	{
		_filter.AddOr(new FilterConditionRelevanceDecorator(a, _includeColumn), new FilterConditionRelevanceDecorator(b, _includeColumn));
	}

	public void AddLessThan(ColumnBase column, ColumnFilterValue to)
	{
		if (DoIfColumnMatchesOrSendTrueCondition(column))
		{
			_filter.AddLessThan(column, to);
		}
	}

	public void AddGreaterThan(ColumnBase column, ColumnFilterValue to)
	{
		if (DoIfColumnMatchesOrSendTrueCondition(column))
		{
			_filter.AddGreaterThan(column, to);
		}
	}

	public void AddUserCondition(Func<bool> condition)
	{
		_filter.AddUserCondition(condition);
	}

	public void AddLessOrEqualWithWildcard(TextColumn column, Text value, ColumnFilterValue filterItem)
	{
		if (DoIfColumnMatchesOrSendTrueCondition(column))
		{
			_filter.AddLessOrEqualWithWildcard(column, value, filterItem);
		}
	}

	public void AddTrueCondition()
	{
		_filter.AddTrueCondition();
	}
}
