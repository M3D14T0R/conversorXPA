using System;

namespace WizardOfOz.Witch.DataAccess;

internal delegate void ApplyRowToColumnsForManualSort(DataProviderRow row, Action doOnColumnsOfRow);
