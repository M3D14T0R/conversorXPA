using System;

namespace WizardOfOz.Witch.Engine;

internal interface CommandRaisingAndInvoking
{
	void Raise(Func<EventHandler, bool> cancelCommand, bool replaceColumnsWithValuesInArgs);

	void Raise(bool replaceColumnsWithValuesInArgs);

	void RaiseCommandToBeHandledBeforeAllOtherCommandsEvenIfNotEnabled(bool raiseOnlyIfHandlerExists, bool replaceColumnsWithValuesInArgs);

	void Invoke(Action defaultAction);

	void RaiseNavigationCommand();

	void RaiseAndRepeatInMultiSelect();

	void RaiseEvenIfNotEnabled(bool replaceColumnsWithValuesInArgs);
}
