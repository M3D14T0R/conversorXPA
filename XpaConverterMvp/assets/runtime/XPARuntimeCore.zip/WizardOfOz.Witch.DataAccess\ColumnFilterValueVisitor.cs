using XPARuntimeCore.Box;

namespace WizardOfOz.Witch.DataAccess;

internal interface ColumnFilterValueVisitor
{
	void AestricText(Text value, bool endsWithAestric);
}
