namespace WizardOfOz.Witch.DataAccess;

internal delegate string TranslateToGatewayTerms(WhereMeaningfullItem x);
