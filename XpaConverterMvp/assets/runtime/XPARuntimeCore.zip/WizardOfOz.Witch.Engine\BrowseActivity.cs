using System;
using XPARuntimeCore.Box;

namespace WizardOfOz.Witch.Engine;

internal class BrowseActivity : ActivityStrategy
{
	private Activities _activity = Activities.Browse;

	public bool DoForceDelete => true;

	public bool SuppressCreationOfRowsByRelations()
	{
		return false;
	}

	public void UpdateRowToDatabase(Row row)
	{
		row.Update();
	}

	public void CreateNewRow(bool allowInsertInUpdateMode, Func<bool> allowInsert, CreateNewRowAndChangeActivityTo createNewRowAfterCurrentPosition, Action cannotCreateRow)
	{
		cannotCreateRow();
	}

	public bool UseEmptyDataView()
	{
		return false;
	}

	public bool DoLocate()
	{
		return true;
	}

	public ActivityStrategy GetStatusForExistingRow()
	{
		return this;
	}

	public void AffectUI(FormForUIController ui)
	{
		ui.SetBrowseState(on: true);
	}

	public void EnableRowActions(Action<bool> enableInsertRow, Action<bool> enableDeleteRow, Action<bool> enableDitto, bool enableInsertRowWhileInsertInUpdate)
	{
		enableDeleteRow(obj: false);
		enableInsertRow(obj: false);
		enableDitto(obj: false);
	}

	public Activities GetMode()
	{
		return _activity;
	}

	public bool AllowsEditing()
	{
		return false;
	}

	public bool InitialActivityIsLegal(TaskType taskType)
	{
		return taskType.BrowseInitialActivityAllowed();
	}

	public Number EvaluateCurrentValue(Func<Number> evaluateExpression)
	{
		return evaluateExpression();
	}

	public Number EvaluateOriginalValue(Func<Number> evaluateExpression)
	{
		return evaluateExpression();
	}

	public bool IsNewRow()
	{
		return false;
	}

	public void NoRowsFound(Action insertNewRow, Action<Action<Action>> switchToInsertIfAllowed)
	{
		switchToInsertIfAllowed(delegate(Action action)
		{
			_activity = Activities.Insert;
			try
			{
				action();
			}
			finally
			{
				_activity = Activities.Browse;
			}
		});
	}

	public bool AllowInsert(bool allowInsertInUpdateActivity, bool allowInsert)
	{
		return false;
	}

	public bool IsInsertActivityOrUpdateInInsert()
	{
		return false;
	}

	public bool AllowMovingToExistingRowAfterUndo(Func<bool> updateAllowed)
	{
		return true;
	}

	public bool StayOnNewRowAfterUndo()
	{
		return false;
	}

	public void ReplaceActivityWithActivityOfParent(Action replace)
	{
	}
}
