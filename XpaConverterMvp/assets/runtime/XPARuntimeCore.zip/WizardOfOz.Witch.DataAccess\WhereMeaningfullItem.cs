using XPARuntimeCore.Box.Data.Advanced;
using XPARuntimeCore.Box.Data.DataProvider;

namespace WizardOfOz.Witch.DataAccess;

internal interface WhereMeaningfullItem
{
	ColumnBase SendIdentifierTo(IdentifierProvider provider);

	void SaveYourValueToDb(IValueSaver handler);
}
