namespace WizardOfOz.Witch.DataAccess;

internal class DataProviderRowComparer
{
	public static bool AreRowsSame(DataProviderRow a, DataProviderRow b)
	{
		if (a == b)
		{
			return true;
		}
		if (a == null || b == null)
		{
			return false;
		}
		return a.IsEqualTo(b);
	}
}
