using XPARuntimeCore.Box.Data.Advanced;

namespace WizardOfOz.Witch.DataAccess;

internal interface IdentifierProvider
{
	bool Contains(ColumnBase column);
}
