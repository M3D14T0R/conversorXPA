namespace WizardOfOz.Witch.DataAccess;

internal class DummyFilterCondition : FilterCondition
{
	public static FilterCondition Instance = new DummyFilterCondition();

	public bool IsEmpty => true;

	public void ApplyTo(Filter filter, bool supportWildCard)
	{
	}
}
