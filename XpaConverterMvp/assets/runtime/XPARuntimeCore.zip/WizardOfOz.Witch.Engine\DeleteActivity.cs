using System;
using XPARuntimeCore.Box;

namespace WizardOfOz.Witch.Engine;

internal class DeleteActivity : ActivityStrategy
{
	private Activities _activity = Activities.Delete;

	public bool DoForceDelete => false;

	public bool SuppressCreationOfRowsByRelations()
	{
		return true;
	}

	public void UpdateRowToDatabase(Row row)
	{
		row.Delete();
	}

	public void CreateNewRow(bool allowInsertInUpdateMode, Func<bool> allowInsert, CreateNewRowAndChangeActivityTo createNewRowAfterCurrentPosition, Action cannotCreateRow)
	{
		cannotCreateRow();
	}

	public bool UseEmptyDataView()
	{
		return false;
	}

	public bool DoLocate()
	{
		return false;
	}

	public ActivityStrategy GetStatusForExistingRow()
	{
		return this;
	}

	public void AffectUI(FormForUIController _mainForm)
	{
	}

	public void EnableRowActions(Action<bool> enableInsertRow, Action<bool> enableDeleteRow, Action<bool> enableDitto, bool enableInsertRowWhileInsertInUpdate)
	{
		enableDeleteRow(obj: true);
		enableInsertRow(obj: false);
		enableDitto(obj: false);
	}

	public Activities GetMode()
	{
		return _activity;
	}

	public bool AllowsEditing()
	{
		return true;
	}

	public bool InitialActivityIsLegal(TaskType taskType)
	{
		return taskType.DeleteInitialActivityAllowed();
	}

	public Number EvaluateCurrentValue(Func<Number> evaluateExpression)
	{
		return 0;
	}

	public Number EvaluateOriginalValue(Func<Number> evaluateExpression)
	{
		return evaluateExpression();
	}

	public bool IsNewRow()
	{
		return false;
	}

	public void NoRowsFound(Action insertNewRow, Action<Action<Action>> switchToInsertIfAllowed)
	{
	}

	public bool AllowInsert(bool allowInsertInUpdateActivity, bool allowInsert)
	{
		return false;
	}

	public bool IsInsertActivityOrUpdateInInsert()
	{
		return false;
	}

	public bool AllowMovingToExistingRowAfterUndo(Func<bool> updateAllowed)
	{
		return true;
	}

	public bool StayOnNewRowAfterUndo()
	{
		return false;
	}

	public void ReplaceActivityWithActivityOfParent(Action replace)
	{
	}
}
