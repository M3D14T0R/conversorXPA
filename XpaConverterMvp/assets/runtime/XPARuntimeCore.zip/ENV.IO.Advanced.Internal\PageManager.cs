using System;
using XPARuntimeCore.Box;
using XPARuntimeCore.Box.Printing;

namespace ENV.IO.Advanced.Internal;

internal class PageManager
{
	private Func<bool> _autoNewPage;

	private bool _pageStarted;

	private bool _closed;

	private int _pageHeight = 60;

	private bool _pageClosedWithoutNewPage;

	private bool _inNewPage;

	private double _knownHeight;

	private Func<double> _lastHeightAdded = () => 0.0;

	private bool _printingNewPage;

	private int _pageNumber;

	private bool _anythingWasPrinted;

	private bool _printingHeaders;

	private bool _suspendAll;

	private bool _newPageOnNextWrite;

	private bool _inTheMiddle;

	private double CurrentPageOfset => _lastHeightAdded() + _knownHeight;

	public int PageCount => _pageNumber + ((!_pageStarted) ? 1 : 0);

	public double HeightUntilEndOfPage => (double)_pageHeight - ((CurrentPageOfset > 0.0) ? CurrentPageOfset : ((double)PageHeaderHeight)) - (double)PageFooterHeight;

	public double Height => CurrentPageOfset;

	public int PageHeight => _pageHeight;

	public int PageFooterHeight { get; set; }

	public int PageHeaderHeight { get; set; }

	public bool PageEnded { get; private set; }

	public bool NewPageOnNextWrite
	{
		get
		{
			return _newPageOnNextWrite;
		}
		set
		{
			_newPageOnNextWrite = value;
		}
	}

	public event Action NewPageEvent;

	public event EndPageDelegate PageEnds;

	public PageManager(Func<bool> autoNewPage)
	{
		_autoNewPage = autoNewPage;
	}

	public void Close()
	{
		_closed = true;
		ClosePreviousPage();
		_pageStarted = false;
	}

	public void SetPageHeight(int val)
	{
		_pageHeight = val;
		if (val == 0)
		{
			_pageHeight = int.MaxValue;
		}
	}

	private void ClosePreviousPage()
	{
		if (_pageStarted && !_pageClosedWithoutNewPage)
		{
			PageEnded = true;
			_inNewPage = true;
			PageFooters();
			_inNewPage = false;
			_pageClosedWithoutNewPage = true;
		}
	}

	public void Print(double height, Action doPrint)
	{
		Print(() => height, doPrint);
	}

	internal void Print(Func<double> height, Action doPrint)
	{
		if (_suspendAll)
		{
			return;
		}
		if (!_inTheMiddle && _autoNewPage() && ((height() > HeightUntilEndOfPage + 0.2 && !_inNewPage) || _newPageOnNextWrite))
		{
			_newPageOnNextWrite = false;
			if (!_printingNewPage)
			{
				_printingNewPage = true;
				try
				{
					NewPageDueToLackOfHeight();
					CheckIfPageStarted();
				}
				finally
				{
					_printingNewPage = false;
				}
			}
		}
		else
		{
			CheckIfPageStarted();
		}
		_inNewPage = false;
		doPrint();
		_knownHeight = CurrentPageOfset;
		_lastHeightAdded = height;
	}

	private void NewPageDueToLackOfHeight()
	{
		if (_pageStarted)
		{
			NewPage();
		}
	}

	internal void CheckIfPageStarted()
	{
		if (!_pageStarted)
		{
			_pageNumber++;
			_pageStarted = true;
			_anythingWasPrinted = true;
			PageEnded = false;
			PageHeaders();
			_inNewPage = true;
		}
	}

	internal bool AnythingWasEverPrinted()
	{
		return _anythingWasPrinted;
	}

	public void NewPage()
	{
		if (_pageStarted && !_inNewPage && Height != 0.0)
		{
			ClosePreviousPage();
			_pageStarted = false;
			_pageClosedWithoutNewPage = false;
			_knownHeight = 0.0;
			_lastHeightAdded = () => 0.0;
		}
	}

	private void PageHeaders()
	{
		if (this.NewPageEvent != null)
		{
			this.NewPageEvent();
		}
	}

	private void PageFooters()
	{
		if (PageFooterHeight == 0)
		{
			return;
		}
		bool inTheMiddle = _inTheMiddle;
		_inTheMiddle = true;
		try
		{
			_suspendAll = true;
			try
			{
				Context.Current.RunExpressionCommands();
			}
			finally
			{
				_suspendAll = false;
			}
			if (this.PageEnds != null)
			{
				this.PageEnds(_closed);
			}
		}
		finally
		{
			_inTheMiddle = inTheMiddle;
		}
	}

	public void EndCurrentPageWithoutStartingANewOne()
	{
		if (_pageStarted && !_inNewPage && Height != 0.0)
		{
			ClosePreviousPage();
		}
	}

	internal void AboutToPrint(double sectionHeight, Action newPageStartedDueToLackOfSpace, bool autoNewPage)
	{
		if (_inTheMiddle)
		{
			return;
		}
		_inTheMiddle = true;
		try
		{
			if (sectionHeight > HeightUntilEndOfPage + 0.2 && Height > 0.0)
			{
				if (autoNewPage)
				{
					newPageStartedDueToLackOfSpace();
					CheckIfPageStarted();
				}
				else
				{
					EndCurrentPageWithoutStartingANewOne();
				}
			}
			else
			{
				CheckIfPageStarted();
			}
		}
		finally
		{
			_inTheMiddle = false;
		}
	}
}
