using System.Collections.Generic;

namespace WizardOfOz.Witch.Engine;

internal class ChangeStuff
{
	public bool _accumulatingValueChageEvents;

	public HashSet<RecomputeItem> _itemsUsed = new HashSet<RecomputeItem>();

	public Queue<ChangeAndItem> _valueChangeToRun = new Queue<ChangeAndItem>();
}
