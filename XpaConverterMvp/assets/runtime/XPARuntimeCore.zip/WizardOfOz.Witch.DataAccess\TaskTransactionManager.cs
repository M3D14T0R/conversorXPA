using System;

namespace WizardOfOz.Witch.DataAccess;

internal interface TaskTransactionManager
{
	void StartTransaction(bool checkRowLocking);

	void Commit();

	void RunMonitoredCommand(Action command, TransactionRollbackDelegate callMeIfYouRollbacked);

	void RollbackIfYouAreARootTransaction();

	void RunRecoverableMonitoredCommand(Action command, Action callMeIfYouRollbacked, bool throwExceptionIfNotRecover);
}
