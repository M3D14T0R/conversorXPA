using System;

namespace WizardOfOz.Witch.DataAccess;

internal class SingleQueryResult : CachedResult
{
	private class myQueryResult : QueryResult, IDisposable
	{
		private DataProviderRow _enumerator;

		private bool _done;

		public DataProviderRow Current => _enumerator;

		public myQueryResult(DataProviderRow enumerator)
		{
			_enumerator = enumerator;
		}

		public bool MoveNext()
		{
			if (_done)
			{
				return false;
			}
			_done = true;
			return true;
		}

		public void Dispose()
		{
		}
	}

	private DataProviderRow _source;

	public SingleQueryResult(DataProviderRow source)
	{
		_source = source;
	}

	public QueryResult GetQueryResult()
	{
		return new myQueryResult(_source);
	}

	public CachedResult Add(DataProviderRow current)
	{
		ListQueryResultProvider listQueryResultProvider = new ListQueryResultProvider();
		listQueryResultProvider.Add(_source);
		return listQueryResultProvider.Add(current);
	}
}
