using System;

namespace WizardOfOz.Witch.Engine;

internal interface ContextInstance : ContextUser, IDisposable
{
}
