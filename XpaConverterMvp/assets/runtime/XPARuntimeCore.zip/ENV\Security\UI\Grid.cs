using System.Drawing;
using XPARuntimeCore.Box.UI;
using XPARuntimeCore.Box;
namespace ENV.Security.UI
{

    /// <summary>Grid</summary>
    public partial class Grid : ENV.UI.Grid
    {


        /// <summary>Grid</summary>
        public Grid()
        {
            InitializeComponent();
            EnableGridEnhancements();
            UnderConstructionNewGridLook = true;
            HorizontalScrollbar = false;
        }

    }
}
