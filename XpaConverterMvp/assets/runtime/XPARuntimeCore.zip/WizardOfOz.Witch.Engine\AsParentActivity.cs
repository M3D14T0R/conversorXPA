using System;
using XPARuntimeCore.Box;

namespace WizardOfOz.Witch.Engine;

internal class AsParentActivity : ActivityStrategy
{
	public bool DoForceDelete
	{
		get
		{
			throw new NotImplementedException();
		}
	}

	public bool SuppressCreationOfRowsByRelations()
	{
		return false;
	}

	public void AffectUI(FormForUIController ui)
	{
		throw new NotImplementedException();
	}

	public bool AllowInsert(bool allowInsertInUpdateActivity, bool allowInsert)
	{
		throw new NotImplementedException();
	}

	public bool AllowMovingToExistingRowAfterUndo(Func<bool> updateAllowed)
	{
		throw new NotImplementedException();
	}

	public bool AllowsEditing()
	{
		throw new NotImplementedException();
	}

	public void CreateNewRow(bool allowInsertInUpdateMode, Func<bool> allowInsert, CreateNewRowAndChangeActivityTo createNewRowAfterCurrentPosition, Action cannotCreateRow)
	{
		throw new NotImplementedException();
	}

	public bool DoLocate()
	{
		throw new NotImplementedException();
	}

	public void EnableRowActions(Action<bool> enableInsertRow, Action<bool> enableDeleteRow, Action<bool> enableDitto, bool enableInsertRowWhileInsertInUpdate)
	{
		throw new NotImplementedException();
	}

	public Number EvaluateCurrentValue(Func<Number> evaluateExpression)
	{
		throw new NotImplementedException();
	}

	public Number EvaluateOriginalValue(Func<Number> evaluateExpression)
	{
		throw new NotImplementedException();
	}

	public Activities GetMode()
	{
		return Activities.AsParent;
	}

	public ActivityStrategy GetStatusForExistingRow()
	{
		throw new NotImplementedException();
	}

	public bool InitialActivityIsLegal(TaskType taskType)
	{
		throw new NotImplementedException();
	}

	public bool IsInsertActivityOrUpdateInInsert()
	{
		throw new NotImplementedException();
	}

	public bool IsNewRow()
	{
		throw new NotImplementedException();
	}

	public void NoRowsFound(Action insertNewRow, Action<Action<Action>> switchToInsertIfAllowed)
	{
		throw new NotImplementedException();
	}

	public void ReplaceActivityWithActivityOfParent(Action replace)
	{
		replace();
	}

	public bool StayOnNewRowAfterUndo()
	{
		throw new NotImplementedException();
	}

	public void UpdateRowToDatabase(Row row)
	{
		throw new NotImplementedException();
	}

	public bool UseEmptyDataView()
	{
		throw new NotImplementedException();
	}
}
