using System;
using XPARuntimeCore.Box;

namespace WizardOfOz.Witch.DataAccess;

internal class LockDoesntMatchTransactionScope : Exception
{
	public LockDoesntMatchTransactionScope(TransactionScopes trans, LockingStrategy locking)
		: base($"{trans.ToString()} transaction scope doesn't match {locking} locking strategy")
	{
	}
}
