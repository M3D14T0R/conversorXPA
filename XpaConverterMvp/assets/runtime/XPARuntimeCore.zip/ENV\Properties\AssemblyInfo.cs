using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("ENV")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("XPARuntimeCore LTD")]
#if DEBUG
[assembly: AssemblyProduct("ENV Debug")]
#else
[assembly: AssemblyProduct("ENV Release")]
#endif
[assembly: AssemblyCopyright("Copyright ֲ© XPARuntimeCore LTD 2026")]
[assembly: AssemblyInformationalVersion("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("E6A916BA-171C-4788-AF6C-FF9F0A58491B")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Revision and Build Numbers 
// by using the '*' as shown below:
[assembly: AssemblyVersion("4.6.0.35025")]
[assembly: AssemblyFileVersion("4.6.0.35025")]
