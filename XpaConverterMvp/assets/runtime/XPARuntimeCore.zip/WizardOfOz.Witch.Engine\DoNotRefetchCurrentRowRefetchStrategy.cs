using System;

namespace WizardOfOz.Witch.Engine;

internal class DoNotRefetchCurrentRowRefetchStrategy : CurrentRowRefetchStrategy
{
	public void Refetch(RefetchCurrentRow refech, Action doNotRefetch)
	{
		doNotRefetch();
	}
}
