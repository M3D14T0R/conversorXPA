using System;

namespace WizardOfOz.Witch.Engine;

internal interface CommandHandling
{
	void OnThisTask(Action<CommandRaisingAndInvoking> doThis);

	void OnCurrentlyActiveTask(Action<CommandRaisingAndInvoking> doThis);

	void OnCurrentlyActiveTask(Action<CommandRaisingAndInvoking> doThis, bool onlyIfThereIsAHandlerInThisTask);
}
