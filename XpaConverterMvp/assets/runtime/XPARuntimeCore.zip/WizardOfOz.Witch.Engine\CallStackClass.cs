using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.Reflection;
using System.Threading;
using System.Web;
using System.Windows.Forms;
using XPARuntimeCore.Box;
using XPARuntimeCore.Box.Advanced;
using XPARuntimeCore.Box.Data;
using XPARuntimeCore.Box.Data.Advanced;
using XPARuntimeCore.Box.Data.DataProvider;
using XPARuntimeCore.Box.DataAccess.Transactions;
using XPARuntimeCore.Box.Engine;
using XPARuntimeCore.Box.Testing;
using XPARuntimeCore.Box.UI;
using XPARuntimeCore.Box.UI.Advanced;
using WizardOfOz.Witch.DataAccess;
using WizardOfOz.Witch.UI;

namespace WizardOfOz.Witch.Engine;

internal class CallStackClass : HostEnvironment
{
	private class MainThread
	{
		private class myMessage : WindowsMessageLoop.Message
		{
			private WindowsMessageLoop.Message _wrapped;

			private object _context;

			public myMessage(WindowsMessageLoop.Message wrapped, object mainContext)
			{
				_wrapped = wrapped;
				_context = mainContext;
			}

			public void DispatchMessage(WindowsMessageLoop.MessageHandler messageHandler, Action<Action, object> doOnUiThread)
			{
				_wrapped.DispatchMessage(messageHandler, doOnUiThread);
			}

			public object GetContext()
			{
				return _wrapped.GetContext() ?? _context;
			}
		}

		private class UIMessageLoop : WindowsMessageLoop.MessageLoop
		{
			private MainThread _parent;

			public UIMessageLoop(MainThread parent)
			{
				_parent = parent;
			}

			public void ProcessNextMessage(Action<WindowsMessageLoop.Message> howToProcessIt, int waitMS, Action<Action<IntPtr>> addWaitHandles)
			{
				_parent._mLoop.ProcessNextUIThreadMessage(howToProcessIt, waitMS);
			}

			public void UpdateAllWindows()
			{
				_parent._mLoop.ProcessInvokeOnUIThread();
				_parent._baseMessageLoop.UpdateAllWindows();
			}

			public void WrapRunFirstMessageLoop(Action run)
			{
				throw new NotImplementedException();
			}
		}

		private class SonThreadMessageLoop : WindowsMessageLoop.MessageLoop
		{
			private MainThread _parent;

			private object _context;

			public SonThreadMessageLoop(MainThread parent, object context)
			{
				_parent = parent;
				_context = context;
			}

			public void ProcessNextMessage(Action<WindowsMessageLoop.Message> howToProcessIt, int waitMS, Action<Action<IntPtr>> addWaitHandles)
			{
				_parent._mLoop.ProcessSonThreadMessage(_context, howToProcessIt, waitMS);
			}

			public void UpdateAllWindows()
			{
				_parent._InvokeOnUIThread(delegate
				{
					_parent._baseMessageLoop.UpdateAllWindows();
				}, _context);
			}

			public void WrapRunFirstMessageLoop(Action run)
			{
				throw new NotImplementedException();
			}
		}

		private class myTarget : IWindowTarget
		{
			private IWindowTarget _target;

			public myTarget(IWindowTarget target)
			{
				_target = target;
			}

			public void OnHandleChange(IntPtr newHandle)
			{
				_target.OnHandleChange(newHandle);
			}

			public void OnMessage(ref Message m)
			{
				if (m.Msg != 61)
				{
					_target.OnMessage(ref m);
				}
			}
		}

		public delegate void RunBeforeDeactivatingForm(Action forceFormClosing);

		private class myFormForTask : FormForTask
		{
			private FormForTask _form;

			private Action<Action> _invokeOnUIThread;

			public myFormForTask(FormForTask form, Action<Action> invokeOnUiThread)
			{
				_form = form;
				_invokeOnUIThread = invokeOnUiThread;
			}

			public void Load(TaskForForm task, RecomputeManager recomputeManager, SubFormRunningState subFormRunningState)
			{
				_form.Load(task, recomputeManager, subFormRunningState);
			}

			public bool Deactivate(bool close)
			{
				bool result = false;
				_invokeOnUIThread(delegate
				{
					result = _form.Deactivate(close);
				});
				return result;
			}

			public void MakeParentOf(Action<XPARuntimeCore.Box.UI.Form> me, Action delegateUpCallStack)
			{
				_invokeOnUIThread(delegate
				{
					_form.MakeParentOf(me, delegateUpCallStack);
				});
			}

			public void AddActionsTo(EventHandlerBuilder handler)
			{
				_form.AddActionsTo(handler);
			}

			public void Display(FormContainer formContainer, FormsManager formsManager)
			{
				_invokeOnUIThread(delegate
				{
					_form.Display(formContainer, formsManager);
				});
			}

			public void SetParent(XPARuntimeCore.Box.UI.Form parent, bool lockParent)
			{
				_invokeOnUIThread(delegate
				{
					_form.SetParent(parent, lockParent);
				});
			}

			public IControl GetCurrentControl()
			{
				return _form.GetCurrentControl();
			}

			public void RemoveDisplayedDataFromControls(bool entityColumnsOnly = false)
			{
				_invokeOnUIThread(delegate
				{
					_form.RemoveDisplayedDataFromControls(entityColumnsOnly);
				});
			}

			public void UserAskedToPutString(string stringToPut, Action defaultAction)
			{
				_form.UserAskedToPutString(stringToPut, defaultAction);
			}

			public void HandleKey(Keys keyData, Action dispatchToWindows, LetFrameworkHandleKey letFrameworkHandle)
			{
				_invokeOnUIThread(delegate
				{
					_form.HandleKey(keyData, dispatchToWindows, letFrameworkHandle);
				});
			}

			public void CheckKeyContext(KeyContextResult result)
			{
				_invokeOnUIThread(delegate
				{
					_form.CheckKeyContext(result);
				});
			}

			public void Reactivate(Action activateFormInParentTask)
			{
				_form.Reactivate(activateFormInParentTask);
			}

			public void DoOnColumns(Action<ColumnBase> selectColumn)
			{
				_form.DoOnColumns(selectColumn);
			}

			public void DisplaySubForms(RecomputeManager recomputeManager, bool refresh)
			{
				_form.DisplaySubForms(recomputeManager, refresh);
			}

			public void InitializeAsSubForm(SubForm subFormControl)
			{
				_invokeOnUIThread(delegate
				{
					_form.InitializeAsSubForm(subFormControl);
				});
			}

			public XPARuntimeCore.Box.UI.Form GetForm()
			{
				return _form.GetForm();
			}

			public void HandleDoubleClick(Control controlClicked, Point location, Action dispatchToWindows)
			{
				_form.HandleDoubleClick(controlClicked, location, dispatchToWindows);
			}

			public void RefreshListSources()
			{
				_form.RefreshListSources();
			}

			public bool ParkedControlIs(ControlBase controlBase)
			{
				return _form.ParkedControlIs(controlBase);
			}

			public void BlockUIChangesWhile(Action runningThis)
			{
				_form.BlockUIChangesWhile(runningThis);
			}

			public void PaintImmediate()
			{
				_invokeOnUIThread(delegate
				{
					_form.PaintImmediate();
				});
			}

			public void HandleMouseDown(Control controlClicked, bool leftButtonWasUsed, Point location, Action dispatchToWindows, Action sendMouseUp)
			{
				_form.HandleMouseDown(controlClicked, leftButtonWasUsed, location, dispatchToWindows, sendMouseUp);
			}

			public void EndEditingDueToChangingFocus(ControlBase controlWhichMayRequireFocus, Action andDo)
			{
				_form.EndEditingDueToChangingFocus(controlWhichMayRequireFocus, andDo);
			}

			public void SendKeys(Keys keys, Action sendToContainer)
			{
				_invokeOnUIThread(delegate
				{
					_form.SendKeys(keys, sendToContainer);
				});
			}

			public void ShowOrHide(bool show, Action showAction)
			{
				_invokeOnUIThread(delegate
				{
					_form.ShowOrHide(show, showAction);
				});
			}

			public void CloseSemiModal(Action close, bool closingAll)
			{
				_form.CloseSemiModal(close, closingAll);
			}

			public void RefreshSubForm(Func<IControl, bool> isThisTheSubformToRefresh, Action noSubformToRefresh)
			{
				_form.RefreshSubForm(isThisTheSubformToRefresh, noSubformToRefresh);
			}

			public void HandleChar(char c, Action dispatchToWindows)
			{
				_form.HandleChar(c, dispatchToWindows);
			}

			public void BeforeBindingFormToTask()
			{
				_invokeOnUIThread(delegate
				{
					_form.BeforeBindingFormToTask();
				});
			}

			public void Activate(Action activateFormInParent)
			{
				_form.Activate(activateFormInParent);
			}

			public void AlwaysForcePaintWhileBusyProcessing(Action paint)
			{
				_form.AlwaysForcePaintWhileBusyProcessing(paint);
			}

			public void ClearDefaultDataFromControls()
			{
				_form.ClearDefaultDataFromControls();
			}

			public void NotifySubformsOfActivitySwitch()
			{
				_form.NotifySubformsOfActivitySwitch();
			}

			public void ForceRefreshOfSubformsOnDoCompute()
			{
				_form.ForceRefreshOfSubformsOnDoCompute();
			}

			public void NotifySubformsOfEnteringRow()
			{
				_form.NotifySubformsOfEnteringRow();
			}

			public void HandleLeftMouseUp(Control controlClicked)
			{
				_form.HandleLeftMouseUp(controlClicked);
			}
		}

		private MultiThreadedMessageLoop _mLoop;

		private System.Windows.Forms.Form _mdiContainer;

		private bool _inModalState;

		private CallStackClass _myContext;

		private WindowsMessageLoop.MessageLoop _baseMessageLoop = new WindowsMessageLoop.WindowsEvilMessageLoop();

		private WeakReference _openFormOnThread;

		private bool _inMessageLoop;

		public MainThread(CallStackClass myContext)
		{
			MainThread mainThread = this;
			_myContext = myContext;
			int threadId = Thread.CurrentThread.ManagedThreadId;
			_mLoop = new MultiThreadedMessageLoop(_myContext, delegate(Action<WindowsMessageLoop.Message> howToProcessIt, int waitMS, Action<Action<IntPtr>> addWaitHandles)
			{
				mainThread._baseMessageLoop.ProcessNextMessage(delegate(WindowsMessageLoop.Message x)
				{
					howToProcessIt(new myMessage(x, myContext));
				}, waitMS, addWaitHandles);
			}, () => Thread.CurrentThread.ManagedThreadId == threadId);
		}

		private void _InvokeOnUIThread(Action command, object context)
		{
			_mLoop.InvokeOnUIThread(command, context);
		}

		internal void RunMDIForTests(System.Windows.Forms.Form mdi, Action runMe)
		{
			_mdiContainer = mdi;
			try
			{
				runMe();
			}
			finally
			{
				_mdiContainer = null;
			}
		}

		public WindowsMessageLoop.MessageLoop GetMessageLoopFor(object context)
		{
			if (context == _myContext)
			{
				return new UIMessageLoop(this);
			}
			return new SonThreadMessageLoop(this, context);
		}

		public void RegisterMockMessageLoopCommand(DispatchMessage command, object callStackClass)
		{
			MockMessageLoopWithQueue mockMessageLoopWithQueue = _baseMessageLoop as MockMessageLoopWithQueue;
			if (mockMessageLoopWithQueue == null)
			{
				mockMessageLoopWithQueue = (MockMessageLoopWithQueue)(_baseMessageLoop = new MockMessageLoopWithQueue());
			}
			mockMessageLoopWithQueue.AddMessage(command, callStackClass);
		}

		internal void RunAsMDI(System.Windows.Forms.Form mdi, Action what)
		{
			_mdiContainer = mdi;
			_openFormOnThread = new WeakReference(mdi);
			_mdiContainer.FormClosing += delegate(object sender, FormClosingEventArgs e)
			{
				Context.Current.CallStack._currentTask.UserTriedToCloseContainer(delegate
				{
					e.Cancel = true;
				});
			};
			_mdiContainer.Activated += delegate
			{
				if (_mdiContainer.ActiveMdiChild is XPARuntimeCore.Box.UI.Form form)
				{
					form._Activated();
				}
			};
			_mdiContainer.Show();
			if (!XPARuntimeCore.Box.UI.Form.AccessibilityEnabled)
			{
				foreach (Control control in _mdiContainer.Controls)
				{
					if (control is MdiClient)
					{
						control.WindowTarget = new myTarget(control.WindowTarget);
					}
				}
			}
			ApplicationContext ac = new ApplicationContext();
			Action method = delegate
			{
				try
				{
					what();
				}
				finally
				{
					_mdiContainer.Close();
					_mdiContainer = null;
					ac.ExitThread();
				}
			};
			_mdiContainer.BeginInvoke(method);
			Application.Run(ac);
		}

		private void BeginModalLoop()
		{
			typeof(Application).InvokeMember("BeginModalMessageLoop", BindingFlags.Static | BindingFlags.NonPublic | BindingFlags.InvokeMethod, null, null, new object[0]);
		}

		private void EndModalLoop()
		{
			typeof(Application).InvokeMember("EndModalMessageLoop", BindingFlags.Static | BindingFlags.NonPublic | BindingFlags.InvokeMethod, null, null, new object[0]);
		}

		public void AddChildForm(XPARuntimeCore.Box.UI.Form form, System.Windows.Forms.Form topMostForm, System.Windows.Forms.Form ownerForTopLevelForm, bool dock, bool floatingWindow, bool modal, bool forceTopLevel, Action<RunBeforeDeactivatingForm> addToRunBeforeDeactivatingForm)
		{
			if (_openFormOnThread == null || !_openFormOnThread.IsAlive || ((Control)_openFormOnThread.Target).IsDisposed)
			{
				_openFormOnThread = new WeakReference(form);
			}
			if (modal && !_inModalState)
			{
				_inModalState = true;
				addToRunBeforeDeactivatingForm(delegate
				{
					_inModalState = false;
				});
			}
			if (dock && topMostForm != null && topMostForm != _mdiContainer)
			{
				form.DockWithinNonMDIForm(topMostForm);
			}
			else if (_inModalState || floatingWindow || forceTopLevel)
			{
				topMostForm = topMostForm ?? _mdiContainer;
				if (form.ContextMenuStrip == null && topMostForm != null)
				{
					form.ContextMenuStrip = topMostForm.ContextMenuStrip;
				}
				if (_inModalState)
				{
					form.BeginModalLoop(delegate
					{
						addToRunBeforeDeactivatingForm(delegate(Action forceFormClosing)
						{
							EndModalLoop();
							forceFormClosing();
						});
						BeginModalLoop();
					});
				}
				if (forceTopLevel)
				{
					form.ShowInTaskbar = true;
				}
				else if (form.Parent == null)
				{
					form.Owner = ownerForTopLevelForm ?? topMostForm;
				}
			}
			else if (_mdiContainer != null)
			{
				form.MdiParent = _mdiContainer;
				if (dock)
				{
					form.Dock = DockStyle.Fill;
				}
			}
			else if (form.TopLevel && topMostForm == null)
			{
				form.ShowInTaskbar = true;
			}
		}

		public void BeginInvokeOnLogicThreadThroughUIThread(Action action, object context, Action failed)
		{
			Action method = delegate
			{
				try
				{
					InvokeOnLogicThread(delegate
					{
						Context.Current.CallStack._eventQue.EnqueueUnclearableCommand(delegate
						{
							action();
						});
					}, context);
				}
				catch
				{
					failed();
				}
			};
			Control control = ((_openFormOnThread == null) ? null : (_openFormOnThread.Target as Control));
			if (control != null && control.IsHandleCreated)
			{
				control.BeginInvoke(method);
			}
			else
			{
				failed();
			}
		}

		public bool ShouldKeyBeProcessed(Control activeControl)
		{
			if (activeControl == _mdiContainer || (activeControl is MdiClient && activeControl.FindForm() == _mdiContainer))
			{
				return true;
			}
			return false;
		}

		public FormForTask GetFormForTask(FormForTask form, object context)
		{
			if (_myContext == context || form is myFormForTask)
			{
				return form;
			}
			return new myFormForTask(form, delegate(Action x)
			{
				_InvokeOnUIThread(x, context);
			});
		}

		public void AddContext(CallStackClass callStackClass)
		{
			_mLoop.AddContext(callStackClass);
		}

		public void RemoveContext(CallStackClass callStackClass)
		{
			_mLoop.RemoveContext(callStackClass);
		}

		public void InvokeOnUIThread(Action command, object context)
		{
			_InvokeOnUIThread(command, context);
		}

		public void InvokeOnLogicThread(Action action, object context)
		{
			_mLoop.InvokeOnNonUIThread(action, context);
		}

		public void SendKeys(Keys keys)
		{
			System.Windows.Forms.Form f = _myContext._currentTask.GetTopMostForm() ?? _mdiContainer;
			if (f == null)
			{
				return;
			}
			_myContext.UICommands.AddCommandForResume(delegate
			{
				if (!f.IsDisposed && f.IsHandleCreated)
				{
					Message msg = new Message
					{
						HWnd = ((f.ActiveControl != null && f.ActiveControl.IsHandleCreated) ? f.ActiveControl.Handle : f.Handle),
						Msg = 256,
						WParam = (IntPtr)(int)keys
					};
					f.PreProcessControlMessage(ref msg);
				}
			});
		}

		public void RequestReactivation(XPARuntimeCore.Box.UI.Form form, Action reactivate)
		{
			if (_mdiContainer == null || form.MdiParent != _mdiContainer)
			{
				reactivate();
				return;
			}
			foreach (object control in _mdiContainer.Controls)
			{
				if (!(control is MdiClient mdiClient))
				{
					continue;
				}
				foreach (object control2 in mdiClient.Controls)
				{
					XPARuntimeCore.Box.UI.Form form2 = control2 as XPARuntimeCore.Box.UI.Form;
					if (form2 == form)
					{
						reactivate();
						return;
					}
					if (form2 != null && form2.GetContext() != form.GetContext())
					{
						form2.GetInternalForm().ReturnFocusToActiveForm();
						return;
					}
				}
				break;
			}
			reactivate();
		}

		internal bool IsMdiContainer(System.Windows.Forms.Form f)
		{
			return f == _mdiContainer;
		}

		internal void WrapRunMessageLoop(Action run)
		{
			if (_inMessageLoop)
			{
				run();
				return;
			}
			_inMessageLoop = true;
			try
			{
				_baseMessageLoop.WrapRunFirstMessageLoop(run);
			}
			finally
			{
				_inMessageLoop = false;
			}
		}
	}

	private class myParentEventManagers : ParentEventManagers
	{
		private Task[] _parentEventManagers;

		public bool Empty => _parentEventManagers.Length == 0;

		public myParentEventManagers(Stack<Task> eventsCallStack)
		{
			_parentEventManagers = eventsCallStack.ToArray();
		}

		public void ForEach(Action<Task> runOnEventManager)
		{
			for (int i = 0; i < _parentEventManagers.Length; i++)
			{
				runOnEventManager(_parentEventManagers[i]);
			}
		}

		public bool BottomEventManagerIs(Task task)
		{
			if (_parentEventManagers.Length != 0)
			{
				return _parentEventManagers[_parentEventManagers.Length - 1] == task;
			}
			return false;
		}
	}

	private class ContextTreeNode : ContextNode
	{
		private delegate void EnqueueGoToCommand(ContextTreeNode abortIfCurrentContextTreeNodeIsThis, bool goingIntoHandler);

		private class NavigationTargetClass : NavigationTarget
		{
			private ContextTreeNode _current;

			private ContextTreeNode _target;

			private Action<Action, bool> _wrapRunnedTask;

			public NavigationTargetClass(ContextTreeNode current, ContextTreeNode target, Action<Action, bool> wrapRunnedTask)
			{
				_current = current;
				_target = target;
				_wrapRunnedTask = wrapRunnedTask;
			}

			public bool Matches(UserFlowConditionalItem flowConditionalItem)
			{
				UnderlyingUserFlowObjectVisitorClass underlyingUserFlowObjectVisitorClass = new UnderlyingUserFlowObjectVisitorClass();
				flowConditionalItem.WhoAreYouReally(underlyingUserFlowObjectVisitorClass);
				if (underlyingUserFlowObjectVisitorClass.ResultTaskFactory != null)
				{
					return _target._item.BelongsToTheTaskCreatedBy(underlyingUserFlowObjectVisitorClass.ResultTaskFactory);
				}
				return false;
			}

			public void UnableToReach()
			{
				_target._item.SearchForHandlerThatRunsYou(delegate(Command cmd, ControlIdentifierForHandler ctrl)
				{
					_wrapRunnedTask(delegate
					{
						_current._item.GetNavigationCommandInvoker(delegate(InvokeCommand action)
						{
							if (_current._childNodes.Contains(_target))
							{
								action(cmd, ctrl);
							}
						});
					}, arg2: true);
				});
			}

			public void WrapRunnedTask(Action runTask)
			{
				_wrapRunnedTask(runTask, arg2: false);
			}
		}

		private class myCachedTaskForTask : CachedTaskForTask
		{
			private object _task;

			private bool _formClosed;

			private Action _removeInstance;

			private object _groupIdentifier;

			private bool _forKeepViewVisibleAfterExitOnly;

			private bool _disposed;

			private bool _taskExitingWithoutKeepingFormVisible;

			public myCachedTaskForTask(object task, Action removeInstance, object groupIdentifier, bool forKeepViewVisibleAfterExitOnly)
			{
				_task = task;
				_removeInstance = removeInstance;
				_groupIdentifier = groupIdentifier;
				_forKeepViewVisibleAfterExitOnly = forKeepViewVisibleAfterExitOnly;
			}

			public void FormClosed()
			{
				_formClosed = true;
				if (_disposed)
				{
					_removeInstance();
				}
			}

			public void SendTaskBase(Action<object> toMe)
			{
				toMe(_task);
			}

			public IDisposable GetRunnungOfTaskWrapper()
			{
				_disposed = false;
				return new myDisposable(delegate
				{
					if (_formClosed || (_forKeepViewVisibleAfterExitOnly && _taskExitingWithoutKeepingFormVisible))
					{
						_removeInstance();
					}
					_disposed = true;
				});
			}

			public bool CloseWhen(CachedTaskForTask thisTaskCloses)
			{
				if (thisTaskCloses is myCachedTaskForTask myCachedTaskForTask2)
				{
					return myCachedTaskForTask2._groupIdentifier == _groupIdentifier;
				}
				return false;
			}

			public bool CloseDueToStartingOf(CachedTaskForTask cachedTaskForTask)
			{
				return CloseWhen(cachedTaskForTask);
			}

			public void TaskExitingWithoutKeepingFormVisible()
			{
				_taskExitingWithoutKeepingFormVisible = true;
			}
		}

		private HostedItem _item;

		private List<ContextTreeNode> _childNodes = new List<ContextTreeNode>();

		private CallStackClass _parent;

		private Dictionary<object, HashSet<object>> _cachedTasks = new Dictionary<object, HashSet<object>>();

		private ContextTreeNode _parentNode;

		public ContextTreeNode(HostedItem item, CallStackClass parent, ContextTreeNode parentNode)
		{
			_item = item;
			_parent = parent;
			_parentNode = parentNode;
		}

		public ContextTreeNode AddChild(HostedItem hostedItem)
		{
			foreach (ContextTreeNode childNode in _childNodes)
			{
				if (childNode._item == hostedItem)
				{
					return childNode;
				}
			}
			ContextTreeNode newNode = new ContextTreeNode(hostedItem, _parent, this);
			newNode = (ContextTreeNode)hostedItem.GetContextNodeBasedOn(newNode);
			_childNodes.Add(newNode);
			return newNode;
		}

		private void CloseChildrenDueToStartingOf(HostedItem hostedItem, int onlyCloseChildrenAtThisLevelBelowYou)
		{
			if (_parentNode != null)
			{
				_parentNode.CloseChildrenDueToStartingOf(hostedItem, onlyCloseChildrenAtThisLevelBelowYou + 1);
			}
			else
			{
				CloseChildrenDueToStartingOfBranchRecursion(hostedItem, onlyCloseChildrenAtThisLevelBelowYou);
			}
		}

		private void CloseChildrenDueToStartingOfBranchRecursion(HostedItem hostedItem, int onlyCloseChildrenAtThisLevelBelowYou)
		{
			if (onlyCloseChildrenAtThisLevelBelowYou == 1)
			{
				_childNodes.RemoveAll(delegate(ContextTreeNode node)
				{
					if (node._item.CloseDueToStartingOf(hostedItem))
					{
						node.CloseAndCloseChildren();
						return true;
					}
					return false;
				});
				return;
			}
			foreach (ContextTreeNode childNode in _childNodes)
			{
				childNode.CloseChildrenDueToStartingOfBranchRecursion(hostedItem, onlyCloseChildrenAtThisLevelBelowYou - 1);
			}
		}

		public void GoTo(HostedItem item, Action<GoToControl> andDo, AllowUserToHandleEventBefore allowUserToHandleEventBefore, ControlBase controlWhichMayRequireFocus)
		{
			EnqueueGoToCommand enqueueGoToCommand = delegate
			{
			};
			enqueueGoToCommand = delegate(ContextTreeNode abortIfCurrentContextTreeNodeIsThis, bool goingIntoHandler)
			{
				_parent._eventQue.EnqueueNavigationCommand(delegate(EventHandler eventHandler)
				{
					eventHandler.ProcessNavigationCommand(delegate
					{
						Action gotoAction = delegate
						{
							_parent._currentContextTreeNode._item.EndEditingDueToChangingFocus(controlWhichMayRequireFocus, delegate
							{
								_parent._currentContextTreeNode.PrivateGoTo(item, andDo, enqueueGoToCommand, abortIfCurrentContextTreeNodeIsThis, goingIntoHandler);
							});
						};
						allowUserToHandleEventBefore(_parent._currentContextTreeNode._item.IsSameTaskAs(item), delegate(Command command, ControlBase control)
						{
							eventHandler.GoTo((IControl focusedControl) => control, command, gotoAction);
						}, gotoAction);
					}, () => _parent._currentContextTreeNode == abortIfCurrentContextTreeNodeIsThis);
				});
			};
			enqueueGoToCommand(null, goingIntoHandler: false);
		}

		private void PrivateGoTo(HostedItem item, Action<GoToControl> andDo, EnqueueGoToCommand enqueueGoToCommand, ContextTreeNode abortIfCurrentContextTreeNodeIsThis, bool goingIntoHandler)
		{
			bool reactivateForm = true;
			if (_item.IsSameTaskAs(item))
			{
				_item.ReachedByNavigation();
				andDo(delegate(IControl control, Action callAfterColumnIsReached)
				{
					_item.NavigateInFlow(delegate(NavigateInRowFlow navigateInRowFlow)
					{
						navigateInRowFlow(control, callAfterColumnIsReached);
					});
				});
			}
			else
			{
				_item.RunActionWhichMayCauseNavigationAwayFromYou(delegate
				{
					foreach (ContextTreeNode node in _childNodes)
					{
						bool stop = false;
						node.If(item, delegate
						{
							stop = true;
							_item.NavigateTo(new NavigationTargetClass(this, node, delegate(Action runTask, bool goingIntoHandler2)
							{
								reactivateForm = false;
								enqueueGoToCommand(this, goingIntoHandler2);
								runTask();
							}));
						});
						if (stop)
						{
							return;
						}
					}
					if (_parentNode != null && (!goingIntoHandler || _parentNode.IsItemAboveMe(item)) && _parentNode.GetChildRecursiveWithExclusion(item, this, searchBrachesOnly: false, _item.IgnoreRootContextInFormNavigation()))
					{
						_item.Close(delegate
						{
							enqueueGoToCommand(abortIfCurrentContextTreeNodeIsThis, goingIntoHandler: false);
						}, closingAll: false);
						reactivateForm = _item.IsRunning();
					}
				});
			}
			if (reactivateForm)
			{
				_item.ActivateForm(delegate
				{
				});
			}
		}

		private bool IsItemAboveMe(HostedItem item)
		{
			if (_item.IsSameTaskAs(item))
			{
				return true;
			}
			if (_parentNode == null)
			{
				return false;
			}
			return _parentNode.IsItemAboveMe(item);
		}

		private void If(HostedItem thisItemIsInYourPath, Action runMeIfFound)
		{
			if (GetChildRecursiveWithExclusion(thisItemIsInYourPath, null, searchBrachesOnly: true, ignoreRootNode: false))
			{
				runMeIfFound();
			}
		}

		public void RemoveChild(ContextTreeNode node)
		{
			if (_childNodes.Contains(node))
			{
				if (_parentNode != null)
				{
					_parentNode.CloseChildrenDueToStartingOf(node._item, 2);
				}
				node.CloseAndCloseChildren();
				_childNodes.Remove(node);
			}
			_childNodes.RemoveAll(delegate(ContextTreeNode treeNode)
			{
				if (treeNode.CloseWhen(node))
				{
					treeNode.CloseAndCloseChildren();
					return true;
				}
				return false;
			});
		}

		private bool CloseWhen(ContextTreeNode nodeCloses)
		{
			return _item.CloseWhen(nodeCloses._item);
		}

		private bool GetChildRecursiveWithExclusion(HostedItem itemToFind, ContextTreeNode excludeMe, bool searchBrachesOnly, bool ignoreRootNode)
		{
			if (_item == itemToFind && (!searchBrachesOnly || !_item.IsRunning()))
			{
				return true;
			}
			if (ignoreRootNode && (_parentNode == null || _parentNode._parentNode == null))
			{
				return false;
			}
			foreach (ContextTreeNode childNode in _childNodes)
			{
				if (childNode != excludeMe && childNode.GetChildRecursiveWithExclusion(itemToFind, excludeMe, searchBrachesOnly: true, ignoreRootNode))
				{
					return true;
				}
			}
			if (!searchBrachesOnly && _parentNode != null)
			{
				return _parentNode.GetChildRecursiveWithExclusion(itemToFind, this, searchBrachesOnly: false, ignoreRootNode);
			}
			return false;
		}

		private bool CloseAndCloseChildren()
		{
			bool flag = false;
			while (_childNodes.Count > 0)
			{
				ContextTreeNode contextTreeNode = _childNodes[0];
				if (contextTreeNode.CloseAndCloseChildren())
				{
					flag = true;
				}
				_childNodes.Remove(contextTreeNode);
			}
			return _item.CloseForm() || flag;
		}

		public T GetCachedTaskInstance<T>(Func<T> create, Func<T, Task> getTask, object uniqueIdentifier, object groupIdentifier, bool forKeepViewVisibleAfterExitOnly)
		{
			if (_cachedTasks.TryGetValue(uniqueIdentifier, out var value))
			{
				foreach (object item in value)
				{
					Task task = getTask((T)item);
					if (task == null || !task.IsRunning())
					{
						return (T)item;
					}
				}
			}
			else
			{
				value = new HashSet<object>();
				_cachedTasks.Add(uniqueIdentifier, value);
			}
			T task2 = create();
			Task task3 = getTask(task2);
			value.Add(task2);
			task3?.SetCachedTask(new myCachedTaskForTask(task2, delegate
			{
				if (_cachedTasks.TryGetValue(uniqueIdentifier, out var value2))
				{
					value2.Remove(task2);
					if (value2.Count == 0)
					{
						_cachedTasks.Remove(uniqueIdentifier);
					}
				}
			}, groupIdentifier, forKeepViewVisibleAfterExitOnly));
			return task2;
		}

		private void _SetParentForm(Action<XPARuntimeCore.Box.UI.Form> setParentForm)
		{
			_item.MakeYourFormParentOf(setParentForm, delegate
			{
				SetParentForm(setParentForm);
			});
		}

		public void SetParentForm(Action<XPARuntimeCore.Box.UI.Form> setParentForm)
		{
			if (_parentNode != null)
			{
				_parentNode._SetParentForm(setParentForm);
			}
		}

		public bool Matches(ContextNode newNode)
		{
			if (!(newNode is ContextTreeNode contextTreeNode))
			{
				return false;
			}
			if (contextTreeNode._parentNode == _parentNode)
			{
				return true;
			}
			return false;
		}

		public void ReactivateLastForm()
		{
			if (_parentNode == null)
			{
				return;
			}
			Action<int> activate = delegate
			{
			};
			activate = delegate(int i)
			{
				if (i < 0)
				{
					_parentNode.ReactivateLastForm();
				}
				else if (_parentNode._childNodes[i] == this)
				{
					activate(i - 1);
				}
				else
				{
					_parentNode._childNodes[i]._item.ReactivateForm(delegate
					{
						activate(i - 1);
					});
				}
			};
			activate(_parentNode._childNodes.Count - 1);
		}

		internal bool CloseChild(HostedItem hostedItem)
		{
			ContextTreeNode contextTreeNode = _childNodes.Find((ContextTreeNode i) => i._item == hostedItem);
			if (contextTreeNode != null)
			{
				RemoveChild(contextTreeNode);
			}
			return contextTreeNode != null;
		}

		internal bool HasNoChildItems()
		{
			return _childNodes.Count == 0;
		}
	}

	private class NullTaskInCallStack : ITaskInCallStack
	{
		private CallStackClass _parent;

		private bool _blockClosingContainerByUser;

		public bool InTransaction => false;

		public NullTaskInCallStack(CallStackClass parent)
		{
			_parent = parent;
		}

		public void Activate()
		{
		}

		public void CallMeIfYouHaveATransactionalEntitiy(EntityTransactionInfo andTellMeIfLocksAreOn)
		{
		}

		public void ActivateForm(Action noFormFoundToActivate)
		{
			noFormFoundToActivate();
		}

		public void ReactivateForm(Action noFormFoundToActivate)
		{
			noFormFoundToActivate();
		}

		public void SearchForHandlerThatRuns(object thisTask, InvokeCommand andRunThisWithTheAppropriateCommand)
		{
		}

		public void Deactivated()
		{
		}

		public void MakeYourselfTheCurrentContext(bool forContextUser, bool keepQueuedCommandsEvenIfCallStackCollapsed)
		{
			_blockClosingContainerByUser = true;
			try
			{
				_parent._currentTask = this;
				while (!keepQueuedCommandsEvenIfCallStackCollapsed && _parent._eventQue.Count != 0)
				{
					_parent._eventQue.Dequeue()(new ContainerEventHandler());
				}
				foreach (Task globalHandler in _parent._globalHandlers)
				{
					globalHandler.DisposeGlobalHandler();
				}
				_parent.WaitForOwnedContexts();
				if (!_parent._isUIThread)
				{
					return;
				}
				CallStackClass contextToReactivate = null;
				lock (_contextsZOrder)
				{
					_contextsZOrder.Remove(_parent);
					if (_contextsZOrder.Count > 0)
					{
						contextToReactivate = _contextsZOrder[0];
					}
				}
				Context.Current.UICommands.Resume();
				if (contextToReactivate != null)
				{
					contextToReactivate.EnqueueNavigationCommand(delegate
					{
						contextToReactivate.ReturnFocusToActiveForm();
					});
				}
			}
			finally
			{
				_blockClosingContainerByUser = false;
			}
		}

		public void SendMessageHandler(Action<WindowsMessageLoop.MessageHandler> toMe)
		{
			toMe(new DefaultMessageHandler());
		}

		public void ForTestingOnlyWrapEventProcessing(Action action)
		{
		}

		public void Close()
		{
		}

		public void Close(Action doBeforeClosing)
		{
			doBeforeClosing();
		}

		public void DoExitApplication(Action andDo)
		{
			andDo();
		}

		public void RefreshSubForm(Func<IControl, bool> isThisTheSubformToRefresh)
		{
		}

		public System.Windows.Forms.Form GetTopMostForm()
		{
			return null;
		}

		public void NavigationIdle()
		{
		}

		public void SetCommandsEnabledState()
		{
		}

		public void CloseDueToCloseAllTasksAndRun(Action run, EventHandler eventHandler)
		{
			run();
		}

		public void CloseChildDueToCloseAllTasksAndRun(Action run, EventHandler eventHandler)
		{
			run();
		}

		public void RestoreCommandsEnabledState()
		{
		}

		public void MakeYourselfTheCurrentParentViewContext()
		{
			_parent._currentContextTreeNode = _parent._rootContextTreeNode;
		}

		public void ExecuteEvent(EventDelegate currentEvent)
		{
			throw new Error.DidNotAnticipateThis();
		}

		public void Populate(TaskCollection collection)
		{
		}

		public void HandleCommand(Command command, ControlBase control, object[] args, Action<CommandRaisingAndInvoking> handle)
		{
		}

		public void DoOnBottomTask(Action<HostedItem> thisCommand, HostedItem childHostedItem)
		{
			thisCommand(childHostedItem);
		}

		public void UserTriedToCloseContainer(Action cancelClosing)
		{
			if (_blockClosingContainerByUser)
			{
				cancelClosing();
			}
		}

		public void DoOnTaskTransactionContainer(Action<TaskTransactionContainer> doOnTrans)
		{
		}

		public void ProcessTimerAndExpressionEvents(bool forceEvents)
		{
		}

		public void RemoveFromContextTree(Action<bool> remove)
		{
		}

		public void AddChildApplicationToContextTreeNode(Action addCommand)
		{
			addCommand();
		}

		public void RemoveChildApplicationFromContextTree(Action<bool> removeCommand)
		{
			removeCommand(obj: false);
		}

		public void AddStateTo(Action<SavedState> add)
		{
		}

		public void EventProcessingCompleted()
		{
		}

		public void RunOnTask(Action<Task> runThis)
		{
		}
	}

	private class ContainerEventHandler : EventHandler
	{
		public void Handle(Command command, CommandInvokationStuff stuff, Action defaultAction)
		{
			defaultAction();
		}

		public void UserAskedToPutString(string text, Action defaultAction)
		{
			defaultAction();
		}

		public void DoUserActionByName(string actionName)
		{
		}

		public void CheckKeyContext(KeyContextResult result)
		{
		}

		public void Invoke(ListenerRunner runner)
		{
			runner.DoDefaultAction(this);
		}

		public void ProcessNavigationCommand(Action cmd, Func<bool> abortCommand)
		{
			cmd();
		}

		public void RunCustomCommand(CustomCommandPrecondition precondition, Action action, Action<Action<Action>> runBeforeLeavingControl)
		{
			action();
		}

		public bool ParkedControlIs(ControlBase controlBase)
		{
			return false;
		}

		public void WrapInvokingFromQueue(Command command, Func<IControl, IControl> controlBase, bool doNotRepeatInMultiSelect, Action<IControl> invoke, Action raiseAgain)
		{
			invoke(controlBase(null));
		}

		public void ProcessUnhandledCommand(Command c, Action doDefault)
		{
			doDefault();
		}

		public void SendKeys(Keys keys)
		{
		}

		public void GoTo(Func<IControl, IControl> control, Command commandToInvokeBefore, Action gotoAction)
		{
			gotoAction();
		}

		public void ExpandParkedColumn()
		{
		}
	}

	private class TaskInCallStack : ITaskInCallStack, TaskRunContext, TaskInCallStackForTransaction
	{
		private class FormsManagerClass : FormsManager
		{
			private TaskInCallStack _parent;

			private CallStackClass _callSTack;

			public FormsManagerClass(TaskInCallStack parent, CallStackClass callStack)
			{
				_parent = parent;
				_callSTack = callStack;
			}

			public void GoTo(Action<GoToControl> cmd, AllowUserToHandleEventBefore allowUserToHandleEventBefore, ControlBase controlWhichMayRequireFocus)
			{
				if (!_parent._isApplication)
				{
					_callSTack._currentContextTreeNode.GoTo(_parent._hostedItem, cmd, allowUserToHandleEventBefore, controlWhichMayRequireFocus);
				}
			}

			public void RefreshSubForm(Func<IControl, bool> isThisTheSubformToRefresh)
			{
				_parent.RefreshSubForm(isThisTheSubformToRefresh);
			}

			public void ReturnFocusToActiveForm()
			{
				_parent._parent.ReturnFocusToActiveForm();
			}

			public void RequestReactivation(XPARuntimeCore.Box.UI.Form form, Action reactivate)
			{
				_callSTack.RequestReactivation(form, reactivate);
			}
		}

		private class FormContainerClass : FormContainer
		{
			private TaskInCallStack _parent;

			public FormContainerClass(TaskInCallStack parent)
			{
				_parent = parent;
			}

			public void AddChildForm(XPARuntimeCore.Box.UI.Form form, XPARuntimeCore.Box.UI.Form callingForm, bool dock, bool floatingWindow, bool modal, bool forceTopLevel)
			{
				_parent._form = form;
				if ((floatingWindow || forceTopLevel) && !_parent._parent._inFloatingState)
				{
					_parent._parent._inFloatingState = true;
					_parent._runBeforeDeactivatingForm.Add(delegate
					{
						_parent._parent._inFloatingState = false;
					});
				}
				_parent._parent._mainThread.AddChildForm(form, _parent._parentTaskWatchOutICanReturnAnApplication.GetTopMostForm(), (callingForm != null) ? (callingForm.TopLevelControl as System.Windows.Forms.Form) : null, dock, _parent._parent._inFloatingState, modal, forceTopLevel, delegate(MainThread.RunBeforeDeactivatingForm x)
				{
					_parent._runBeforeDeactivatingForm.Add(delegate(Action a)
					{
						_parent.InvokeOnUIThread(delegate
						{
							x(a);
						});
					});
				});
			}
		}

		private class MyContextInstance : ContextInstance, ContextUser, IDisposable
		{
			private CallStackClass _parent;

			private TaskInCallStack _theTask;

			private ITaskInCallStack _previousTask;

			public MyContextInstance(CallStackClass parent, TaskInCallStack theTask)
			{
				_parent = parent;
				_theTask = theTask;
			}

			public void NeedContext()
			{
				if (_previousTask == null)
				{
					_previousTask = _parent._currentTask;
					_theTask.MakeYourselfTheCurrentContext(forContextUser: true, keepQueuedCommandsEvenIfCallStackCollapsed: false);
				}
			}

			public void Dispose()
			{
				if (_previousTask != null)
				{
					_previousTask.MakeYourselfTheCurrentContext(forContextUser: true, keepQueuedCommandsEvenIfCallStackCollapsed: false);
				}
			}
		}

		private HostedItem _hostedItem;

		private bool _isApplication;

		private ITaskInCallStack _parentTaskWatchOutICanReturnAnApplication;

		private TaskTransactionContainer _transactionContainer;

		private CallStackClass _parent;

		private ITaskInCallStack _previouslyRunningTask;

		private ParentEventManagers _parentEventManagers;

		private XPARuntimeCore.Box.UI.Form _form;

		private List<MainThread.RunBeforeDeactivatingForm> _runBeforeDeactivatingForm = new List<MainThread.RunBeforeDeactivatingForm>();

		private Dictionary<Command, bool> _commandsForActivation = new Dictionary<Command, bool>();

		private Action _runToMakeYourselfTheCurrentParentViewContext = delegate
		{
		};

		private Action<bool> _setAsTheCurrentContext = delegate
		{
		};

		public bool InTransaction => _transactionContainer.InTransaction;

		public TaskInCallStack(HostedItem hostedItem, bool isApplication, ITaskInCallStack parentTask, ITaskInCallStack runningTask, CallStackClass parent, ParentEventManagers parentEventManagers)
		{
			_parent = parent;
			_hostedItem = hostedItem;
			_isApplication = isApplication;
			_parentTaskWatchOutICanReturnAnApplication = parentTask;
			_previouslyRunningTask = runningTask;
			_transactionContainer = new TaskTransactionContainer(this);
			_parentEventManagers = parentEventManagers;
		}

		public void ProcessTimerAndExpressionEvents(bool forceEvents)
		{
			_hostedItem.ProcessTimerAndExpressionEvents(forceEvents);
		}

		public void AddToContextTreeNode(Action addCommand)
		{
			if (_isApplication)
			{
				_parentTaskWatchOutICanReturnAnApplication.AddChildApplicationToContextTreeNode(addCommand);
			}
			else
			{
				addCommand();
			}
		}

		public void RemoveFromContextTree(Action<bool> remove)
		{
			if (_isApplication)
			{
				_parentTaskWatchOutICanReturnAnApplication.RemoveChildApplicationFromContextTree(remove);
			}
			else
			{
				_hostedItem.RemoveFromContextTree(remove);
			}
		}

		public void AddChildApplicationToContextTreeNode(Action addCommand)
		{
		}

		public void RemoveChildApplicationFromContextTree(Action<bool> removeCommand)
		{
		}

		public void DisplayForm(Action<FormContainer, FormsManager> display)
		{
			display(new FormContainerClass(this), new FormsManagerClass(this, _parent));
		}

		public void SendCurrentForm(Action<XPARuntimeCore.Box.UI.Form> doOnForm)
		{
			_parent._currentContextTreeNode.SetParentForm(doOnForm);
		}

		public void RefreshSubForm(Func<IControl, bool> isThisTheSubformToRefresh)
		{
			_hostedItem.RefreshSubForm(isThisTheSubformToRefresh, delegate
			{
				_parentTaskWatchOutICanReturnAnApplication.RefreshSubForm(isThisTheSubformToRefresh);
			});
		}

		public System.Windows.Forms.Form GetTopMostForm()
		{
			if (_form != null && _form.TopLevelControl is System.Windows.Forms.Form { Owner: null } form)
			{
				return form;
			}
			return _parentTaskWatchOutICanReturnAnApplication.GetTopMostForm();
		}

		public void NavigationIdle()
		{
			_hostedItem.NavigationIdle();
		}

		public void SetCommandsEnabledState()
		{
			if (!_parent._isUIThread)
			{
				return;
			}
			foreach (KeyValuePair<Command, bool> item in _commandsForActivation)
			{
				item.Key.Enabled = item.Value;
			}
		}

		public void CloseDueToCloseAllTasksAndRun(Action run, EventHandler eventHandler)
		{
			_parentTaskWatchOutICanReturnAnApplication.CloseChildDueToCloseAllTasksAndRun(run, eventHandler);
		}

		public void CloseChildDueToCloseAllTasksAndRun(Action run, EventHandler eventHandler)
		{
			eventHandler.ProcessNavigationCommand(delegate
			{
				eventHandler.GoTo((IControl focusedControl) => focusedControl, Command.Exit, delegate
				{
					_parent._currentTask.Close(delegate
					{
						_parent.EnqueueNavigationCommand(delegate(EventHandler handler)
						{
							_parent.PrivateCloseAllTasksAndRun(run, handler);
						});
					});
				});
			}, () => false);
		}

		public void RunInContext(Action command)
		{
			if (_parent._currentTask == this)
			{
				command();
				return;
			}
			ITaskInCallStack currentTask = _parent._currentTask;
			MakeYourselfTheCurrentContext(forContextUser: false, keepQueuedCommandsEvenIfCallStackCollapsed: false);
			try
			{
				command();
			}
			finally
			{
				currentTask.MakeYourselfTheCurrentContext(forContextUser: false, keepQueuedCommandsEvenIfCallStackCollapsed: false);
			}
		}

		public ContextInstance CreateContextInstance()
		{
			if (_parent._currentTask == this)
			{
				return DummyContextInstance.Instance;
			}
			return new MyContextInstance(_parent, this);
		}

		private void ProcessWindowsMessages(Action<Action<WindowsMessageLoop.MessageHandler>> callProessMessages)
		{
			Context.Current.SuspendMenus();
			Context.Current.UICommands.Flush(whileBusy: true);
			callProessMessages(delegate(WindowsMessageLoop.MessageHandler messageHandler)
			{
				_parent._messageLoop.ProcessNextMessage(delegate(WindowsMessageLoop.Message msg)
				{
					_parent.DispatchMssage(msg, messageHandler);
					Context.Current.UICommands.Flush(whileBusy: true);
				}, 0, delegate
				{
				});
			});
		}

		public void ProcessWindowsMessagesOrSingleEvent(WindowsMessageLoop.MessageHandler messageHandler, EventHandler handler, FormForTask form)
		{
			ProcessWindowsMessages(delegate(Action<WindowsMessageLoop.MessageHandler> callProessMessages)
			{
				_parent._eventQue.ProcessUnclearableCommands();
				if (_parent._eventQue.Count > 0)
				{
					_parent._eventQue.Dequeue()(handler);
				}
				else
				{
					form.AlwaysForcePaintWhileBusyProcessing(_parent._messageLoop.UpdateAllWindows);
					callProessMessages(messageHandler);
				}
			});
		}

		public void ForcePaint()
		{
			Context.Current.UICommands.Flush(whileBusy: true);
			_parent._messageLoop.UpdateAllWindows();
		}

		public object GetContext()
		{
			return _parent;
		}

		public void InvokeOnUIThread(Action action)
		{
			_parent.InvokeInUIThread(action);
		}

		public void InvokeOnLogicThread(Action action)
		{
			_parent.InvokeOnLogicThread(action);
		}

		public void DoOnParentEventManagers(Action<ParentEventManagers> doThis)
		{
			doThis(_parentEventManagers);
		}

		public void RunWhileYouAreTheParentView(Action action)
		{
			if (_parent._currentTask == this)
			{
				action();
				return;
			}
			ITaskInCallStack currentTask = _parent._currentTask;
			MakeYourselfTheCurrentParentViewContext();
			try
			{
				action();
			}
			finally
			{
				currentTask.MakeYourselfTheCurrentParentViewContext();
			}
		}

		public void PushEventManager(Task currentEventManager)
		{
			_parent.PushEventManager(currentEventManager);
		}

		public Task PopEventManager()
		{
			return _parent.PopEventManager();
		}

		public void PushEventStack(Task currentEventManager)
		{
			Task[] array = _parent._eventsCallStack.ToArray();
			Array.Reverse(array);
			int num = Array.IndexOf(array, currentEventManager);
			if (num == -1)
			{
				Array.Resize(ref array, array.Length + 1);
				array[array.Length - 1] = currentEventManager;
			}
			else
			{
				Array.Resize(ref array, num + 1);
			}
			_parent._eventsCallStackStack.Push(new Stack<Task>(array));
		}

		public void PopEventStack()
		{
			_parent._eventsCallStackStack.Pop();
		}

		public void ExitApplication()
		{
			List<CallStackClass> list;
			lock (_parent._ownedContextsSync)
			{
				list = new List<CallStackClass>(_parent._ownedContexts);
			}
			CallStackClass[] array = list.ToArray();
			foreach (CallStackClass callStackClass in array)
			{
				CallStackClass o = callStackClass;
				o._mainThread.BeginInvokeOnLogicThreadThroughUIThread(delegate
				{
					o.ExitContext();
				}, o, delegate
				{
					o.EnqueueNavigationCommand(delegate
					{
						o.ExitContext();
					});
				});
			}
			if (_parent._mainContext != null)
			{
				_parent._mainContext.EnqueueNavigationCommand(delegate
				{
					_parent._mainContext._currentTask.UserTriedToCloseContainer(delegate
					{
					});
				});
			}
			_parent.EnqueueNavigationCommand(delegate
			{
				_parent.DoExitApplication(delegate
				{
				});
			});
		}

		public void RunMessageLoop(WindowsMessageLoop.StopLoop stopLoop, WindowsMessageLoop.MessageHandler messageHandler, Action<Action> wrapEventProcessing)
		{
			bool stopMessageLoop = false;
			Action checkStopLoop = delegate
			{
				_parent.HandleUIException();
				_parent.ProcessEvents(() => stopLoop());
				stopMessageLoop = stopLoop();
				Context.Current.ResumeMenus();
				if (!stopMessageLoop)
				{
					Context.Current.UICommands.Flush(whileBusy: false);
				}
			};
			wrapEventProcessing(checkStopLoop);
			while (!stopMessageLoop)
			{
				wrapEventProcessing(delegate
				{
					_parent._messageLoop.ProcessNextMessage(delegate(WindowsMessageLoop.Message msg)
					{
						_parent.DispatchMssage(msg, messageHandler);
					}, 100, delegate
					{
					});
					checkStopLoop();
				});
			}
		}

		public void SetActionState(Command command, bool enabled)
		{
			_commandsForActivation[command] = enabled;
			if (_parent._currentTask == this)
			{
				command.Enabled = enabled;
			}
		}

		public void AboutToDeactivateForm(SubFormRunningState subFormRunningState, Action forceFormClosing)
		{
			_runBeforeDeactivatingForm.ForEach(delegate(MainThread.RunBeforeDeactivatingForm runBeforeDeactivatingForm)
			{
				runBeforeDeactivatingForm(forceFormClosing);
			});
			_runBeforeDeactivatingForm = new List<MainThread.RunBeforeDeactivatingForm>();
			if (!subFormRunningState.EndTaskAfterEnterRow())
			{
				_previouslyRunningTask.ReactivateForm(delegate
				{
					_parent._currentContextTreeNode.ReactivateLastForm();
				});
			}
		}

		public void DoOnTaskTransactionContainer(Action<TaskTransactionContainer> doOnTrans)
		{
			doOnTrans(_transactionContainer);
		}

		public void HandleCommand(Command command, ControlBase control, object[] args, Action<CommandRaisingAndInvoking> handle)
		{
			_hostedItem.HandleCommand(command, control, args, handle);
		}

		public void Populate(TaskCollection collection)
		{
			_parentTaskWatchOutICanReturnAnApplication.Populate(collection);
			_hostedItem.AddTaskTo(collection);
		}

		public void ExecuteEvent(EventDelegate currentEvent)
		{
			_hostedItem.ExecuteEvent(currentEvent);
		}

		public void Activate()
		{
			_hostedItem.Activated();
		}

		public void ActivateForm(Action noFormFoundToActivate)
		{
			_hostedItem.ActivateForm(delegate
			{
				_previouslyRunningTask.ActivateForm(noFormFoundToActivate);
			});
		}

		public void ReactivateForm(Action noFormFoundToActivate)
		{
			if (_isApplication)
			{
				_previouslyRunningTask.ReactivateForm(noFormFoundToActivate);
				return;
			}
			_hostedItem.ReactivateForm(delegate
			{
				_previouslyRunningTask.ReactivateForm(noFormFoundToActivate);
			});
		}

		public void SearchForHandlerThatRuns(object thisTask, InvokeCommand andRunThisWithTheAppropriateCommand)
		{
			bool found = false;
			_hostedItem.SearchForHandlerThatRuns(thisTask, delegate(Command cmd, ControlIdentifierForHandler ctrl)
			{
				andRunThisWithTheAppropriateCommand(cmd, ctrl);
				found = true;
			});
			if (!found)
			{
				_parentTaskWatchOutICanReturnAnApplication.SearchForHandlerThatRuns(thisTask, andRunThisWithTheAppropriateCommand);
			}
		}

		public void Deactivated()
		{
			_hostedItem.Deactivated();
		}

		public void MakeYourselfTheCurrentContext(bool forContextUser, bool keepQueuedCommandsEvenIfCallStackCollapsed)
		{
			_setAsTheCurrentContext(forContextUser);
		}

		public void SendMessageHandler(Action<WindowsMessageLoop.MessageHandler> toMe)
		{
			_hostedItem.SendMessageHandler(toMe);
		}

		public void ForTestingOnlyWrapEventProcessing(Action action)
		{
			_hostedItem.ForTestingOnlyWrapEventProcessing(action);
		}

		public void Close(Action doBeforeClosing)
		{
			_hostedItem.Close(doBeforeClosing, closingAll: true);
		}

		public void DoExitApplication(Action andDo)
		{
			_hostedItem.HandleCommand(_isApplication ? Command.ExitApplication : Command.Exit, null, new object[0], delegate(CommandRaisingAndInvoking invoking)
			{
				invoking.Invoke(delegate
				{
				});
			});
			_parent.DoExitApplication(andDo);
		}

		public void RestoreCommandsEnabledState()
		{
			if (!_parent._isUIThread)
			{
				return;
			}
			foreach (Command key in _commandsForActivation.Keys)
			{
				key.Enabled = key.GetDefaultEnabled();
			}
		}

		public void MakeYourselfTheCurrentParentViewContext()
		{
			_runToMakeYourselfTheCurrentParentViewContext();
		}

		public void DoOnBottomTask(Action<HostedItem> thisCommand, HostedItem childHostedItem)
		{
			_parentTaskWatchOutICanReturnAnApplication.DoOnBottomTask(thisCommand, _hostedItem);
		}

		public void UserTriedToCloseContainer(Action cancelClosing)
		{
			cancelClosing();
			_hostedItem.HandleCommand(Command.ExitApplication, null, new object[0], delegate(CommandRaisingAndInvoking invoking)
			{
				invoking.Raise(replaceColumnsWithValuesInArgs: true);
			});
		}

		public void DoOnParentTransaction(Action<TaskTransactionContainer> parentTrans)
		{
			_parentTaskWatchOutICanReturnAnApplication.DoOnTaskTransactionContainer(parentTrans);
		}

		public void DoOnCurrentActiveTaskTransactionInCallstack(Action<TaskTransactionContainer> container)
		{
			_parent._currentTask.DoOnTaskTransactionContainer(container);
		}

		public void RollbackHappened()
		{
			_hostedItem.RollbackHappened();
		}

		public void RecoverFromRowLevelExceptionWithoutRollback()
		{
			_hostedItem.RecoverFromRowLevelExceptionWithoutRollback();
		}

		public bool UseChildTransaction()
		{
			return _hostedItem.UseChildTransaction();
		}

		public void CallMeIfYouHaveATransactionalEntitiy(EntityTransactionInfo andTellMeIfLocksAreOn)
		{
			bool done = false;
			_transactionContainer.CallMeIfYouHaveATransactionalEntitiy(delegate(bool locksAreOn, bool requireTransactionForLocking)
			{
				done = true;
				andTellMeIfLocksAreOn(locksAreOn, requireTransactionForLocking);
			});
			if (!done)
			{
				_parentTaskWatchOutICanReturnAnApplication.CallMeIfYouHaveATransactionalEntitiy(delegate(bool locksAreOn, bool requireTransactionForLocking)
				{
					andTellMeIfLocksAreOn(locksAreOn: false, requireTransactionForLocking);
				});
			}
		}

		public void RunThisToSetYourselfAsTheCurrentContext(Action<bool> action)
		{
			_setAsTheCurrentContext = action;
		}

		public void RunThisToSetYourselfAsTheCurrentParentViewContext(Action action)
		{
			_runToMakeYourselfTheCurrentParentViewContext = action;
		}

		public void AddTransactionProvider(TransactionProvider provider, MonitoredDatabaseClient monitorClient)
		{
			_transactionContainer.AddTransactionProvider(provider, monitorClient);
		}

		public void StartTransaction(TransactionTypeStrategy transactionTypeStrategy, MonitoredDatabaseClient monitorClient)
		{
			_transactionContainer.StartTransaction(transactionTypeStrategy, monitorClient);
		}

		public void Commit(MonitoredDatabaseClient monitorClient)
		{
			_transactionContainer.Commit(monitorClient);
		}

		public void RunMonitoredCommand(Action command, TransactionRollbackDelegate callMeIfYouRollbacked)
		{
			_transactionContainer.RunMonitoredCommand(command, callMeIfYouRollbacked);
		}

		public void RollbackIfYouAreARootTransaction()
		{
			_transactionContainer.RollbackIfYouAreARootTransaction();
		}

		public void RunRecoverableMonitoredCommand(Action command, Action callMeIfYouRollbacked, bool throwExceptionIfNotRecover)
		{
			_transactionContainer.RunRecoverableMonitoredCommand(command, callMeIfYouRollbacked, throwExceptionIfNotRecover);
		}

		public IRowsSource WrapRowsSource(IRowsSource wrapMe)
		{
			return _transactionContainer.WrapRowsSource(wrapMe);
		}

		public void ProcessSingleEvent(EventHandlerWrapperForProcessSingleEvent eventHandlerWrapper)
		{
			_parent.ProcessSingleEvent(eventHandlerWrapper);
		}

		public bool IsCurrentInCallStack()
		{
			return _parent._runningTask == this;
		}

		public bool IsOptimisticConcurrencyRequired()
		{
			return _transactionContainer.IsOptimisticConcurrencyRequired();
		}

		public void SetAsFocusedContext()
		{
			CallStackClass focusedContext = _focusedContext;
			if (focusedContext == _parent)
			{
				return;
			}
			_focusedContext = _parent;
			lock (_contextsZOrder)
			{
				_contextsZOrder.Remove(_parent);
				_contextsZOrder.Insert(0, _parent);
			}
			_parent.InvokeOnLogicThread(delegate
			{
				Command.ForEach(delegate(Command command)
				{
					command.RefreshBoundMenus();
				});
				Context.Current.InvokeFocusedContextChanged((focusedContext == null) ? null : focusedContext._owner);
			});
		}

		public void ProcessWindowsMessages(WindowsMessageLoop.MessageHandler messageHandler)
		{
			ProcessWindowsMessages(delegate(Action<WindowsMessageLoop.MessageHandler> action)
			{
				action(messageHandler);
			});
		}

		public void InnerTextBoxClicked()
		{
			_parent._blockTextBoxCursorCommands = true;
		}

		public void WrapTextBoxCursorMovementCommnad(Action action)
		{
			if (!_parent._blockTextBoxCursorCommands)
			{
				action();
			}
		}

		public void AddStateTo(Action<SavedState> add)
		{
			_hostedItem.AddStateTo(add);
			_parentTaskWatchOutICanReturnAnApplication.AddStateTo(add);
		}

		public void EventProcessingCompleted()
		{
			_hostedItem.EventProcessingCompleted();
		}

		public bool CloseForm()
		{
			return _parent._currentContextTreeNode.CloseChild(_hostedItem);
		}

		public void RunOnCurrentTask(Action<Task> runThis)
		{
			_parent._currentTask.RunOnTask(runThis);
		}

		public void RunOnTask(Action<Task> runThis)
		{
			_hostedItem.RunOnTask(runThis);
		}
	}

	private class myEventQueue
	{
		private List<EventDelegate> _commands = new List<EventDelegate>();

		private List<EventDelegate> _navigationCommands = new List<EventDelegate>();

		private List<EventDelegate> _unclearableCommands = new List<EventDelegate>();

		private List<EventDelegate> _delayedUnclearableCommands = new List<EventDelegate>();

		private DateTime _timestampOfLastEnqueue = DateTime.Now;

		private Action _beforeDequeue;

		public int Count => _commands.Count + _navigationCommands.Count + _unclearableCommands.Count + _delayedUnclearableCommands.Count;

		public bool HasNavigationCommands => _navigationCommands.Count > 0;

		public myEventQueue(Action beforeDequeue)
		{
			_beforeDequeue = beforeDequeue;
		}

		public void Enqueue(EventDelegate cmd)
		{
			lock (this)
			{
				_commands.Add(cmd);
			}
			_timestampOfLastEnqueue = DateTime.Now;
		}

		public EventDelegate Dequeue()
		{
			lock (this)
			{
				_beforeDequeue();
				if (_unclearableCommands.Count > 0)
				{
					EventDelegate result = _unclearableCommands[0];
					_unclearableCommands.RemoveAt(0);
					return result;
				}
				if (_navigationCommands.Count > 0)
				{
					EventDelegate result2 = _navigationCommands[0];
					_navigationCommands.RemoveAt(0);
					return result2;
				}
				if (_commands.Count > 0)
				{
					EventDelegate result3 = _commands[0];
					_commands.RemoveAt(0);
					return result3;
				}
				if (_delayedUnclearableCommands.Count > 0)
				{
					EventDelegate result4 = _delayedUnclearableCommands[0];
					_delayedUnclearableCommands.RemoveAt(0);
					return result4;
				}
				return null;
			}
		}

		public void EnqueueAtBottom(EventDelegate cmd)
		{
			lock (this)
			{
				_commands.Insert(0, cmd);
			}
			_timestampOfLastEnqueue = DateTime.Now;
		}

		public void EnqueueNavigationCommand(EventDelegate cmd)
		{
			lock (this)
			{
				_navigationCommands.Insert(0, cmd);
			}
			_timestampOfLastEnqueue = DateTime.Now;
		}

		public void EnqueueUnclearableCommand(EventDelegate cmd)
		{
			lock (this)
			{
				_unclearableCommands.Add(cmd);
			}
		}

		public void Clear()
		{
			lock (this)
			{
				_navigationCommands.Clear();
				_commands.Clear();
			}
		}

		public int GetIdleSeconds()
		{
			return (int)(DateTime.Now - _timestampOfLastEnqueue).TotalSeconds;
		}

		public void EnqueueDelayedUnclearableCommand(Action action)
		{
			lock (this)
			{
				_delayedUnclearableCommands.Add(delegate
				{
					action();
				});
			}
		}

		internal void ProcessUnclearableCommands()
		{
			while (_unclearableCommands.Count > 0)
			{
				Dequeue()(new NullEventHandler());
			}
		}
	}

	public delegate void DispatchMessage(WindowsMessageLoop.MessageHandler messageHandler);

	private class MockMessageLoopWithQueue : WindowsMessageLoop.MessageLoop
	{
		private class MockMessage : WindowsMessageLoop.Message
		{
			private class myMockMessageHandler : WindowsMessageLoop.MessageHandler
			{
				private WindowsMessageLoop.MessageHandler _wrapped;

				private Action<Action, object> _doOnUiThread;

				private object _context;

				public myMockMessageHandler(WindowsMessageLoop.MessageHandler wrapped, Action<Action, object> doOnUiThread, object context)
				{
					_wrapped = wrapped;
					_doOnUiThread = doOnUiThread;
					_context = context;
				}

				public void HandleMouseDown(Control control, bool leftButtonWasUsed, Point location, Action dispatchToWindows, Action sendMouseUp)
				{
					_wrapped.HandleMouseDown(control, leftButtonWasUsed, location, delegate
					{
						_doOnUiThread(dispatchToWindows, _context);
					}, sendMouseUp);
				}

				public void HandleKeyboard(Control control, Keys keyData, Action dispatchToWindows)
				{
					_wrapped.HandleKeyboard(control, keyData, delegate
					{
						_doOnUiThread(dispatchToWindows, _context);
					});
				}

				public void HandleLeftDoubleClick(Control controlClicked, Point location, Action dispatchToWindows)
				{
					_wrapped.HandleLeftDoubleClick(controlClicked, location, delegate
					{
						_doOnUiThread(dispatchToWindows, _context);
					});
				}

				public void HandleChar(char c, Action dispatchToWindows)
				{
					_wrapped.HandleChar(c, delegate
					{
						_doOnUiThread(dispatchToWindows, _context);
					});
				}

				public void HandleLeftMouseUp(Control controlClicked)
				{
					_wrapped.HandleLeftMouseUp(controlClicked);
				}
			}

			private DispatchMessage _action;

			private object _context;

			public MockMessage(DispatchMessage action, object context)
			{
				_context = context;
				_action = action;
			}

			public void DispatchMessage(WindowsMessageLoop.MessageHandler messageHandler, Action<Action, object> doOnUiThread)
			{
				_action(new myMockMessageHandler(messageHandler, doOnUiThread, _context));
			}

			public object GetContext()
			{
				return _context;
			}
		}

		private Queue<WindowsMessageLoop.Message> _messages = new Queue<WindowsMessageLoop.Message>();

		public void ProcessNextMessage(Action<WindowsMessageLoop.Message> howToProcessIt, int waitMS, Action<Action<IntPtr>> addWaitHandles)
		{
			if (_messages.Count > 0)
			{
				howToProcessIt(_messages.Dequeue());
			}
		}

		public void UpdateAllWindows()
		{
		}

		public void AddMessage(DispatchMessage thatDoesThis, object context)
		{
			_messages.Enqueue(new MockMessage(thatDoesThis, context));
		}

		public void WrapRunFirstMessageLoop(Action run)
		{
			run();
		}
	}

	private class myMessageHandlingWrapper : WindowsMessageLoop.MessageHandler
	{
		private WindowsMessageLoop.MessageHandler _wrapped;

		public myMessageHandlingWrapper(WindowsMessageLoop.MessageHandler wrapped)
		{
			_wrapped = wrapped;
		}

		public void HandleKeyboard(Control control, Keys keyData, Action dispatchToWindows)
		{
			XPARuntimeCore.Box.UI.Form.InvokeUserInput();
			_wrapped.HandleKeyboard(control, keyData, dispatchToWindows);
		}

		public void HandleLeftDoubleClick(Control controlClicked, Point location, Action dispatchToWindows)
		{
			XPARuntimeCore.Box.UI.Form.InvokeUserInput();
			_wrapped.HandleLeftDoubleClick(controlClicked, location, dispatchToWindows);
		}

		public void HandleChar(char c, Action dispatchToWindows)
		{
			_wrapped.HandleChar(c, dispatchToWindows);
		}

		public void HandleMouseDown(Control control, bool leftButtonWasUsed, Point location, Action dispatchToWindows, Action sendMouseUp)
		{
			XPARuntimeCore.Box.UI.Form.InvokeUserInput();
			_wrapped.HandleMouseDown(control, leftButtonWasUsed, location, delegate
			{
				dispatchToWindows();
			}, sendMouseUp);
		}

		public void HandleLeftMouseUp(Control controlClicked)
		{
			_wrapped.HandleLeftMouseUp(controlClicked);
		}
	}

	private class MessageHandlerForSuspend : WindowsMessageLoop.MessageHandler
	{
		public bool UserHitKeyboad;

		public Keys KeyHitByUser;

		private WindowsMessageLoop.MessageHandler _wrapped;

		private ITaskInCallStack _currentTask;

		public MessageHandlerForSuspend(WindowsMessageLoop.MessageHandler wrapped, ITaskInCallStack currentTask)
		{
			_wrapped = wrapped;
			_currentTask = currentTask;
		}

		public void HandleMouseDown(Control control, bool leftButtonWasUsed, Point location, Action dispatchToWindows, Action sendMouseUp)
		{
			_wrapped.HandleMouseDown(control, leftButtonWasUsed, location, dispatchToWindows, sendMouseUp);
		}

		public void HandleKeyboard(Control control, Keys keyData, Action dispatchToWindows)
		{
			UserHitKeyboad = true;
			KeyHitByUser = keyData;
			_wrapped.HandleKeyboard(control, keyData, dispatchToWindows);
		}

		public void HandleLeftDoubleClick(Control controlClicked, Point location, Action dispatchToWindows)
		{
			_wrapped.HandleLeftDoubleClick(controlClicked, location, dispatchToWindows);
		}

		public void HandleChar(char c, Action dispatchToWindows)
		{
			_wrapped.HandleChar(c, delegate
			{
				_currentTask.HandleCommand(Command.InputText(c.ToString()), null, new object[0], delegate(CommandRaisingAndInvoking h)
				{
					h.Raise(replaceColumnsWithValuesInArgs: false);
				});
			});
		}

		public void HandleLeftMouseUp(Control controlClicked)
		{
			_wrapped.HandleLeftMouseUp(controlClicked);
		}
	}

	private class SuspendManagerClass : SuspendManager, Suspended
	{
		private class myAction
		{
			public bool IgnoreInForcePaint;

			public Action Action;

			public SuspendedCommandStillValid StillValid = () => true;

			public myAction(Action action)
			{
				Action = action;
			}
		}

		private class DeferredLayoutManager : LayoutManager
		{
			private delegate void CollectCommand(Control control, LayoutCommand command);

			private delegate void WaitingCommand(CollectCommand collect);

			private class ControlBoundsClass : ControlBounds
			{
				private Control _control;

				private Rectangle _bounds;

				public ControlBoundsClass(Control control)
				{
					_control = control;
					_bounds = control.Bounds;
				}

				public void Update(int x, int y, int width, int height, BoundsSpecified specified)
				{
					if ((specified & BoundsSpecified.X) == BoundsSpecified.X)
					{
						_bounds.X = x;
					}
					if ((specified & BoundsSpecified.Y) == BoundsSpecified.Y)
					{
						_bounds.Y = y;
					}
					if ((specified & BoundsSpecified.Width) == BoundsSpecified.Width)
					{
						_bounds.Width = width;
					}
					if ((specified & BoundsSpecified.Height) == BoundsSpecified.Height)
					{
						_bounds.Height = height;
					}
				}

				public void Collect(CollectCommand collector)
				{
					collector(_control, delegate(LayoutManager manager)
					{
						manager.SetBounds(_control, _bounds.X, _bounds.Y, _bounds.Width, _bounds.Height, delegate
						{
							if (_control is ControlBase controlBase)
							{
								controlBase.UpdateBounds(_bounds);
							}
							else
							{
								_control.Bounds = _bounds;
							}
						});
					});
				}
			}

			private interface ControlBounds
			{
				void Update(int x, int y, int width, int height, BoundsSpecified specified);

				void Collect(CollectCommand collector);
			}

			private List<WaitingCommand> _waiting = new List<WaitingCommand>();

			private List<Action> _updateCommands = new List<Action>();

			private Dictionary<Control, ControlBounds> _controlBounds = new Dictionary<Control, ControlBounds>();

			public void SetVisible(Control control, bool visible)
			{
				control.Visible = visible;
			}

			public void SetBounds(Control control, int x, int y, int width, int height, Action doDefault)
			{
				_waiting.Add(delegate(CollectCommand collect)
				{
					collect(control, delegate(LayoutManager manager)
					{
						manager.SetBounds(control, x, y, width, height, doDefault);
					});
				});
			}

			public void SetBounds(Control control, int x, int y, int width, int height, BoundsSpecified specified, Action doDefault)
			{
				if (!_controlBounds.TryGetValue(control, out var value))
				{
					value = new ControlBoundsClass(control);
					_controlBounds.Add(control, value);
				}
				value.Update(x, y, width, height, specified);
			}

			public void DoUpdate(ControlBase controlBase)
			{
				_updateCommands.Add(controlBase.DoUpdate);
			}

			public void Commit()
			{
				Dictionary<Control, List<LayoutCommand>> _commands = new Dictionary<Control, List<LayoutCommand>>();
				CollectCommand collectCommand = delegate(Control theControl, LayoutCommand command)
				{
					if (!theControl.IsDisposed)
					{
						Control key = theControl.Parent ?? theControl;
						if (!_commands.TryGetValue(key, out var value))
						{
							value = new List<LayoutCommand>();
							_commands.Add(key, value);
						}
						value.Add(command);
					}
				};
				foreach (WaitingCommand item in _waiting)
				{
					item(collectCommand);
				}
				foreach (KeyValuePair<Control, ControlBounds> controlBound in _controlBounds)
				{
					controlBound.Value.Collect(collectCommand);
				}
				foreach (KeyValuePair<Control, List<LayoutCommand>> pair in _commands)
				{
					pair.Key.SuspendLayout();
					new LayoutTransaction().RunWithin(delegate(LayoutManager manager)
					{
						foreach (LayoutCommand item2 in pair.Value)
						{
							item2(manager);
						}
					}, pair.Value.Count);
					pair.Key.ResumeLayout(performLayout: true);
				}
				_updateCommands.ForEach(delegate(Action action)
				{
					action();
				});
			}
		}

		private class EqualityComparer : IEqualityComparer<IComparable>
		{
			public bool Equals(IComparable x, IComparable y)
			{
				return x.CompareTo(y) == 0;
			}

			public int GetHashCode(IComparable obj)
			{
				return obj.GetHashCode();
			}
		}

		private bool _isSuspended;

		private CallStackClass _parent;

		private Queue<myAction> _commandsForResume = new Queue<myAction>();

		private Queue<myAction> _commandsForAfterResume = new Queue<myAction>();

		private LayoutManager _layout;

		private bool _runningCommandsForAfterResume;

		private static Action _beforeResume = delegate
		{
		};

		private Dictionary<IComparable, Action> _suspendedCommandsWithId = new Dictionary<IComparable, Action>(new EqualityComparer());

		public bool isSuspended => _isSuspended;

		public LayoutManager Layout => _layout ?? DummyLayoutManager.Instance;

		public SuspendManagerClass(CallStackClass parent)
		{
			_parent = parent;
		}

		public void AddCommandForResume(Action command)
		{
			AddCommandForResume(command, () => true, ignoreInForcePaint: false);
		}

		private bool CheckSuspended(Action andRunThisIfNot)
		{
			if (_isSuspended)
			{
				return true;
			}
			_parent._mainThread.InvokeOnUIThread(andRunThisIfNot, Context.Current.CallStack);
			return false;
		}

		public void AddCommandForResume(Action command, SuspendedCommandStillValid commandStillValid, bool ignoreInForcePaint)
		{
			if (!CheckSuspended(command))
			{
				return;
			}
			_commandsForResume.Enqueue(new myAction(delegate
			{
				if (commandStillValid())
				{
					command();
				}
			})
			{
				IgnoreInForcePaint = ignoreInForcePaint,
				StillValid = commandStillValid
			});
		}

		public void Suspend()
		{
			_isSuspended = true;
		}

		public void Resume()
		{
			Resume(forForcePaint: false);
		}

		public void Resume(bool forForcePaint)
		{
			_parent.InvokeInUIThread(delegate
			{
				_beforeResume();
				if (_isSuspended)
				{
					_isSuspended = false;
					DeferredLayoutManager deferredLayoutManager = new DeferredLayoutManager();
					_layout = deferredLayoutManager;
					List<myAction> list = new List<myAction>();
					List<myAction> list2 = new List<myAction>();
					try
					{
						try
						{
							while (_commandsForResume.Count > 0)
							{
								myAction myAction2 = _commandsForResume.Dequeue();
								if (forForcePaint && myAction2.IgnoreInForcePaint)
								{
									if (myAction2.StillValid())
									{
										list.Add(myAction2);
									}
								}
								else
								{
									myAction2.Action();
								}
							}
							_commandsForResume = new Queue<myAction>(1024);
						}
						finally
						{
							_layout = null;
							deferredLayoutManager.Commit();
						}
						_runningCommandsForAfterResume = true;
						try
						{
							while (_commandsForAfterResume.Count > 0)
							{
								myAction myAction3 = _commandsForAfterResume.Dequeue();
								if (forForcePaint && myAction3.IgnoreInForcePaint)
								{
									if (myAction3.StillValid())
									{
										list2.Add(myAction3);
									}
								}
								else
								{
									myAction3.Action();
								}
							}
						}
						finally
						{
							_runningCommandsForAfterResume = false;
						}
						_commandsForResume = new Queue<myAction>(1024);
					}
					finally
					{
						list.ForEach(delegate(myAction action)
						{
							_commandsForResume.Enqueue(action);
						});
						list2.ForEach(delegate(myAction action)
						{
							_commandsForAfterResume.Enqueue(action);
						});
					}
				}
			});
			_parent.RunIfFocused(delegate
			{
				Command.ForEach(delegate(Command command)
				{
					command.OnUIFlushed();
				});
			});
			_parent.OnResume();
		}

		public void AssertOnResumeIfOver10Commands(Action whileRunningThis)
		{
			_beforeResume = delegate
			{
				if (_commandsForResume.Count > 10)
				{
					throw new Exception("Too many commands for resume");
				}
			};
			try
			{
				whileRunningThis();
			}
			finally
			{
				_beforeResume = delegate
				{
				};
			}
		}

		public void AddCommandForAfterResume(Action command)
		{
			AddCommandForAfterResume(command, ignoreInForcePaint: false);
		}

		public void AddCommandForAfterResume(Action command, bool ignoreInForcePaint)
		{
			if (!_runningCommandsForAfterResume)
			{
				_commandsForAfterResume.Enqueue(new myAction(command)
				{
					IgnoreInForcePaint = ignoreInForcePaint
				});
			}
			else
			{
				_parent._mainThread.InvokeOnUIThread(command, Context.Current.CallStack);
			}
		}

		public void AddSuspendedCommandWithId(IComparable id, Action action, SuspendedCommandStillValid suspendedCommandValid)
		{
			AddSuspendedCommandWithId(id, action, suspendedCommandValid, ignoreInForcePaint: false);
		}

		public void AddSuspendedCommandWithId(IComparable id, Action action, SuspendedCommandStillValid suspendedCommandValid, bool ignoreInForcePaint)
		{
			if (!CheckSuspended(action))
			{
				return;
			}
			_commandsForResume.Enqueue(new myAction(delegate
			{
				if (_suspendedCommandsWithId.ContainsKey(id) && _suspendedCommandsWithId[id] == action)
				{
					if (suspendedCommandValid())
					{
						action();
					}
					_suspendedCommandsWithId.Remove(id);
				}
			})
			{
				IgnoreInForcePaint = ignoreInForcePaint,
				StillValid = delegate
				{
					if (_suspendedCommandsWithId.ContainsKey(id) && _suspendedCommandsWithId[id] == action)
					{
						if (suspendedCommandValid())
						{
							return true;
						}
						_suspendedCommandsWithId.Remove(id);
					}
					return false;
				}
			});
			_suspendedCommandsWithId[id] = action;
		}

		public void AddSuspendedCommandWithId(IComparable id, Action action)
		{
			AddSuspendedCommandWithId(id, action, () => true);
		}

		public void WithdrawSuspendedCommand(IComparable commandId)
		{
			_suspendedCommandsWithId.Remove(commandId);
		}

		public void Flush(bool whileBusy)
		{
			Resume(whileBusy);
			Suspend();
		}

		public void AssertLessThan(int thisManySuspendedCommands)
		{
			Should.BeLessThan(_commandsForResume.Count + _commandsForAfterResume.Count, thisManySuspendedCommands);
		}
	}

	private ITaskInCallStack _currentTask;

	private ITaskInCallStack _runningTask;

	private readonly List<ModuleController> _loadedModules = new List<ModuleController>();

	private bool _inFloatingState;

	private MainThread _mainThread;

	private bool _isUIThread = true;

	private Context _owner;

	private ContextTreeNode _rootContextTreeNode;

	private ContextTreeNode _currentContextTreeNode;

	private bool _preventRecursiveReturnFocusToActiveForm;

	private bool _blockTextBoxCursorCommands;

	private static List<CallStackClass> _contextsZOrder = new List<CallStackClass>();

	private static CallStackClass _focusedContext;

	private ITaskInCallStack _lastActiveTask;

	private myEventQueue _eventQue;

	private WindowsMessageLoop.MessageLoop _messageLoop;

	private Stack<Stack<Task>> _eventsCallStackStack = new Stack<Stack<Task>>();

	private SuspendManager _uiCommands;

	private List<Task> _globalHandlers = new List<Task>();

	private List<Task> _globalHandlersOfCustomCommands = new List<Task>();

	private string _currentHandledKey;

	private Exception _uiException;

	private CallStackClass _mainContext;

	private object _ownedContextsSync = new object();

	private List<CallStackClass> _ownedContexts = new List<CallStackClass>();

	public TaskCollection Tasks => new TaskCollection(_currentTask);

	public TaskCollection RunningTasks => new TaskCollection(_runningTask);

	public bool InTransaction => _currentTask.InTransaction;

	public bool CommandsPending => _eventQue.Count > 0;

	private Stack<Task> _eventsCallStack => _eventsCallStackStack.Peek();

	internal SuspendManager UICommands => _uiCommands;

	internal void RunExpressionCommands()
	{
		_currentTask.ProcessTimerAndExpressionEvents(forceEvents: true);
	}

	internal void CloseAllTasks()
	{
		DoExitApplication(delegate
		{
		});
	}

	internal bool IsMdiContainer(System.Windows.Forms.Form f)
	{
		return _mainThread.IsMdiContainer(f);
	}

	internal void DoOnParentEventManagers(Action<ParentEventManagers> doThis)
	{
		doThis(new myParentEventManagers(_eventsCallStack));
	}

	internal void DiscardPendingCommandsIfOnUIThread(HostEnvironment host)
	{
		if (_isUIThread)
		{
			host.ClearEvents();
		}
	}

	private void DoExitApplication(Action andDo)
	{
		_currentTask.Close(delegate
		{
			_eventQue.EnqueueNavigationCommand(delegate
			{
				_currentTask.DoExitApplication(andDo);
			});
		});
	}

	internal void RunMDIForTests(System.Windows.Forms.Form mdi, Action runMe)
	{
		_mainThread.RunMDIForTests(mdi, runMe);
	}

	internal void RunAsMDI(System.Windows.Forms.Form mdi, Action what)
	{
		if (!_isUIThread)
		{
			what();
			return;
		}
		_mainThread.RunAsMDI(mdi, delegate
		{
			what();
			WaitForOwnedContexts();
		});
		HandleUIException();
	}

	private void WaitForOwnedContexts()
	{
		while (_ownedContexts.Count > 0)
		{
			Suspend(1000, delayWindowActivation: false);
		}
	}

	void HostEnvironment.WaitForOwnedContexts(Action andDo)
	{
		WaitForOwnedContexts();
		andDo();
	}

	public static CallStackClass Create(Context owner)
	{
		return new CallStackClass(owner);
	}

	private CallStackClass(Context owner)
	{
		_owner = owner;
		_eventQue = new myEventQueue(delegate
		{
			_currentHandledKey = "";
		});
		_currentTask = new NullTaskInCallStack(this);
		_runningTask = _currentTask;
		_rootContextTreeNode = new ContextTreeNode(new DummyHostedItem(), this, null);
		_currentContextTreeNode = _rootContextTreeNode;
		_eventsCallStackStack.Push(new Stack<Task>());
		_mainThread = new MainThread(this);
		_messageLoop = _mainThread.GetMessageLoopFor(this);
		try
		{
			new AspNetHostingPermission(AspNetHostingPermissionLevel.High).Demand();
			SetupApplicationEvents();
		}
		catch
		{
		}
	}

	private void SetupApplicationEvents()
	{
		Application.ThreadException += ApplicationOnThreadException;
		Application.EnterThreadModal += EnterThreadModal;
	}

	private void ApplicationOnThreadException(object sender, ThreadExceptionEventArgs threadExceptionEventArgs)
	{
		_uiException = threadExceptionEventArgs.Exception;
	}

	private static void EnterThreadModal(object sender, EventArgs e)
	{
		Context.Current.UICommands.Flush(whileBusy: true);
	}

	public void OnResume()
	{
		if (_lastActiveTask != _currentTask)
		{
			if (_lastActiveTask != null)
			{
				_lastActiveTask.Deactivated();
			}
			if (_currentTask != null)
			{
				_currentTask.Activate();
			}
			_lastActiveTask = _currentTask;
		}
	}

	private void RunTask(HostedItem task, bool isApplication, RunTask commandToExecute)
	{
		ITaskInCallStack currentTask = _currentTask;
		ITaskInCallStack runningTask = _runningTask;
		ContextTreeNode oldNode = _currentContextTreeNode;
		TaskInCallStack result = new TaskInCallStack(task, isApplication, currentTask, runningTask, this, new myParentEventManagers(_eventsCallStack));
		result.AddToContextTreeNode(delegate
		{
			_currentContextTreeNode = _currentContextTreeNode.AddChild(task);
		});
		ContextTreeNode ctn = _currentContextTreeNode;
		Action<bool> action = delegate
		{
			_currentTask = result;
			_currentContextTreeNode = ctn;
		};
		result.RunThisToSetYourselfAsTheCurrentContext(action);
		result.RunThisToSetYourselfAsTheCurrentParentViewContext(delegate
		{
			_currentContextTreeNode = ctn;
		});
		runningTask.RestoreCommandsEnabledState();
		action(obj: false);
		_runningTask = result;
		try
		{
			TaskRunContext context;
			if (!_isUIThread)
			{
				TaskRunContext taskRunContext = new TaskRunContextNoUIWrapper(result);
				context = taskRunContext;
			}
			else
			{
				TaskRunContext taskRunContext = result;
				context = taskRunContext;
			}
			commandToExecute(context);
			if (currentTask == null && InTransaction)
			{
				throw new Error.DidNotAnticipateThis();
			}
		}
		catch (Exception)
		{
			_uiException = null;
			throw;
		}
		finally
		{
			_runningTask = runningTask;
			_currentTask.RemoveFromContextTree(delegate(bool onlyIfHasNoChildItems)
			{
				if (!onlyIfHasNoChildItems || _currentContextTreeNode.HasNoChildItems())
				{
					oldNode.RemoveChild(_currentContextTreeNode);
				}
			});
			_currentContextTreeNode = oldNode;
			if (_currentTask != result)
			{
				throw new Error.DidNotAnticipateThis();
			}
			_currentTask.RestoreCommandsEnabledState();
			runningTask.SetCommandsEnabledState();
			currentTask.MakeYourselfTheCurrentContext(forContextUser: false, task.KeepQueuedCommandsEvenIfCallStackCollapsed());
		}
	}

	private void ExitContext()
	{
		CancelEventArgs e = new CancelEventArgs();
		Context.Current.InvokeBeforeExit(e);
		if (!e.Cancel)
		{
			DoExitApplication(delegate
			{
			});
		}
	}

	private void RunIfFocused(Action activate)
	{
		if (_contextsZOrder.Count == 0 || _contextsZOrder[0] == this)
		{
			activate();
		}
	}

	private void RequestReactivation(XPARuntimeCore.Box.UI.Form form, Action reactivate)
	{
		_mainThread.RequestReactivation(form, reactivate);
	}

	private void ReturnFocusToActiveForm()
	{
		if (_preventRecursiveReturnFocusToActiveForm)
		{
			return;
		}
		_preventRecursiveReturnFocusToActiveForm = true;
		try
		{
			_currentTask.ActivateForm(delegate
			{
			});
		}
		finally
		{
			_preventRecursiveReturnFocusToActiveForm = false;
		}
	}

	void HostEnvironment.ExecuteTask(HostedItem task, ModuleController module, RunTask cmd)
	{
		RunActionWithModuleController(module, delegate
		{
			RunTask(task, isApplication: false, cmd);
		});
	}

	void HostEnvironment.ExecuteApplication(HostedItem task, ModuleController applic, RunTask commandToExecute)
	{
		if (_loadedModules.Contains(applic))
		{
			throw new Error.DidNotAnticipateThis();
		}
		_loadedModules.Add(applic);
		try
		{
			RunTask(task, isApplication: true, commandToExecute);
		}
		finally
		{
			if (_loadedModules[_loadedModules.Count - 1] != applic)
			{
				throw new Error.DidNotAnticipateThis();
			}
			_loadedModules.RemoveAt(_loadedModules.Count - 1);
		}
	}

	void HostEnvironment.Enqueue(EventDelegate thisEvent)
	{
		Enqueue(thisEvent);
	}

	public bool ShouldKeyBeProcessed(Control activeControl)
	{
		return _mainThread.ShouldKeyBeProcessed(activeControl);
	}

	internal void Enqueue(EventDelegate thisEvent)
	{
		_eventQue.Enqueue(thisEvent);
	}

	internal void ProcessEvents(Func<bool> stopProcessing)
	{
		bool happened = false;
		while (_eventQue.Count != 0)
		{
			bool stop = true;
			if (!_eventQue.HasNavigationCommands)
			{
				_currentTask.NavigationIdle();
			}
			_currentTask.ExecuteEvent(delegate(EventHandler eventHandler)
			{
				happened = true;
				_eventQue.Dequeue()(eventHandler);
				stop = false;
			});
			if (stop || stopProcessing())
			{
				return;
			}
		}
		_blockTextBoxCursorCommands = false;
		_currentTask.NavigationIdle();
		_currentTask.EventProcessingCompleted();
		if (!happened)
		{
			_currentTask.ProcessTimerAndExpressionEvents(forceEvents: false);
		}
	}

	private void ProcessSingleEvent(EventHandlerWrapperForProcessSingleEvent wrapper)
	{
		if (_eventQue.Count <= 0)
		{
			return;
		}
		_currentTask.ExecuteEvent(delegate(EventHandler eventHandler)
		{
			_eventQue.ProcessUnclearableCommands();
			if (_eventQue.Count != 0)
			{
				EventDelegate dequeuedAction = _eventQue.Dequeue();
				dequeuedAction(wrapper(eventHandler, delegate
				{
					_eventQue.EnqueueAtBottom(dequeuedAction);
				}));
			}
		});
	}

	private void PrivateCloseAllTasksAndRun(Action run, EventHandler eventHandler)
	{
		_currentTask.CloseDueToCloseAllTasksAndRun(run, eventHandler);
	}

	public void CloseAllTasksAndRun(Action run)
	{
		PrivateCloseAllTasksAndRun(run, new NullEventHandler());
	}

	public static void RegisterMockMessageLoopCommand(DispatchMessage command)
	{
		Context.Current.CallStack.PrivateRegisterMockMessageLoopCommand(command);
	}

	public void RegisterMockMessageLoopCommand(DispatchMessage command, object context)
	{
		_mainThread.RegisterMockMessageLoopCommand(command, context);
	}

	private void PrivateRegisterMockMessageLoopCommand(DispatchMessage command)
	{
		_mainThread.RegisterMockMessageLoopCommand(command, this);
	}

	private void DispatchMssage(WindowsMessageLoop.Message message, WindowsMessageLoop.MessageHandler handler)
	{
		message.DispatchMessage(new myMessageHandlingWrapper(handler), _mainThread.InvokeOnUIThread);
	}

	public Keys Suspend(int milliseconds, bool delayWindowActivation)
	{
		_currentHandledKey = "";
		XPARuntimeCore.Box.Engine.Timer timer = new TimerClass(milliseconds);
		Context.Current.UICommands.Resume(delayWindowActivation);
		bool cancelDelay = false;
		Keys result = Keys.None;
		_currentTask.SendMessageHandler(delegate(WindowsMessageLoop.MessageHandler messageHandler)
		{
			while (!timer.Elapsed() && !cancelDelay)
			{
				_messageLoop.ProcessNextMessage(delegate(WindowsMessageLoop.Message msg)
				{
					MessageHandlerForSuspend messageHandlerForSuspend = new MessageHandlerForSuspend(messageHandler, _currentTask);
					int count = _eventQue.Count;
					DispatchMssage(msg, messageHandlerForSuspend);
					cancelDelay = messageHandlerForSuspend.UserHitKeyboad || _eventQue.Count > count;
					result = messageHandlerForSuspend.KeyHitByUser;
				}, timer.RemainingMilliseconds(), delegate
				{
				});
			}
		});
		Context.Current.UICommands.Suspend();
		return result;
	}

	int HostEnvironment.GetIdleSeconds()
	{
		return _eventQue.GetIdleSeconds();
	}

	public void SearchForHandlerThatRuns(object thisTask, InvokeCommand andRunThisWithTheAppropriateCommand)
	{
		_currentTask.SearchForHandlerThatRuns(thisTask, andRunThisWithTheAppropriateCommand);
	}

	public void PushEventManager(Task eventManager)
	{
		_eventsCallStack.Push(eventManager);
	}

	public Task PopEventManager()
	{
		return _eventsCallStack.Pop();
	}

	public void AddGlobalHandler(Task task)
	{
		if (_globalHandlers.Contains(task))
		{
			throw new Error.DidNotAnticipateThis();
		}
		_globalHandlers.Add(task);
		_globalHandlersOfCustomCommands.Add(task);
	}

	public void RemoveGlobalHandler(Task task)
	{
		_globalHandlersOfCustomCommands.Remove(task);
	}

	public IEnumerable GetGlobalHandlers()
	{
		return _globalHandlersOfCustomCommands;
	}

	void HostEnvironment.EnqueueAtBottom(EventDelegate thisEvent)
	{
		_eventQue.EnqueueAtBottom(thisEvent);
	}

	void HostEnvironment.BeginInvoke(Action action)
	{
		_eventQue.EnqueueUnclearableCommand(delegate
		{
			action();
		});
	}

	void HostEnvironment.HandleOnCurrentTask(Command command, ControlBase sender, object[] args, Action<CommandRaisingAndInvoking> handle)
	{
		_currentTask.HandleCommand(command, sender, args, handle);
	}

	public void SetCurrentHandledKey(string keyText)
	{
		_currentHandledKey = keyText;
	}

	public string GetCurrentHandledKey()
	{
		return _currentHandledKey;
	}

	public void ClearEvents()
	{
		_eventQue.Clear();
	}

	public void EnqueueNavigationCommand(EventDelegate ed)
	{
		_eventQue.EnqueueNavigationCommand(ed);
	}

	public void SendKeys(Keys keys)
	{
		_mainThread.SendKeys(keys);
	}

	internal void ResetEvents()
	{
		_eventsCallStack.Clear();
		_globalHandlers.Clear();
	}

	private void HandleUIException()
	{
		if (_uiException != null)
		{
			Exception uiException = _uiException;
			_uiException = null;
			if (!(uiException is RollbackException) && !(uiException is AbortAllTasksException) && !(uiException is AbortTaskException) && !(uiException is FlowAbortException))
			{
				throw new InUIException(uiException);
			}
			throw uiException;
		}
	}

	public void UserInputForTesting(Action action)
	{
		Func<bool> currentTaskCanHandleEvents = delegate
		{
			bool b = false;
			_currentTask.ExecuteEvent(delegate
			{
				b = true;
			});
			return b;
		};
		_currentTask.ForTestingOnlyWrapEventProcessing(delegate
		{
			action();
			do
			{
				HandleUIException();
				Context.Current.CallStack.ProcessEvents(() => false);
				if (currentTaskCanHandleEvents())
				{
					Context.Current.UICommands.Flush(whileBusy: false);
				}
			}
			while (currentTaskCanHandleEvents() && _eventQue.Count > 0);
		});
	}

	public T GetCachedTaskInstanceForCurrentContext<T>(Func<T> create, Func<T, Task> getTask, object uniqueIdentifier, object groupIdentifier, bool forKeepViewVisibleAfterExitOnly)
	{
		return _currentContextTreeNode.GetCachedTaskInstance(create, getTask, uniqueIdentifier, groupIdentifier, forKeepViewVisibleAfterExitOnly);
	}

	public void SetNonUIThread()
	{
		_isUIThread = false;
	}

	public FormForTask GetFormForTask(FormForTask form)
	{
		return _mainThread.GetFormForTask(form, this);
	}

	public void Dispose()
	{
		while (_eventQue.Count != 0)
		{
			_eventQue.Dequeue()(new ContainerEventHandler());
		}
		Application.ThreadException -= ApplicationOnThreadException;
		Application.EnterThreadModal -= EnterThreadModal;
		_mainThread.RemoveContext(this);
		if (_mainContext != null)
		{
			lock (_mainContext._ownedContextsSync)
			{
				_mainContext._ownedContexts.Remove(this);
			}
		}
		_contextsZOrder.Remove(this);
	}

	internal void DisableSuspendingOfUICommandsForTests()
	{
		_uiCommands = DummySuspendManager.Instance;
	}

	internal void ResetUICommandsForTests()
	{
		_uiCommands = new SuspendManagerClass(this);
	}

	private void InvokeInUIThread(Action command)
	{
		_mainThread.InvokeOnUIThread(command, this);
	}

	private void InvokeOnLogicThread(Action action)
	{
		if (Context.Current.CallStack == this)
		{
			action();
		}
		else
		{
			_mainThread.InvokeOnLogicThread(action, this);
		}
	}

	public void AttachToUIContext(CallStackClass callStack)
	{
		callStack._mainThread.AddContext(this);
		_mainThread = callStack._mainThread;
		_messageLoop = _mainThread.GetMessageLoopFor(this);
		if (_mainContext != null)
		{
			lock (_mainContext._ownedContextsSync)
			{
				_mainContext._ownedContexts.Remove(this);
			}
		}
		_mainContext = callStack;
		lock (callStack._ownedContextsSync)
		{
			callStack._ownedContexts.Add(this);
		}
	}

	public void DetachFromUIContext()
	{
		_mainThread.RemoveContext(this);
		_mainThread = new MainThread(this);
		_messageLoop = _mainThread.GetMessageLoopFor(this);
		if (_mainContext != null)
		{
			CallStackClass mainContext = _mainContext;
			while (mainContext._mainContext != null)
			{
				mainContext = mainContext._mainContext;
			}
			lock (mainContext._ownedContextsSync)
			{
				mainContext._ownedContexts.Add(this);
			}
			lock (_mainContext._ownedContextsSync)
			{
				_mainContext._ownedContexts.Remove(this);
			}
			_mainContext = mainContext;
		}
	}

	public void InvokeUICommand(Action command)
	{
		InvokeInUIThread(command);
	}

	public void RunActionWithModuleController(ModuleController moduleController, Action action)
	{
		if (moduleController != null && !_loadedModules.Contains(moduleController))
		{
			moduleController.ActivateAsAComponentOfAnApplication(action);
			return;
		}
		if (moduleController != null && !_eventsCallStack.Contains(moduleController.GetTask()))
		{
			_eventsCallStack.Push(moduleController.GetTask());
			try
			{
				action();
				return;
			}
			finally
			{
				_eventsCallStack.Pop();
			}
		}
		action();
	}

	public void BeginInvoke(EventDelegate e)
	{
		_eventQue.EnqueueUnclearableCommand(e);
	}

	public void BeginInvokeDelayed(Action action)
	{
		_eventQue.EnqueueDelayedUnclearableCommand(action);
	}
}
