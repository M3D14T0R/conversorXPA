using System;
using XPARuntimeCore.Box.Engine;

namespace WizardOfOz.Witch.DataAccess;

internal class TransactionStartStrategyTrue : TransactionStartStrategy
{
	public void ApplyLockingStrategy(Action yes)
	{
		yes();
	}

	public void CheckThatLockingIsInATransaction(Action yes)
	{
		yes();
	}

	public void StartTransaction(TaskRunContext context, bool checkLocking, Action yes)
	{
		yes();
	}
}
