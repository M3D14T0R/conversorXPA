using System;
using XPARuntimeCore.Box.Advanced;
using XPARuntimeCore.Box.Flow;
using WizardOfOz.Witch.UI;

namespace WizardOfOz.Witch.Engine;

internal interface ControlForFlow
{
	bool CheckEnabled();

	void DoValidating();

	void ActivateTemplateMode(Action selectionSucceeded);

	bool AreYou(IControl thisControl);

	void ExitEditing();

	void SaveYourDataAndDo(Action what, Action gotoNextControl);

	void Activate(FlowMode mode, Direction direction, bool requiresTabStop, bool noData, Action duplicateIndexCheck, Action activationSucceeded, Action<Action> runInputValidation, Action<Action, FlowActionVisitor> runInFlowContext);

	void Leave(bool stopOnInvalidInput, bool forceInputValidation, bool performControlLeave, bool forceDuplicateIndexCheck, Action performDupIndexCheckAndThrowExceptionIfFailed, Action andDo);

	bool LeaveColumnWithFlowBackwardInExpand();

	bool CanYouExpandBefore();

	bool CanYouExpandAfter();

	bool IsEditable();
}
