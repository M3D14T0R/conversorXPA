using System;
using System.Windows.Forms;
using XPARuntimeCore.Box;
using XPARuntimeCore.Box.UI.Advanced;
using WizardOfOz.Witch.UI;

namespace WizardOfOz.Witch.Engine;

internal class EventHandlerForRunningCommandsBeforeACustomCommandWithPrecondition : EventHandler
{
	private EventHandler _eventHandler;

	public EventHandlerForRunningCommandsBeforeACustomCommandWithPrecondition(EventHandler eventHandler)
	{
		_eventHandler = eventHandler;
	}

	public void Handle(Command command, CommandInvokationStuff stuff, Action defaultAction)
	{
		if (command == Command.Expand)
		{
			_eventHandler.ExpandParkedColumn();
		}
	}

	public void UserAskedToPutString(string text, Action defaultAction)
	{
	}

	public void DoUserActionByName(string actionName)
	{
	}

	public void CheckKeyContext(KeyContextResult result)
	{
	}

	public void Invoke(ListenerRunner runner)
	{
	}

	public void ProcessNavigationCommand(Action cmd, Func<bool> abortCommand)
	{
	}

	public void RunCustomCommand(CustomCommandPrecondition precondition, Action action, Action<Action<Action>> runBeforeLeavingControl)
	{
	}

	public bool ParkedControlIs(ControlBase controlBase)
	{
		return false;
	}

	public void WrapInvokingFromQueue(Command command, Func<IControl, IControl> controlBase, bool doNotRepeatInMultiSelect, Action<IControl> invoke, Action raiseAgain)
	{
	}

	public void ProcessUnhandledCommand(Command c, Action doDefault)
	{
	}

	public void SendKeys(Keys keys)
	{
	}

	public void GoTo(Func<IControl, IControl> control, Command commandToInvokeBefore, Action gotoAction)
	{
	}

	public void ExpandParkedColumn()
	{
	}
}
