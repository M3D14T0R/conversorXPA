using System.Collections.Generic;
using XPARuntimeCore.Box.Data.Advanced;

namespace WizardOfOz.Witch.DataAccess;

internal delegate void ProvideStructuralDataConsumer(IEnumerable<ColumnBase> allColumns, IEnumerable<ColumnBase> primaryKeyColumns);
