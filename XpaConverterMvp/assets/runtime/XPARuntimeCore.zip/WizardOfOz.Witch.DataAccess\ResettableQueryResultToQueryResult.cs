using System;

namespace WizardOfOz.Witch.DataAccess;

internal class ResettableQueryResultToQueryResult : QueryResult, IDisposable
{
	private ResetableQueryResult _x;

	public DataProviderRow Current => _x.Current;

	public ResettableQueryResultToQueryResult(ResetableQueryResult x)
	{
		_x = x;
	}

	public void Dispose()
	{
		_x.Dispose();
	}

	public bool MoveNext()
	{
		return _x.MoveNext();
	}
}
