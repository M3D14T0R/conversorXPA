using System;
using System.Collections.Generic;
using XPARuntimeCore.Box;
using XPARuntimeCore.Box.Advanced;
using XPARuntimeCore.Box.Data;
using XPARuntimeCore.Box.Data.Advanced;
using XPARuntimeCore.Box.Data.DataProvider;

namespace WizardOfOz.Witch.DataAccess;

internal class QueryClass : Query, LookupQuery, QueryResultProvider
{
	private class myIdentifier : IdentifierProvider
	{
		private QueryClass _parent;

		public myIdentifier(QueryClass parent)
		{
			_parent = parent;
		}

		public bool Contains(ColumnBase column)
		{
			return _parent._sources.Contains(column);
		}
	}

	private class MainTableSource : QuerySource
	{
		public MainTableSource(Entity table, IEnumerable<ColumnBase> selectedColumns, QueryClass parent)
			: base(selectedColumns, parent, table)
		{
		}

		protected override void NotifiyLookupedRows(InnerRow row, bool isNewRow)
		{
		}
	}

	private class InnerJoinQuerySource : QuerySource
	{
		protected FilterCondition _filter;

		private LookupInAQuery _lookupInQuery;

		protected IdentifierProvider _identifier;

		public override IFilter Where => new FilterConditionBridgeToIFilter(_filter, _identifier, supportWildCard: true);

		public override bool IsOuterJoin => false;

		public InnerJoinQuerySource(Entity table, IEnumerable<ColumnBase> selectedColumns, FilterCondition filter, LookupInAQuery lookupInAQuery, QueryClass parent)
			: base(selectedColumns, parent, table)
		{
			_filter = filter;
			_lookupInQuery = lookupInAQuery;
			_identifier = parent._myIdentifier;
			_useIndex = false;
		}

		protected override void NotifiyLookupedRows(InnerRow row, bool isNewRow)
		{
			_lookupInQuery.SetCurrentRow(isNewRow ? null : row, delegate(DataProviderRow r)
			{
				if (r != row && !r.IsNewRow())
				{
					row.SetDataProviderRow(r);
				}
			});
		}

		public override myRow Populate(InnerRowHelper x, IRowsReader provider)
		{
			return new InnerRow(this, (IRowStorage r) => provider.GetJoinedRow(_entityInDb, r), x);
		}
	}

	private class OuterJoinQuerySource : InnerJoinQuerySource
	{
		public override bool IsOuterJoin => true;

		public OuterJoinQuerySource(Entity table, IEnumerable<ColumnBase> selectedColumns, FilterCondition filter, LookupInAQuery lookupInAQuery, QueryClass parent)
			: base(table, selectedColumns, filter, lookupInAQuery, parent)
		{
		}
	}

	private interface IQuerySource
	{
		bool Contains(ColumnBase column);

		IQuerySource Add(IQuerySource item);

		myRow Populate(InnerRowHelper myRow, IRowsReader provider);

		myRow PopulateNewRow(InnerRowHelper newRow);

		bool AddColumnIfItFits(ColumnBase column);
	}

	private class JoniedQuerySource : IQuerySource
	{
		private List<IQuerySource> _sources = new List<IQuerySource>();

		public bool Contains(ColumnBase column)
		{
			foreach (IQuerySource source in _sources)
			{
				if (source.Contains(column))
				{
					return true;
				}
			}
			return false;
		}

		public IQuerySource Add(IQuerySource item)
		{
			_sources.Add(item);
			return this;
		}

		public myRow Populate(InnerRowHelper x, IRowsReader provider)
		{
			JoinedRowsBundle joinedRowsBundle = new JoinedRowsBundle();
			foreach (IQuerySource source in _sources)
			{
				joinedRowsBundle.AddInnerRow(source.Populate(joinedRowsBundle, provider));
			}
			return joinedRowsBundle;
		}

		public myRow PopulateNewRow(InnerRowHelper newRow)
		{
			JoinedRowsBundle joinedRowsBundle = new JoinedRowsBundle();
			foreach (IQuerySource source in _sources)
			{
				joinedRowsBundle.AddInnerRow(source.PopulateNewRow(joinedRowsBundle));
			}
			return joinedRowsBundle;
		}

		public bool AddColumnIfItFits(ColumnBase column)
		{
			foreach (IQuerySource source in _sources)
			{
				if (source.AddColumnIfItFits(column))
				{
					return true;
				}
			}
			return false;
		}
	}

	private abstract class QuerySource : IQuerySource, IJoin
	{
		public class InnerRow : IRowStorage, myRow, DataProviderRow
		{
			private interface RowStrategy
			{
				void SetColumnsAcordingToYourValue();

				void UpdateDatabaseAcordingToValues();

				void DoUpdateOrInsertSavingRow();

				void Delete();

				void DoDeleteOnSavingRow();

				void Lock(Action callIfRowDoesNotExist, bool checkForValueChange);

				bool IsNewRow();

				void ReloadRowData(Action callIfRowDoesNotExist);

				void SetValue(ColumnBase column, IValueLoader loader);

				void Unlock();

				void ReloadRowDataAndIgnoreExceptions();

				void LockAndIgnoreExceptions();

				ColumnDataInRow GetValueOf(ColumnBase column);
			}

			private class ExistingRowStrategy : RowStrategy
			{
				private class OnSavingRowUpdateHelper : UpdateHelper
				{
					public bool result;

					public void AddChangedColumn(ColumnBase column)
					{
						result = true;
					}

					public void AddValueToSetToOriginalAfterSave(ColumnDataInRow data)
					{
					}
				}

				private class UpdateCommand : RunMonitoredCommand, UpdateHelper
				{
					private readonly ExistingRowStrategy _parent;

					private readonly ColumnDataInRow[] _databaseValues;

					private readonly List<ColumnDataInRow> _valuesToSetToOriginalValue;

					private readonly ColumnsForUpdateOrInsertCollector _colsAndValues;

					public UpdateCommand(ExistingRowStrategy parent, ColumnDataInRow[] databaseValues)
					{
						_parent = parent;
						_databaseValues = databaseValues;
						_colsAndValues = new ColumnsForUpdateOrInsertCollector(databaseValues.Length);
						_valuesToSetToOriginalValue = new List<ColumnDataInRow>(databaseValues.Length);
					}

					public void Run()
					{
						_parent._row._source._entityInDb.AboutToUpdate();
						_colsAndValues.RunUpdate(_parent._row._providerRow, _parent._row._source._parent._useOptimisticConcurrency());
					}

					public void AddChangedColumn(ColumnBase column)
					{
						_colsAndValues.AddColumn(column);
					}

					public void AddValueToSetToOriginalAfterSave(ColumnDataInRow data)
					{
						_valuesToSetToOriginalValue.Add(data);
					}

					public void RunWith(MonitoredDatabaseRunner runner)
					{
						bool flag = false;
						foreach (ColumnBase column in _parent._row._source._columns)
						{
							if (column._valueIsDifferentThenOriginal())
							{
								flag = true;
								break;
							}
						}
						if (!flag)
						{
							return;
						}
						ColumnDataInRow[] databaseValues = _databaseValues;
						for (int i = 0; i < databaseValues.Length; i++)
						{
							databaseValues[i].IfYouWereUpdatedAddColumnsTo(this);
						}
						if (_colsAndValues.Count > 0)
						{
							runner.RunQuery(this, isUpdateOrInsert: true);
						}
						foreach (ColumnDataInRow item in _valuesToSetToOriginalValue)
						{
							item.SaveCurrentValuesAsOriginalValues();
						}
					}
				}

				private class DeleteCommand : RunMonitoredCommand
				{
					private ExistingRowStrategy _parent;

					public DeleteCommand(ExistingRowStrategy parent)
					{
						_parent = parent;
					}

					public void Run()
					{
						_parent._row._source._entityInDb.AboutToUpdate();
						_parent._row._providerRow.Delete(_parent._row._source._parent._useOptimisticConcurrency());
					}
				}

				private class myUpdateHelper : UpdateHelper
				{
					public bool WasChanged;

					public void AddChangedColumn(ColumnBase column)
					{
						WasChanged = true;
					}

					public void AddValueToSetToOriginalAfterSave(ColumnDataInRow data)
					{
					}
				}

				private class DummyRunMonitoredCommand : RunMonitoredCommand
				{
					public static DummyRunMonitoredCommand Instance = new DummyRunMonitoredCommand();

					public void Run()
					{
					}
				}

				private class LockCommand : RunMonitoredCommand
				{
					private ExistingRowStrategy _parent;

					private Action _callMeIfRowDoesNotExist;

					private Action _lockSucceeded;

					public LockCommand(ExistingRowStrategy parent, Action callIfRowDoesNotExist, Action lockSucceeded)
					{
						_parent = parent;
						_callMeIfRowDoesNotExist = callIfRowDoesNotExist;
						_lockSucceeded = lockSucceeded;
					}

					public void Run()
					{
						try
						{
							_parent._row._providerRow.Lock();
							_lockSucceeded();
						}
						catch (DatabaseErrorException ex)
						{
							if (ex.ErrorType == DatabaseErrorType.RowDoesNotExist)
							{
								_callMeIfRowDoesNotExist();
							}
							throw;
						}
					}
				}

				private class LockAndVerify : RunMonitoredCommand
				{
					private class myUpdateHelper : UpdateHelper
					{
						public bool WasChanged;

						public void AddChangedColumn(ColumnBase column)
						{
							WasChanged = true;
						}

						public void AddValueToSetToOriginalAfterSave(ColumnDataInRow data)
						{
						}
					}

					private ExistingRowStrategy _parent;

					private RunMonitoredCommand _lockCommand;

					private RunMonitoredCommand _unlockCommand;

					private bool _shouldUnlock;

					public LockAndVerify(ExistingRowStrategy parent, RunMonitoredCommand lockCommand, RunMonitoredCommand unLockCommand)
					{
						_parent = parent;
						_lockCommand = lockCommand;
						_unlockCommand = unLockCommand;
					}

					public void Run()
					{
						_shouldUnlock = false;
						ColumnDataInRow[] array = new ColumnDataInRow[_parent._databaseValues.Length];
						_parent._databaseValues.CopyTo(array, 0);
						_lockCommand.Run();
						bool flag = false;
						for (int i = 0; i < array.Length; i++)
						{
							if (!array[i].IsEqualTo(_parent._databaseValues[i]))
							{
								flag = true;
							}
						}
						if (!flag)
						{
							return;
						}
						RowWasChangedHelper rowWasChangedHelper = new RowWasChangedHelper();
						for (int j = 0; j < array.Length; j++)
						{
							array[j].AddInfoTo(rowWasChangedHelper, _parent._databaseValues[j]);
						}
						myUpdateHelper myUpdateHelper2 = new myUpdateHelper();
						ColumnDataInRow[] array2 = array;
						for (int k = 0; k < array2.Length; k++)
						{
							array2[k].IfYouWereUpdatedAddColumnsTo(myUpdateHelper2);
						}
						if (myUpdateHelper2.WasChanged)
						{
							_parent._databaseValues = array;
						}
						else
						{
							array2 = _parent._databaseValues;
							for (int k = 0; k < array2.Length; k++)
							{
								array2[k].SetColumnAcordingToYourValue(updateUI: true);
							}
						}
						_shouldUnlock = true;
						throw new DatabaseErrorException(DatabaseErrorType.RowWasChangedSinceLoaded, rowWasChangedHelper.CreateExcpetion(), DatabaseErrorHandlingStrategy.Rollback);
					}

					internal void Failed()
					{
						if (_shouldUnlock)
						{
							_unlockCommand.Run();
						}
					}
				}

				private class UnlockCommand : RunMonitoredCommand
				{
					private ExistingRowStrategy _parent;

					public UnlockCommand(ExistingRowStrategy parent)
					{
						_parent = parent;
					}

					public void Run()
					{
						_parent._row._providerRow.Unlock();
					}
				}

				private class LockAndIgnoreExceptionsCommand : RunMonitoredCommand
				{
					private IRow _row;

					public LockAndIgnoreExceptionsCommand(IRow row)
					{
						_row = row;
					}

					public void Run()
					{
						try
						{
							_row.Lock();
						}
						catch (DatabaseErrorException ex)
						{
							if (ex.ErrorType == DatabaseErrorType.LockedRow)
							{
								throw;
							}
						}
					}
				}

				private class ReloadRowDataCommand : RunMonitoredCommand
				{
					private ExistingRowStrategy _parent;

					private Action _callMeIfRowDoesNotExist;

					public ReloadRowDataCommand(ExistingRowStrategy parent, Action callMeIfRowDoesNotExist)
					{
						_parent = parent;
						_callMeIfRowDoesNotExist = callMeIfRowDoesNotExist;
					}

					public void Run()
					{
						try
						{
							_parent._row._providerRow.ReloadData();
						}
						catch (DatabaseErrorException ex)
						{
							if (ex.ErrorType == DatabaseErrorType.RowDoesNotExist)
							{
								_callMeIfRowDoesNotExist();
							}
							throw;
						}
					}
				}

				private InnerRow _row;

				private bool _wasLocked;

				private ColumnDataInRow[] _databaseValues;

				public ExistingRowStrategy(InnerRow row)
				{
					_row = row;
					_databaseValues = new ColumnDataInRow[row._source._columns.Count];
				}

				internal void LoadDataFromColumns()
				{
					if (_row._source._useIndex)
					{
						foreach (ColumnBase column in _row._source._columns)
						{
							_databaseValues[column._internalIndexInRow] = column.GetCurrentDataInRow();
						}
						return;
					}
					foreach (KeyValuePair<ColumnBase, int> columnIndex in _row._source._columnIndexes)
					{
						_databaseValues[columnIndex.Value] = columnIndex.Key.GetCurrentDataInRow();
					}
				}

				public void SetColumnsAcordingToYourValue()
				{
					_row._source.NotifiyLookupedRows(_row, isNewRow: false);
					ColumnDataInRow[] databaseValues = _databaseValues;
					for (int i = 0; i < databaseValues.Length; i++)
					{
						databaseValues[i].SetColumnAcordingToYourValue(updateUI: false);
					}
				}

				public override string ToString()
				{
					string text = "";
					ColumnDataInRow[] databaseValues = _databaseValues;
					for (int i = 0; i < databaseValues.Length; i++)
					{
						text = text + "," + databaseValues[i];
					}
					return text;
				}

				public void UpdateDatabaseAcordingToValues()
				{
					new UpdateCommand(this, _databaseValues).RunWith(_row._source._parent._runner);
				}

				public void DoUpdateOrInsertSavingRow()
				{
					OnSavingRowUpdateHelper onSavingRowUpdateHelper = new OnSavingRowUpdateHelper();
					ColumnDataInRow[] databaseValues = _databaseValues;
					for (int i = 0; i < databaseValues.Length; i++)
					{
						databaseValues[i].IfYouWereUpdatedAddColumnsTo(onSavingRowUpdateHelper);
						if (onSavingRowUpdateHelper.result)
						{
							break;
						}
					}
					if (onSavingRowUpdateHelper.result)
					{
						_row._source.Entity.DoOnSavingRow(new EntityOnSavingRowEventArgs(Activities.Update));
					}
				}

				public void Delete()
				{
					_row._source._parent._runner.RunQuery(new DeleteCommand(this), isUpdateOrInsert: false);
					_row._strategy = new DeletetRowStrategy(_databaseValues, _row._source);
				}

				public void Lock(Action callIfRowDoesNotExist, bool checkForValueChange)
				{
					bool locked = false;
					Action lockSucceeded = delegate
					{
						locked = true;
					};
					bool doLock = false;
					DBLock(delegate
					{
						doLock = true;
					});
					Action callIfRowDoesNotExistOnce = delegate
					{
					};
					callIfRowDoesNotExistOnce = delegate
					{
						callIfRowDoesNotExist();
						callIfRowDoesNotExistOnce = delegate
						{
						};
					};
					RunMonitoredCommand runMonitoredCommand2;
					if (!doLock)
					{
						RunMonitoredCommand runMonitoredCommand = new ReloadRowDataCommand(this, callIfRowDoesNotExistOnce);
						runMonitoredCommand2 = runMonitoredCommand;
					}
					else
					{
						RunMonitoredCommand runMonitoredCommand = new LockCommand(this, callIfRowDoesNotExistOnce, lockSucceeded);
						runMonitoredCommand2 = runMonitoredCommand;
					}
					RunMonitoredCommand runMonitoredCommand3 = runMonitoredCommand2;
					RunMonitoredCommand runMonitoredCommand4;
					if (!doLock)
					{
						RunMonitoredCommand runMonitoredCommand = DummyRunMonitoredCommand.Instance;
						runMonitoredCommand4 = runMonitoredCommand;
					}
					else
					{
						RunMonitoredCommand runMonitoredCommand = new UnlockCommand(this);
						runMonitoredCommand4 = runMonitoredCommand;
					}
					RunMonitoredCommand unLockCommand = runMonitoredCommand4;
					if (checkForValueChange)
					{
						runMonitoredCommand3 = new LockAndVerify(this, runMonitoredCommand3, unLockCommand);
					}
					if (doLock || (checkForValueChange && !_row._source._entityInDb.Cached))
					{
						try
						{
							_row._source._parent._runner.RunQuery(runMonitoredCommand3, isUpdateOrInsert: false);
						}
						catch
						{
							if (runMonitoredCommand3 is LockAndVerify lockAndVerify)
							{
								lockAndVerify.Failed();
							}
							throw;
						}
					}
					if (doLock && !locked)
					{
						callIfRowDoesNotExistOnce();
					}
				}

				private void DBLock(Action l)
				{
					_wasLocked = true;
					_row._source._entityInDb.Lock(l);
				}

				public bool IsNewRow()
				{
					return false;
				}

				public void ReloadRowData(Action callIfRowDoesNotExist)
				{
					if (_row._row.HasJoins())
					{
						FilterCollection filterCollection = new FilterCollection();
						for (int i = 0; i < _row._source._primaryKeyColumns.Length; i++)
						{
							ColumnBase columnBase = _row._source._primaryKeyColumns[i];
							if (_row._source._useIndex)
							{
								_databaseValues[columnBase._internalIndexInRow].AddEqualToColumn(columnBase, filterCollection);
							}
							else
							{
								_databaseValues[_row._source._columnIndexes[columnBase]].AddEqualToColumn(columnBase, filterCollection);
							}
						}
						using QueryResult queryResult = _row._source._parent.SelectWithoutOriginalFilter(filterCollection);
						if (queryResult.MoveNext())
						{
							_row._row.Refresh(queryResult.Current);
						}
						else
						{
							callIfRowDoesNotExist();
						}
						return;
					}
					_row._source._parent._runner.RunQuery(new ReloadRowDataCommand(this, callIfRowDoesNotExist), isUpdateOrInsert: false);
				}

				public void SetValue(ColumnBase column, IValueLoader loader)
				{
					int value;
					if (_row._source._useIndex)
					{
						if (column._internalIndexInRow >= 0 && loader != null && column.Entity == _row._source.Entity)
						{
							_databaseValues[column._internalIndexInRow] = column.GetDataInRowFrom(loader);
						}
					}
					else if (_row._source._columnIndexes.TryGetValue(column, out value))
					{
						_databaseValues[value] = column.GetDataInRowFrom(loader);
					}
				}

				public void Unlock()
				{
					if (_wasLocked)
					{
						_row._source._entityInDb.Lock(delegate
						{
							_row._source._parent._runner.RunQuery(new UnlockCommand(this), isUpdateOrInsert: false);
						});
					}
				}

				public void ReloadRowDataAndIgnoreExceptions()
				{
					try
					{
						_row._providerRow.ReloadData();
					}
					catch (DatabaseErrorException)
					{
					}
				}

				public void LockAndIgnoreExceptions()
				{
					DBLock(delegate
					{
						_row._source._parent._runner.RunQuery(new LockAndIgnoreExceptionsCommand(_row._providerRow), isUpdateOrInsert: false);
					});
				}

				public ColumnDataInRow GetValueOf(ColumnBase col)
				{
					int value;
					if (_row._source._useIndex)
					{
						if (col._internalIndexInRow >= 0 && col.Entity == _row._source.Entity && col._internalIndexInRow < _databaseValues.Length)
						{
							return _databaseValues[col._internalIndexInRow];
						}
					}
					else if (_row._source._columnIndexes.TryGetValue(col, out value))
					{
						return _databaseValues[value];
					}
					return null;
				}

				public void SetColumnAcordingToValue(ColumnBase column)
				{
					if (_row._source._useIndex)
					{
						_databaseValues[column._internalIndexInRow].SetColumnAcordingToYourValue(updateUI: false);
					}
					else
					{
						_databaseValues[_row._source._columnIndexes[column]].SetColumnAcordingToYourValue(updateUI: false);
					}
				}

				public void DoDeleteOnSavingRow()
				{
					_row._source.Entity.DoOnSavingRow(new EntityOnSavingRowEventArgs(Activities.Delete));
				}
			}

			private class NewRowStrategy : RowStrategy
			{
				private class InsertCommand : RunMonitoredCommand
				{
					private NewRowStrategy _parent;

					private Action _insertCommandSucceeded;

					public InsertCommand(NewRowStrategy parent, Action insertCommandSucceeded)
					{
						_parent = parent;
						_insertCommandSucceeded = insertCommandSucceeded;
					}

					public void Run()
					{
						_parent._row._source._entityInDb.AboutToUpdate();
						ColumnsForUpdateOrInsertCollector col = new ColumnsForUpdateOrInsertCollector(_parent._row._source._columns.Count);
						foreach (ColumnBase column in _parent._row._source._columns)
						{
							column.AddToInsert(delegate(ColumnBase a)
							{
								col.AddColumn(a);
							});
						}
						IRow row = col.Insert(_parent._row._source._entityInDb.InternalGetRowSource(), _parent._row, _parent._row._source._columns);
						if (row != null)
						{
							_parent._row._providerRow = row;
							_insertCommandSucceeded();
						}
					}
				}

				private InnerRow _row;

				public NewRowStrategy(InnerRow row)
				{
					_row = row;
				}

				public void SetColumnsAcordingToYourValue()
				{
					_row._source.NotifiyLookupedRows(_row, isNewRow: true);
					foreach (ColumnBase column in _row._source._columns)
					{
						column.ResetToDefaultValue();
					}
				}

				public void UpdateDatabaseAcordingToValues()
				{
					InsertCommand command = new InsertCommand(this, SetExistingRowStrategy);
					_row._source._parent._runner.RunQuery(command, isUpdateOrInsert: true);
				}

				private void SetExistingRowStrategy()
				{
					if (_row._strategy == this)
					{
						ExistingRowStrategy existingRowStrategy = new ExistingRowStrategy(_row);
						existingRowStrategy.LoadDataFromColumns();
						_row._strategy = existingRowStrategy;
					}
				}

				public void Delete()
				{
					throw new Error.ShouldntHappen("Cant delete new row");
				}

				public void Lock(Action callIfRowDoesNotExist, bool checkForValueChange)
				{
				}

				public bool IsNewRow()
				{
					return true;
				}

				public void ReloadRowData(Action callIfRowDoesNotExist)
				{
				}

				public void SetValue(ColumnBase column, IValueLoader loader)
				{
					SetExistingRowStrategy();
					_row._strategy.SetValue(column, loader);
					((ExistingRowStrategy)_row._strategy).SetColumnAcordingToValue(column);
				}

				public void Unlock()
				{
				}

				public void ReloadRowDataAndIgnoreExceptions()
				{
				}

				public void LockAndIgnoreExceptions()
				{
				}

				public ColumnDataInRow GetValueOf(ColumnBase column)
				{
					return null;
				}

				public void DoUpdateOrInsertSavingRow()
				{
					_row._source.Entity.DoOnSavingRow(new EntityOnSavingRowEventArgs(Activities.Insert));
				}

				public void DoDeleteOnSavingRow()
				{
					throw new Error.ShouldntHappen("Cant delete new row");
				}
			}

			private class DeletetRowStrategy : RowStrategy
			{
				private ColumnDataInRow[] _oldDatabaseValues;

				private QuerySource _source;

				public DeletetRowStrategy(ColumnDataInRow[] oldDatabaseValues, QuerySource source)
				{
					_source = source;
					_oldDatabaseValues = oldDatabaseValues;
				}

				public void SetColumnsAcordingToYourValue()
				{
					throw new Error.ShouldntHappen("Row Was Deleted");
				}

				public void UpdateDatabaseAcordingToValues()
				{
				}

				public void Delete()
				{
					throw new Error.ShouldntHappen("Row Was Deleted");
				}

				public void Lock(Action callIfRowDoesNotExist, bool checkForValueChange)
				{
					throw new Error.ShouldntHappen("Row Was Deleted");
				}

				public bool IsNewRow()
				{
					return false;
				}

				public void ReloadRowData(Action callIfRowDoesNotExist)
				{
					throw new NotImplementedException();
				}

				public void SetValue(ColumnBase column, IValueLoader loader)
				{
					throw new InvalidOperationException("Row was deleted");
				}

				public void Unlock()
				{
				}

				public void ReloadRowDataAndIgnoreExceptions()
				{
					throw new InvalidOperationException("Row was deleted");
				}

				public void LockAndIgnoreExceptions()
				{
					throw new Error.ShouldntHappen("Row Was Deleted");
				}

				public ColumnDataInRow GetValueOf(ColumnBase col)
				{
					if (_source._columnIndexes.TryGetValue(col, out var value))
					{
						return _oldDatabaseValues[value];
					}
					return null;
				}

				public void DoUpdateOrInsertSavingRow()
				{
				}

				public void DoDeleteOnSavingRow()
				{
					throw new Error.ShouldntHappen("Row Was Deleted");
				}
			}

			private class OtherDataProviderEmptyRowStrategy : RowStrategy
			{
				private InnerRow _row;

				public OtherDataProviderEmptyRowStrategy(InnerRow row)
				{
					_row = row;
				}

				public void SetColumnsAcordingToYourValue()
				{
					foreach (ColumnBase column in _row._source._columns)
					{
						column.ResetToDefaultValue();
					}
				}

				public void UpdateDatabaseAcordingToValues()
				{
				}

				public void Delete()
				{
				}

				public void Lock(Action callIfRowDoesNotExist, bool checkForValueChange)
				{
				}

				public bool IsNewRow()
				{
					return true;
				}

				public void ReloadRowData(Action callIfRowDoesNotExist)
				{
				}

				public void SetValue(ColumnBase column, IValueLoader loader)
				{
				}

				public void Unlock()
				{
				}

				public void ReloadRowDataAndIgnoreExceptions()
				{
				}

				public void LockAndIgnoreExceptions()
				{
				}

				public ColumnDataInRow GetValueOf(ColumnBase column)
				{
					return null;
				}

				public void DoUpdateOrInsertSavingRow()
				{
				}

				public void DoDeleteOnSavingRow()
				{
				}
			}

			private class OtherDataProviderRowStrategy : RowStrategy
			{
				private InnerRow _parent;

				private DataProviderRow _row;

				public OtherDataProviderRowStrategy(InnerRow parent, DataProviderRow row)
				{
					_parent = parent;
					_row = row;
				}

				public void SetColumnsAcordingToYourValue()
				{
					_parent._source.NotifiyLookupedRows(_parent, isNewRow: false);
					_row.SetColumnsAcordingToYourValueOrDefaultValuesForANewRowAndRefreshJoinedLookups();
				}

				public void UpdateDatabaseAcordingToValues()
				{
					if (!_row.IsNewRow())
					{
						_row.UpdateDatabaseAcordingToValues();
					}
				}

				public void Delete()
				{
					_row.Delete();
				}

				public void Lock(Action callIfRowDoesNotExist, bool checkForValueChange)
				{
					_row.Lock(callIfRowDoesNotExist, checkForValueChange);
				}

				public bool IsNewRow()
				{
					return _row.IsNewRow();
				}

				public void ReloadRowData(Action callIfRowDoesNotExist)
				{
					_row.ReloadRowData(callIfRowDoesNotExist);
				}

				public void SetValue(ColumnBase column, IValueLoader loader)
				{
					throw new NotImplementedException();
				}

				public void Unlock()
				{
					_row.Unlock();
				}

				public void ReloadRowDataAndIgnoreExceptions()
				{
					_row.ReloadRowDataAndIgnoreExceptions();
				}

				public void LockAndIgnoreExceptions()
				{
					_row.LockAndIgnoreExceptions();
				}

				public ColumnDataInRow GetValueOf(ColumnBase column)
				{
					return null;
				}

				public void DoUpdateOrInsertSavingRow()
				{
					if (!_row.IsNewRow())
					{
						_row.DoUpdateOrInsertOnSavingRow();
					}
				}

				public void DoDeleteOnSavingRow()
				{
					_row.DoDeleteOnSavingRow();
				}
			}

			internal class ColumnsForUpdateOrInsertCollector
			{
				private class NullValue : IValue
				{
					public void SaveTo(IValueSaver saver)
					{
						saver.SaveNull();
					}
				}

				private class EmptyDateTimeValue : IValue
				{
					public void SaveTo(IValueSaver saver)
					{
						saver.SaveEmptyDateTime();
					}
				}

				private class DateTimeCombinedValue : IValue
				{
					private DateTime _dateTime;

					public DateTimeCombinedValue(DateTime dateTime)
					{
						_dateTime = dateTime;
					}

					public void SaveTo(IValueSaver saver)
					{
						saver.SaveDateTime(_dateTime);
					}
				}

				private readonly List<ColumnBase> _updatedColumns;

				private readonly List<IValue> _values;

				private HashSet<ColumnBase> _columnsToIgnore = new HashSet<ColumnBase>();

				public int Count => _updatedColumns.Count;

				public ColumnsForUpdateOrInsertCollector(int capacity)
				{
					_updatedColumns = new List<ColumnBase>(capacity);
					_values = new List<IValue>(capacity);
				}

				public void AddColumn(ColumnBase column)
				{
					if (_columnsToIgnore.Contains(column))
					{
						return;
					}
					TimeColumn timeColumn = column as TimeColumn;
					if (timeColumn != null && timeColumn.DateColumnForDateTimeStorage != null)
					{
						column = timeColumn.DateColumnForDateTimeStorage;
					}
					DateColumn dateColumn = column as DateColumn;
					if (dateColumn != null && dateColumn.TimeColumnForDateTimeStorage != null)
					{
						_columnsToIgnore.Add(dateColumn);
						_columnsToIgnore.Add(dateColumn.TimeColumnForDateTimeStorage);
						_updatedColumns.Add(column);
						if (dateColumn.IsNull())
						{
							_values.Add(new NullValue());
							return;
						}
						if ((bool)(dateColumn.Value <= Date.Empty))
						{
							_values.Add(new EmptyDateTimeValue());
							return;
						}
						if (dateColumn.TimeColumnForDateTimeStorage.IsNull())
						{
							dateColumn.TimeColumnForDateTimeStorage.Value = Time.StartOfDay;
						}
						_values.Add(new DateTimeCombinedValue(dateColumn.Value.ToDateTime().AddSeconds(dateColumn.TimeColumnForDateTimeStorage.Value.TotalSeconds)));
					}
					else
					{
						_updatedColumns.Add(column);
						_values.Add(column.GetCurrentDbValue());
					}
				}

				public void RunUpdate(IRow providerRow, bool useOptimisticConcurrency)
				{
					providerRow.Update(_updatedColumns, _values, useOptimisticConcurrency);
				}

				public IRow Insert(IRowsSource internalGetRowSource, InnerRow row, IEnumerable<ColumnBase> selectedColumns)
				{
					return internalGetRowSource.Insert(_updatedColumns, _values, row, selectedColumns);
				}
			}

			private QuerySource _source;

			private RowStrategy _strategy;

			private IRow _providerRow;

			private InnerRowHelper _row;

			public InnerRow(QuerySource source, Func<IRowStorage, IRow> rowProvider, InnerRowHelper row)
			{
				_row = row;
				_source = source;
				_strategy = new ExistingRowStrategy(this);
				_providerRow = rowProvider(this);
				if (_providerRow == null)
				{
					_strategy = new NewRowStrategy(this);
				}
			}

			public void DoUpdateOrInsertOnSavingRow()
			{
				_strategy.DoUpdateOrInsertSavingRow();
			}

			public void DoDeleteOnSavingRow()
			{
				_strategy.DoDeleteOnSavingRow();
			}

			public override string ToString()
			{
				return _strategy.ToString();
			}

			public void SetColumnsAcordingToYourValueOrDefaultValuesForANewRowAndRefreshJoinedLookups()
			{
				_strategy.SetColumnsAcordingToYourValue();
			}

			public void UpdateDatabaseAcordingToValues()
			{
				_strategy.UpdateDatabaseAcordingToValues();
			}

			public void Delete()
			{
				_strategy.Delete();
			}

			public void Lock(Action callIfRowDoesNotExist, bool checkForChanges)
			{
				_strategy.Lock(callIfRowDoesNotExist, checkForChanges);
			}

			public void SetDataProviderRow(DataProviderRow r)
			{
				if (r == null)
				{
					_strategy = new OtherDataProviderEmptyRowStrategy(this);
				}
				else
				{
					_strategy = new OtherDataProviderRowStrategy(this, r);
				}
			}

			public bool IsNewRow()
			{
				return _strategy.IsNewRow();
			}

			public void ReloadRowData(Action callIfRowDoesNotExist)
			{
				_strategy.ReloadRowData(callIfRowDoesNotExist);
			}

			public bool IsEqualTo(DataProviderRow b)
			{
				if (_providerRow == null)
				{
					return this == b;
				}
				if (b is InnerRow innerRow)
				{
					return _providerRow.IsEqualTo(innerRow._providerRow);
				}
				return false;
			}

			public void Unlock()
			{
				_strategy.Unlock();
			}

			public ColumnDataInRow GetValue(ColumnBase column)
			{
				ColumnDataInRow valueOf = _strategy.GetValueOf(column);
				if (valueOf != null)
				{
					return valueOf;
				}
				return _row.GetValue(column);
			}

			IValue IRowStorage.GetValue(ColumnBase column)
			{
				return GetValue(column);
			}

			public void SetValue(ColumnBase column, IValueLoader value)
			{
				_strategy.SetValue(column, value);
			}

			public IRow GetRow()
			{
				return _providerRow;
			}

			public void ReloadRowDataAndIgnoreExceptions()
			{
				_strategy.ReloadRowDataAndIgnoreExceptions();
			}

			public void LockAndIgnoreExceptions()
			{
				if (_source._entityInDb.AllowRowLocking)
				{
					_strategy.LockAndIgnoreExceptions();
				}
			}

			public bool HasJoins()
			{
				return false;
			}

			public DataRowFilter GetFilterChecker()
			{
				return new FilterOnColumnsForDataProviderRow(this);
			}

			public void AddEqualToColumn(ColumnBase parentIdColumn, ColumnBase columnToTakeTheValueFrom, FilterCollection fc)
			{
				GetValue(columnToTakeTheValueFrom)?.AddEqualToColumn(parentIdColumn, fc);
			}

			public void AttachToRow(InnerRowHelper row)
			{
				_row = row;
			}
		}

		protected List<ColumnBase> _columns;

		protected Dictionary<ColumnBase, int> _columnIndexes = new Dictionary<ColumnBase, int>();

		protected ColumnBase[] _primaryKeyColumns;

		protected QueryClass _parent;

		internal Entity _entityInDb;

		protected bool _useIndex = true;

		public Entity Entity => _entityInDb;

		public virtual IFilter Where
		{
			get
			{
				throw new NotImplementedException();
			}
		}

		public virtual bool IsOuterJoin
		{
			get
			{
				throw new NotImplementedException();
			}
		}

		public QuerySource(IEnumerable<ColumnBase> selectedColumns, QueryClass parent, Entity table)
		{
			_entityInDb = table;
			_parent = parent;
			_primaryKeyColumns = _entityInDb.PrimaryKeyColumns;
			foreach (ColumnBase selectedColumn in selectedColumns)
			{
				_parent._columns.Add(selectedColumn);
				_parent._selectedColumns.Add(selectedColumn);
			}
			_columns = new List<ColumnBase>(selectedColumns);
			int internalIndexInRow = 0;
			foreach (ColumnBase selectedColumn2 in selectedColumns)
			{
				selectedColumn2._internalIndexInRow = internalIndexInRow;
				_columnIndexes.Add(selectedColumn2, internalIndexInRow++);
			}
			ColumnBase[] primaryKeyColumns = _primaryKeyColumns;
			foreach (ColumnBase columnBase in primaryKeyColumns)
			{
				if (!_parent._columns.Contains(columnBase))
				{
					_columns.Add(columnBase);
					columnBase._internalIndexInRow = internalIndexInRow;
					_columnIndexes.Add(columnBase, internalIndexInRow++);
					_parent._selectedColumns.Add(columnBase);
					_parent._columns.Add(columnBase);
				}
			}
			if (table.AllowRowLocking)
			{
				_parent._allowLockAllRows = true;
			}
		}

		protected abstract void NotifiyLookupedRows(InnerRow row, bool isNewRow);

		public myRow PopulateNewRow(InnerRowHelper r)
		{
			return new InnerRow(this, (IRowStorage x) => (IRow)null, r);
		}

		public bool Contains(ColumnBase column)
		{
			return _entityInDb == column.Entity;
		}

		public IQuerySource Add(IQuerySource item)
		{
			JoniedQuerySource joniedQuerySource = new JoniedQuerySource();
			joniedQuerySource.Add(this);
			return joniedQuerySource.Add(item);
		}

		public bool AddColumnIfItFits(ColumnBase column)
		{
			if (Contains(column))
			{
				_columns.Add(column);
				column._internalIndexInRow = _columnIndexes.Count;
				_columnIndexes.Add(column, _columnIndexes.Count);
				_parent._columns.Add(column);
				_parent._selectedColumns.Add(column);
				return true;
			}
			return false;
		}

		public virtual myRow Populate(InnerRowHelper x, IRowsReader provider)
		{
			return new InnerRow(this, (IRowStorage r) => provider.GetRow(r), x);
		}
	}

	private class mySubQueryResultProviderForManualSort : SubQueryResultProvider
	{
		private QueryClass _parent;

		private ApplyRowToColumnsForManualSort _applyRowToColumns;

		public mySubQueryResultProviderForManualSort(QueryClass parent, ApplyRowToColumnsForManualSort applyRowToColumns)
		{
			_parent = parent;
			_applyRowToColumns = applyRowToColumns;
		}

		public DataProviderRow CreateTemporaryNewRow()
		{
			return _parent.CreateTemporaryNewRow();
		}

		public QueryResult SubFilter(FilterCondition extraFilter)
		{
			RowSourceSortedManualy rowSourceSortedManualy = new RowSourceSortedManualy(_parent._sort, _applyRowToColumns, null);
			rowSourceSortedManualy.Populate(() => _parent.SubFilter(extraFilter));
			return new ResettableQueryResultToQueryResult(rowSourceSortedManualy);
		}

		public QueryResult FetchRowsThatMatchFilterOrAreAfterIt(FilterCondition filter, bool reverseParkOnRowOrder)
		{
			return _parent.FetchRowsThatMatchFilterOrAreAfterIt(filter, reverseParkOnRowOrder);
		}

		public bool ProvidesInfiniteQueryResults()
		{
			return _parent.ProvidesInfiniteQueryResults();
		}
	}

	private class SubFilterCommand : RunMonitoredCommand
	{
		private QueryClass _parent;

		private IRowsProvider _provider;

		public QueryResult Result = new EmptyQueryResult();

		public SubFilterCommand(QueryClass parent, FilterCondition extraFilter)
		{
			_parent = parent;
			_provider = _parent._rowSource.CreateReader(_parent._selectedColumns, _parent.PrepareFilter(extraFilter, supportWildCard: true), _parent.PrepareSort(reverseRowOrder: false), _parent._joins, _parent._disableCache);
		}

		public void Run()
		{
			Result = new QueryResultBridgeToSelectedRowsProvider(_provider.FromStart(), _parent);
		}
	}

	private class PreloadQueryResult : RunMonitoredCommand
	{
		private QueryClass _parent;

		private IFilter _filter;

		private Sort _sort;

		private bool _lockAllRows;

		public QueryResult Result = new EmptyQueryResult();

		public PreloadQueryResult(QueryClass parent, IFilter filter, Sort sort, bool lockAllRows)
		{
			_lockAllRows = lockAllRows;
			_parent = parent;
			_filter = filter;
			_sort = sort;
		}

		public void Run()
		{
			if (_parent._joins.Count == 0)
			{
				Result = new QueryResultBridgeToSelectedRowsProvider(_parent._rowSource.ExecuteCommand(_parent._selectedColumns, _filter, _sort, firstRowOnly: false, shouldBeOnlyOneRowThatMatchesTheFilter: false, lockAllRows: false), _parent);
			}
			else
			{
				Result = new QueryResultBridgeToSelectedRowsProvider(_parent._rowSource.CreateReader(_parent._selectedColumns, _filter, _sort, _parent._joins, disableCache: false).FromStart(), _parent);
			}
		}
	}

	private class FindCommand : RowsReaderProviderCommand
	{
		private IFilter _filter;

		private bool _reverse;

		public FindCommand(QueryClass parent, IFilter filter, bool reverse)
			: base(parent)
		{
			_filter = filter;
			_reverse = reverse;
		}

		protected override IRowsReader CreateReader(IRowsProvider p)
		{
			return p.Find(_filter, _reverse);
		}
	}

	private abstract class RowsReaderProviderCommand : RunMonitoredCommand
	{
		private QueryClass _parent;

		public QueryResult Result = new EmptyQueryResult();

		public RowsReaderProviderCommand(QueryClass parent)
		{
			_parent = parent;
			if (_parent._rowsProvider == null)
			{
				_parent._rowsProvider = _parent._rowSource.CreateReader(_parent._selectedColumns, _parent.PrepareFilter(null, supportWildCard: true), _parent.PrepareSort(reverseRowOrder: false), _parent._joins, _parent._disableCache);
			}
		}

		public void Run()
		{
			Result = new QueryResultBridgeToSelectedRowsProvider(CreateReader(_parent._rowsProvider), _parent);
		}

		protected abstract IRowsReader CreateReader(IRowsProvider p);
	}

	private class AfterRowCommand : RowsReaderProviderCommand
	{
		private IRow _filter;

		private bool _rverese;

		public AfterRowCommand(QueryClass parent, IRow filter, bool rverese)
			: base(parent)
		{
			_filter = filter;
			_rverese = rverese;
		}

		protected override IRowsReader CreateReader(IRowsProvider p)
		{
			return p.After(_filter, _rverese);
		}
	}

	private class FromRowCommand : RowsReaderProviderCommand
	{
		private IRow _filter;

		private bool _rverese;

		public FromRowCommand(QueryClass parent, IRow filter, bool rverese)
			: base(parent)
		{
			_filter = filter;
			_rverese = rverese;
		}

		protected override IRowsReader CreateReader(IRowsProvider p)
		{
			return p.From(_filter, _rverese);
		}
	}

	private class FromCommand : RowsReaderProviderCommand
	{
		private IFilter _filter;

		private bool _rverese;

		public FromCommand(QueryClass parent, IFilter filter, bool rverese)
			: base(parent)
		{
			_filter = filter;
			_rverese = rverese;
		}

		protected override IRowsReader CreateReader(IRowsProvider p)
		{
			return p.From(_filter, _rverese);
		}
	}

	private class FromEndCommand : RowsReaderProviderCommand
	{
		public FromEndCommand(QueryClass parent)
			: base(parent)
		{
		}

		protected override IRowsReader CreateReader(IRowsProvider p)
		{
			return p.FromEnd();
		}
	}

	private class FromStartCommand : RowsReaderProviderCommand
	{
		public FromStartCommand(QueryClass parent)
			: base(parent)
		{
		}

		protected override IRowsReader CreateReader(IRowsProvider p)
		{
			return p.FromStart();
		}
	}

	private class SelectMonitoredCommand : RunMonitoredCommand
	{
		private QueryClass _parent;

		private IFilter _filter;

		private Sort _sort;

		private bool _lockAllRows;

		public QueryResult Result = new EmptyQueryResult();

		public SelectMonitoredCommand(QueryClass parent, IFilter filter, Sort sort, bool lockAllRows)
		{
			_lockAllRows = lockAllRows;
			_parent = parent;
			_filter = filter;
			_sort = sort;
		}

		public void Run()
		{
			Result = new QueryResultBridgeToSelectedRowsProvider(_parent._rowSource.ExecuteReader(_parent._selectedColumns, _filter, _sort, _parent._joins, _lockAllRows), _parent);
		}
	}

	private class QueryResultBridgeToSelectedRowsProvider : QueryResult, IDisposable
	{
		private class RowsReaderReadCommand : RunMonitoredCommand
		{
			private IRowsReader _provider;

			public bool Result;

			public RowsReaderReadCommand(IRowsReader provider)
			{
				_provider = provider;
			}

			public void Run()
			{
				Result = false;
				Result = _provider.Read();
			}
		}

		private IRowsReader _provider;

		private QueryClass _parent;

		private RowsReaderReadCommand _read;

		private DataProviderRow _row;

		public DataProviderRow Current => _row;

		public QueryResultBridgeToSelectedRowsProvider(IRowsReader provider, QueryClass parent)
		{
			_parent = parent;
			_provider = provider;
			_read = new RowsReaderReadCommand(_provider);
		}

		private bool Read()
		{
			_parent._runner.RunQuery(_read, isUpdateOrInsert: false);
			return _read.Result;
		}

		public void Dispose()
		{
			_parent._runner.RunQuery(new ActionMonitoredCommand(_provider.Dispose), isUpdateOrInsert: false);
		}

		public bool MoveNext()
		{
			while (Read())
			{
				myRow myRow2 = _parent._sources.Populate(DummyInnerRowHelper.Instance, _provider);
				if (_parent._filter != null)
				{
					DataRowFilter filterChecker = myRow2.GetFilterChecker();
					_parent._filter.ApplyTo(new FilterRelevanceDecorator(filterChecker, new myIdentityDataProvider(_parent._primaryEntity)), supportWildCard: true);
					if (!filterChecker.MatchesFilter)
					{
						continue;
					}
				}
				_row = myRow2;
				return true;
			}
			_row = null;
			return false;
		}
	}

	private class FilterOnColumnsForDataProviderRow : DataRowFilter, Filter
	{
		private bool _matchesFilter = true;

		private myRow _row;

		private bool _isEmpty = true;

		public bool MatchesFilter
		{
			get
			{
				return _matchesFilter;
			}
			set
			{
				if (_matchesFilter)
				{
					if (_isEmpty)
					{
						_isEmpty = false;
					}
					if (!value)
					{
						_matchesFilter = false;
					}
				}
			}
		}

		public bool IsEmpty => _isEmpty;

		public FilterOnColumnsForDataProviderRow(myRow row)
		{
			_row = row;
		}

		public void AddBetweenCondition(ColumnBase column, ColumnFilterValue from, ColumnFilterValue to)
		{
			AddGreaterOrEqual(column, from);
			AddLessOrEqual(column, to);
		}

		public void AddEqual(ColumnBase column, ColumnFilterValue to)
		{
			Check(column, to, (int i) => i == 0);
		}

		public void AddDifferent(ColumnBase column, ColumnFilterValue from)
		{
			Check(column, from, (int i) => i != 0);
		}

		private void Check(ColumnBase column, ColumnFilterValue to, Func<int, bool> theCheck)
		{
			ColumnDataInRow value = _row.GetValue(column);
			if (value != null)
			{
				MatchesFilter = theCheck(value.CompareValueTo(to));
			}
		}

		public void AddStartsWith(ColumnBase column, ColumnFilterValue to)
		{
			ColumnDataInRow value = _row.GetValue(column);
			if (value != null)
			{
				MatchesFilter = value.ValueStartsWith(to);
			}
		}

		public void AddGreaterOrEqual(ColumnBase column, ColumnFilterValue to)
		{
			if (!to.IsNull())
			{
				Check(column, to, (int i) => i >= 0);
			}
		}

		public void AddLessOrEqual(ColumnBase column, ColumnFilterValue to)
		{
			if (!to.IsNull())
			{
				Check(column, to, (int i) => i <= 0);
			}
		}

		public void AddWhere(Action<TranslateToGatewayTerms, Action<string>> whereFactory)
		{
		}

		public void AddOr(FilterCondition a, FilterCondition b)
		{
			FilterOnColumnsForDataProviderRow filterOnColumnsForDataProviderRow = new FilterOnColumnsForDataProviderRow(_row);
			FilterOnColumnsForDataProviderRow filterOnColumnsForDataProviderRow2 = new FilterOnColumnsForDataProviderRow(_row);
			a.ApplyTo(filterOnColumnsForDataProviderRow, supportWildCard: true);
			if (!filterOnColumnsForDataProviderRow.MatchesFilter)
			{
				b.ApplyTo(filterOnColumnsForDataProviderRow2, supportWildCard: true);
			}
			MatchesFilter = filterOnColumnsForDataProviderRow.MatchesFilter || filterOnColumnsForDataProviderRow2.MatchesFilter;
		}

		public void AddLessThan(ColumnBase column, ColumnFilterValue to)
		{
			if (!to.IsNull())
			{
				Check(column, to, (int i) => i < 0);
			}
		}

		public void AddGreaterThan(ColumnBase column, ColumnFilterValue to)
		{
			if (!to.IsNull())
			{
				Check(column, to, (int i) => i > 0);
			}
		}

		public void AddUserCondition(Func<bool> condition)
		{
		}

		public void AddLessOrEqualWithWildcard(TextColumn column, Text value, ColumnFilterValue filterItem)
		{
			ColumnDataInRow value2 = _row.GetValue(column);
			if (value2 != null)
			{
				MatchesFilter = value2.IsSubstringLessOrEqualTo(value);
			}
		}

		public void AddTrueCondition()
		{
			MatchesFilter = true;
		}
	}

	private class myIdentityDataProvider : IdentifierProvider
	{
		private IdentifierProvider _e;

		public myIdentityDataProvider(IdentifierProvider e)
		{
			_e = e;
		}

		public bool Contains(ColumnBase cb)
		{
			if (_e.Contains(cb))
			{
				return cb.AlwaysIncludeInNonDbFilter();
			}
			return false;
		}
	}

	private class FilterColumnSelector : Filter, IdentifierProvider
	{
		private Action<ColumnBase> _selectColumn;

		private bool _selectOnlyLeftSideColumns;

		public FilterColumnSelector(Action<ColumnBase> selectColumn, bool selectOnlyLeftSideColumns = false)
		{
			_selectColumn = selectColumn;
			_selectOnlyLeftSideColumns = selectOnlyLeftSideColumns;
		}

		public void AddBetweenCondition(ColumnBase column, ColumnFilterValue from, ColumnFilterValue to)
		{
			SelectWhereMeaningfull(column, from, to);
		}

		private void SelectWhereMeaningfull(params WhereMeaningfullItem[] items)
		{
			for (int i = 0; i < items.Length; i++)
			{
				items[i].SendIdentifierTo(this);
				if (_selectOnlyLeftSideColumns)
				{
					break;
				}
			}
		}

		public void AddEqual(ColumnBase column, ColumnFilterValue to)
		{
			SelectWhereMeaningfull(column, to);
		}

		public void AddDifferent(ColumnBase column, ColumnFilterValue from)
		{
			SelectWhereMeaningfull(column, from);
		}

		public void AddStartsWith(ColumnBase column, ColumnFilterValue to)
		{
			SelectWhereMeaningfull(column, to);
		}

		public void AddGreaterOrEqual(ColumnBase column, ColumnFilterValue to)
		{
			SelectWhereMeaningfull(column, to);
		}

		public void AddLessOrEqual(ColumnBase column, ColumnFilterValue to)
		{
			SelectWhereMeaningfull(column, to);
		}

		public void AddWhere(Action<TranslateToGatewayTerms, Action<string>> whereFactory)
		{
			whereFactory(delegate(WhereMeaningfullItem x)
			{
				SelectWhereMeaningfull(x);
				return "";
			}, delegate
			{
			});
		}

		public void AddOr(FilterCondition a, FilterCondition b)
		{
			a.ApplyTo(this, supportWildCard: true);
			b.ApplyTo(this, supportWildCard: true);
		}

		public void AddLessThan(ColumnBase column, ColumnFilterValue to)
		{
			SelectWhereMeaningfull(column, to);
		}

		public void AddGreaterThan(ColumnBase column, ColumnFilterValue to)
		{
			SelectWhereMeaningfull(column, to);
		}

		public void AddUserCondition(Func<bool> condition)
		{
		}

		public void AddLessOrEqualWithWildcard(TextColumn column, Text value, ColumnFilterValue filterItem)
		{
			SelectWhereMeaningfull(column);
		}

		public void AddTrueCondition()
		{
		}

		public bool Contains(ColumnBase column)
		{
			_selectColumn(column);
			return true;
		}
	}

	private interface myRow : DataProviderRow
	{
		IRow GetRow();

		void AttachToRow(InnerRowHelper joinedRowsBundle);

		ColumnDataInRow GetValue(ColumnBase column);
	}

	private interface InnerRowHelper
	{
		bool HasJoins();

		void Refresh(DataProviderRow current);

		ColumnDataInRow GetValue(ColumnBase column);
	}

	private class DummyInnerRowHelper : InnerRowHelper
	{
		public static DummyInnerRowHelper Instance = new DummyInnerRowHelper();

		public bool HasJoins()
		{
			return false;
		}

		public void Refresh(DataProviderRow current)
		{
		}

		public ColumnDataInRow GetValue(ColumnBase column)
		{
			return null;
		}
	}

	private class JoinedRowsBundle : myRow, DataProviderRow, InnerRowHelper
	{
		private List<myRow> _innerRows = new List<myRow>();

		private bool _inGetValue;

		public void SetColumnsAcordingToYourValueOrDefaultValuesForANewRowAndRefreshJoinedLookups()
		{
			foreach (QuerySource.InnerRow innerRow in _innerRows)
			{
				innerRow.SetColumnsAcordingToYourValueOrDefaultValuesForANewRowAndRefreshJoinedLookups();
			}
		}

		public void UpdateDatabaseAcordingToValues()
		{
			_innerRows[0].UpdateDatabaseAcordingToValues();
		}

		public void Delete()
		{
			_innerRows[0].Delete();
		}

		public void DoUpdateOrInsertOnSavingRow()
		{
			_innerRows[0].DoUpdateOrInsertOnSavingRow();
		}

		public void DoDeleteOnSavingRow()
		{
			_innerRows[0].DoDeleteOnSavingRow();
		}

		public void Lock(Action callIfRowDoesNotExist, bool checkForChanges)
		{
			for (int i = 0; i < _innerRows.Count; i++)
			{
				_innerRows[i].Lock(callIfRowDoesNotExist, checkForChanges);
			}
		}

		internal void AddInnerRow(myRow innerRow)
		{
			_innerRows.Add(innerRow);
		}

		public override string ToString()
		{
			string text = "";
			foreach (QuerySource.InnerRow innerRow in _innerRows)
			{
				text += innerRow.ToString();
			}
			return text;
		}

		public bool IsNewRow()
		{
			return _innerRows[0].IsNewRow();
		}

		public void ReloadRowData(Action callIfRowDoesNotExist)
		{
			_innerRows[0].ReloadRowData(callIfRowDoesNotExist);
		}

		public void ReloadRowDataAndIgnoreExceptions()
		{
			_innerRows[0].ReloadRowDataAndIgnoreExceptions();
		}

		public bool IsEqualTo(DataProviderRow b)
		{
			if (b is JoinedRowsBundle joinedRowsBundle)
			{
				return _innerRows[0].IsEqualTo(joinedRowsBundle._innerRows[0]);
			}
			return false;
		}

		public void Unlock()
		{
			for (int i = 0; i < _innerRows.Count; i++)
			{
				_innerRows[i].Unlock();
			}
		}

		public void LockAndIgnoreExceptions()
		{
			for (int i = 0; i < _innerRows.Count; i++)
			{
				_innerRows[i].LockAndIgnoreExceptions();
			}
		}

		public bool HasJoins()
		{
			return _innerRows.Count > 1;
		}

		public DataRowFilter GetFilterChecker()
		{
			return new FilterOnColumnsForDataProviderRow(this);
		}

		public void AddEqualToColumn(ColumnBase parentIdColumn, ColumnBase columnToTakeTheValueFrom, FilterCollection fc)
		{
			GetValue(columnToTakeTheValueFrom)?.AddEqualToColumn(parentIdColumn, fc);
		}

		public IRow GetRow()
		{
			return _innerRows[0].GetRow();
		}

		public void AttachToRow(InnerRowHelper joinedRowsBundle)
		{
			throw new NotImplementedException();
		}

		public ColumnDataInRow GetValue(ColumnBase column)
		{
			if (_inGetValue)
			{
				return null;
			}
			_inGetValue = true;
			try
			{
				ColumnDataInRow columnDataInRow = null;
				foreach (myRow innerRow in _innerRows)
				{
					columnDataInRow = innerRow.GetValue(column);
					if (columnDataInRow != null)
					{
						return columnDataInRow;
					}
				}
				return null;
			}
			finally
			{
				_inGetValue = false;
			}
		}

		public void Refresh(DataProviderRow withThisRow)
		{
			JoinedRowsBundle joinedRowsBundle = withThisRow as JoinedRowsBundle;
			if (withThisRow == null)
			{
				throw new Error.DidNotAnticipateThis();
			}
			_innerRows = joinedRowsBundle._innerRows;
			foreach (myRow innerRow in _innerRows)
			{
				innerRow.AttachToRow(this);
			}
		}
	}

	private class DoOnRowsCommand : RunMonitoredCommand
	{
		private Action<QueryResult> _doOnRows;

		private QueryClass _parent;

		private UberFilter _filter;

		private bool _lockAllRows;

		public DoOnRowsCommand(QueryClass parent, UberFilter filter, Action<QueryResult> doOnRows, bool lockAllRows)
		{
			_lockAllRows = lockAllRows;
			_filter = filter;
			_parent = parent;
			_doOnRows = doOnRows;
		}

		public void Run()
		{
			if (_parent._doNotUseCommand)
			{
				using (QueryResultBridgeToSelectedRowsProvider obj = new QueryResultBridgeToSelectedRowsProvider(_parent._rowSource.ExecuteReader(_parent._selectedColumns, _filter.GetIFilter(), _parent.PrepareSort(reverseRowOrder: false), new IJoin[0], _lockAllRows), _parent))
				{
					_doOnRows(obj);
					return;
				}
			}
			using QueryResultBridgeToSelectedRowsProvider obj2 = new QueryResultBridgeToSelectedRowsProvider(_parent._rowSource.ExecuteCommand(_parent._selectedColumns, _filter.GetIFilter(), _parent.PrepareSort(reverseRowOrder: false), !_filter.HasTrueCondition, _filter.OnlyOneRowShouldMatchThisFilter(), _lockAllRows), _parent);
			_doOnRows(obj2);
		}
	}

	private IQuerySource _sources;

	private List<IJoin> _joins = new List<IJoin>();

	private Sort _sort;

	private Sort _sortForSelect;

	private FilterCondition _filter;

	private MonitoredDatabaseRunner _runner;

	private IdentifierProvider _myIdentifier;

	private HashSet<ColumnBase> _columns = new HashSet<ColumnBase>();

	private List<ColumnBase> _selectedColumns = new List<ColumnBase>();

	private IRowsSource _rowSource;

	private bool _disableCache;

	private bool _allowLockAllRows;

	private Entity _primaryEntity;

	private Func<bool> _useOptimisticConcurrency;

	private bool _doNotUseCommand;

	private Action<QueryConsumer> _construct;

	private IRowsProvider _rowsProvider;

	private bool _addedColumns;

	public QueryClass(Entity table, IRowsSource source, IEnumerable<ColumnBase> selectedColumns, FilterCondition filter, Sort sort, MonitoredDatabaseRunner runner, bool disableCache, Func<bool> useOptimisticConcurrency, bool doNotUseCommand)
	{
		_doNotUseCommand = doNotUseCommand;
		_allowLockAllRows = table.AllowRowLocking;
		_sort = sort;
		_sortForSelect = _sort;
		_filter = filter;
		_myIdentifier = new myIdentifier(this);
		_rowSource = source;
		if (_rowSource == null)
		{
			throw new NullReferenceException();
		}
		_primaryEntity = table;
		_sources = new MainTableSource(table, selectedColumns, this);
		_disableCache = disableCache;
		_runner = runner;
		_useOptimisticConcurrency = useOptimisticConcurrency;
	}

	public void AddJoin(Entity t, IEnumerable<ColumnBase> selectedColumns, FilterCondition joinFilter, LookupInAQuery lookup)
	{
		InnerJoinQuerySource item = new InnerJoinQuerySource(t, selectedColumns, joinFilter, lookup, this);
		_sources = _sources.Add(item);
		_joins.Add(item);
	}

	public void AddLeftOuterJoin(Entity t, IEnumerable<ColumnBase> selectedColumns, FilterCondition joinFilter, LookupInAQuery lookup)
	{
		OuterJoinQuerySource item = new OuterJoinQuerySource(t, selectedColumns, joinFilter, lookup, this);
		_sources = _sources.Add(item);
		_joins.Add(item);
	}

	public void Prepare(ApplyRowToColumnsForManualSort applyRowToColumns, Action notifyThisMayTakeLong, RowsProgressHandler sorting, bool donotFetchSort)
	{
		List<ColumnBase> list = new List<ColumnBase>();
		bool flag = false;
		foreach (SortSegment segment in _sort.Segments)
		{
			if (_sources.Contains(segment.Column) && !segment.Column.ExcludeFromDbWhere)
			{
				list.Add(segment.Column);
			}
			else
			{
				flag = true;
			}
		}
		SelectColumns(list);
		if ((!flag && _rowSource.IsOrderBySupported(_sort)) || donotFetchSort)
		{
			_construct = delegate(QueryConsumer consumer)
			{
				consumer.UserResultProvider(this);
			};
			return;
		}
		notifyThisMayTakeLong();
		_sortForSelect = new Sort();
		RowSourceSortedManualy rows = new RowSourceSortedManualy(_sort, applyRowToColumns, sorting);
		rows.Populate(() => AllRows(lockAllRows: false));
		_construct = delegate(QueryConsumer consumer)
		{
			consumer.UseQueryResult(rows, new mySubQueryResultProviderForManualSort(this, applyRowToColumns));
		};
	}

	private QueryResult SelectWithoutOriginalFilter(FilterCollection filter)
	{
		FilterCollection filterCollection = new FilterCollection();
		filterCollection.InternalAdd(filter);
		FilterColumnSelector condition = new FilterColumnSelector(AddColumnIfItFits);
		filterCollection.ApplyTo(condition, supportWildCard: true);
		SelectMonitoredCommand selectMonitoredCommand = new SelectMonitoredCommand(this, new FilterConditionBridgeToIFilter(filterCollection, _myIdentifier, supportWildCard: true), PrepareSort(reverseRowOrder: false), lockAllRows: false);
		_runner.RunQuery(selectMonitoredCommand, isUpdateOrInsert: false);
		return selectMonitoredCommand.Result;
	}

	public QueryResult SubFilter(FilterCondition extraFilter)
	{
		SubFilterCommand subFilterCommand = new SubFilterCommand(this, extraFilter);
		_runner.RunQuery(subFilterCommand, isUpdateOrInsert: false);
		return subFilterCommand.Result;
	}

	public QueryResult AllRows(bool lockAllRows)
	{
		SelectMonitoredCommand selectMonitoredCommand = new SelectMonitoredCommand(this, PrepareFilter(null, supportWildCard: true), PrepareSort(reverseRowOrder: false), lockAllRows && _allowLockAllRows);
		_runner.RunQuery(selectMonitoredCommand, isUpdateOrInsert: false);
		return selectMonitoredCommand.Result;
	}

	public QueryResult Preload()
	{
		PreloadQueryResult preloadQueryResult = new PreloadQueryResult(this, PrepareFilter(null, supportWildCard: true), PrepareSort(reverseRowOrder: false), lockAllRows: false);
		_runner.RunQuery(preloadQueryResult, isUpdateOrInsert: false);
		return preloadQueryResult.Result;
	}

	public QueryResult FromEnd()
	{
		FromEndCommand fromEndCommand = new FromEndCommand(this);
		_runner.RunQuery(fromEndCommand, isUpdateOrInsert: false);
		return fromEndCommand.Result;
	}

	public QueryResult After(DataProviderRow row, bool reverse)
	{
		myRow myRow2 = row as myRow;
		AfterRowCommand afterRowCommand = new AfterRowCommand(this, myRow2.GetRow(), reverse);
		_runner.RunQuery(afterRowCommand, isUpdateOrInsert: false);
		return afterRowCommand.Result;
	}

	public QueryResult FetchRowsThatMatchFilterOrAreAfterIt(FilterCondition filter, bool reverseParkOnRowOrder)
	{
		List<ColumnBase> list = new List<ColumnBase>();
		FilterColumnSelector filter2 = new FilterColumnSelector(list.Add, selectOnlyLeftSideColumns: true);
		filter.ApplyTo(filter2, supportWildCard: true);
		bool flag = false;
		for (int num = _sort.Segments.Count - 1; num >= 0; num--)
		{
			bool flag2 = list.Remove(_sort.Segments[num].Column);
			if (flag2)
			{
				flag = true;
			}
			if (flag && !flag2)
			{
				flag = false;
				break;
			}
		}
		if (flag)
		{
			FromCommand fromCommand = new FromCommand(this, new FilterConditionBridgeToIFilter(filter, _myIdentifier, supportWildCard: true), reverseParkOnRowOrder);
			_runner.RunQuery(fromCommand, isUpdateOrInsert: false);
			return fromCommand.Result;
		}
		FindCommand findCommand = new FindCommand(this, new FilterConditionBridgeToIFilter(filter, _myIdentifier, supportWildCard: true), reverseParkOnRowOrder);
		_runner.RunQuery(findCommand, isUpdateOrInsert: false);
		return findCommand.Result;
	}

	public QueryResult FromStart()
	{
		FromStartCommand fromStartCommand = new FromStartCommand(this);
		_runner.RunQuery(fromStartCommand, isUpdateOrInsert: false);
		return fromStartCommand.Result;
	}

	public QueryResult From(DataProviderRow row, bool reverse)
	{
		if (!(row is myRow myRow2))
		{
			return new EmptyQueryResult();
		}
		IRow row2 = myRow2.GetRow();
		if (row2 == null)
		{
			return new EmptyQueryResult();
		}
		FromRowCommand fromRowCommand = new FromRowCommand(this, row2, reverse);
		_runner.RunQuery(fromRowCommand, isUpdateOrInsert: false);
		return fromRowCommand.Result;
	}

	private Sort PrepareSort(bool reverseRowOrder)
	{
		Sort sort = _sortForSelect;
		if (reverseRowOrder)
		{
			sort = sort.Clone();
			sort.Reversed = !sort.Reversed;
		}
		return sort;
	}

	private IFilter PrepareFilter(FilterCondition extraFilter, bool supportWildCard)
	{
		MakeSureAllColumnsAreSelected(extraFilter, supportWildCard);
		return PrepareFilter(extraFilter, supportWildCard, _myIdentifier, _filter);
	}

	private void MakeSureAllColumnsAreSelected(FilterCondition extraFilter, bool supportWildCard)
	{
		if (_addedColumns)
		{
			return;
		}
		FilterColumnSelector filterColumnSelector = null;
		if (extraFilter != null && !extraFilter.IsEmpty)
		{
			if (filterColumnSelector == null)
			{
				filterColumnSelector = new FilterColumnSelector(AddColumnIfItFits);
			}
			extraFilter.ApplyTo(filterColumnSelector, supportWildCard);
		}
		if (_filter != null && !_filter.IsEmpty)
		{
			if (filterColumnSelector == null)
			{
				filterColumnSelector = new FilterColumnSelector(AddColumnIfItFits);
			}
			_filter.ApplyTo(filterColumnSelector, supportWildCard);
		}
		_addedColumns = true;
	}

	public static IFilter PrepareFilter(FilterCondition extraFilter, bool supportWildCard, IdentifierProvider dentifierProvider, FilterCondition filterCondition)
	{
		FilterCollection filterCollection = new FilterCollection();
		if (extraFilter != null)
		{
			filterCollection.InternalAdd(extraFilter);
		}
		filterCollection.InternalAdd(filterCondition);
		return new FilterConditionBridgeToIFilter(filterCollection, dentifierProvider, supportWildCard);
	}

	public void DoOnRows(UberFilter filter, Action<QueryResult> doOnRows, bool supportWildCard, bool lockAllRows)
	{
		_addedColumns = true;
		_runner.RunQuery(new DoOnRowsCommand(this, filter, doOnRows, lockAllRows), supportWildCard);
	}

	public DataProviderRow CreateTemporaryNewRow()
	{
		return _sources.PopulateNewRow(DummyInnerRowHelper.Instance);
	}

	public bool ProvidesInfiniteQueryResults()
	{
		return false;
	}

	public void ClearCache()
	{
	}

	public IdentifierProvider GetIdentifier()
	{
		return _myIdentifier;
	}

	public void AddColumnIfItsNotThere(ColumnBase column)
	{
		if (!_addedColumns)
		{
			AddColumnIfItFits(column);
		}
	}

	public void Construct(QueryConsumer client, ApplyRowToColumnsForManualSort applyRowToColumns, RowsProgressHandler sorting, bool donotFetchSort)
	{
		if (_construct == null)
		{
			Prepare(applyRowToColumns, delegate
			{
			}, sorting, donotFetchSort);
		}
		_construct(client);
	}

	public void AddColumnIfItFits(ColumnBase column)
	{
		if (!_columns.Contains(column))
		{
			_sources.AddColumnIfItFits(column);
		}
	}

	public void SelectColumns(List<ColumnBase> columns)
	{
		foreach (ColumnBase column in columns)
		{
			AddColumnIfItFits(column);
		}
	}
}
