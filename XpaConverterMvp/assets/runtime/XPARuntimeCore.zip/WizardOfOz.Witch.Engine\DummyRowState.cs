namespace WizardOfOz.Witch.Engine;

internal class DummyRowState : RowState
{
	public static readonly DummyRowState Instance = new DummyRowState();

	private DummyRowState()
	{
	}

	public void Restore()
	{
	}

	public void SaveChangedToDB()
	{
	}

	public void Init()
	{
	}

	public void RestoreWithoutLocalColumns()
	{
	}
}
