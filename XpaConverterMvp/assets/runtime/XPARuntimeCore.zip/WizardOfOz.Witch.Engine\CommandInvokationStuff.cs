using WizardOfOz.Witch.UI;

namespace WizardOfOz.Witch.Engine;

internal class CommandInvokationStuff
{
	private IControl _control;

	private object[] _args;

	public CommandInvokationStuff(IControl control, object[] args)
	{
		_control = control;
		_args = args;
	}

	public void Invoke(ActionWithParameters actionWithParameters)
	{
		actionWithParameters(_control, _args);
	}
}
